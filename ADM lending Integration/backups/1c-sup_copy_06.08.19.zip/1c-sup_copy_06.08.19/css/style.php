<?php header("Content-type: text/css; charset: UTF-8"); ?>

<?php
$doubleOffsetWidth_1 = 30;
$doubleOffsetWidth_2 = 60;
$doubleOffsetWidth_3 = 60;
$doubleOffsetWidth_4 = 120;
$menuWidth_1 = 210;
$menuWidth_2 = 210;
$menuWidth_3 = 210;
$menuWidth_4 = 260;

$m_dx_1 = 0; 
$m_dx_2 = 0; 
$m_dx_3 = 0; 
$m_dx_4 = 0; 
$m_dx_5 = $menuWidth_1 + $doubleOffsetWidth_1; 
$m_dx_6 = $menuWidth_1 + $doubleOffsetWidth_1; 
$m_dx_7 = $menuWidth_2 + $doubleOffsetWidth_2; 
$m_dx_8 = $menuWidth_2 + $doubleOffsetWidth_2; 
$m_dx_9  = $menuWidth_3 + $doubleOffsetWidth_3; 
$m_dx_10 = $menuWidth_3 + $doubleOffsetWidth_3; 
$m_dx_11 = $menuWidth_3 + $doubleOffsetWidth_3; 
$m_dx_12 = $menuWidth_4 + $doubleOffsetWidth_4; 
$m_dx_13 = $menuWidth_4 + $doubleOffsetWidth_4; 


$w_374 = (374 + $m_dx_1) . "px";
$w_375 = (375 + $m_dx_2) . "px";
$w_424 = (424 + $m_dx_3) . "px";
$w_425 = (425 + $m_dx_4) . "px";
$w_575 = (575 + $m_dx_5) . "px";
$w_576 = (576 + $m_dx_6) . "px";

$w_767 = (767 + $m_dx_7) . "px";
$w_768 = (768 + $m_dx_8) . "px";

$w_991 = (991 + $m_dx_9) . "px";
$w_992 = (992 + $m_dx_10) . "px";
$w_1024 = (1024 + $m_dx_11) . "px";
//
$w_1199 = (1199 + $m_dx_12) . "px";
$w_1200 = (1200 + $m_dx_13) . "px";

?>

@charset "UTF-8";
body {
  font-family: 'Open Sans', sans-serif;
}

* {
  -webkit-box-sizing: border-box;
          box-sizing: border-box;
}

body {
  min-width: 320px;
  margin: 0;
  padding: 0;
  font-size: 14px;
  line-height: 14px;
}
/*
.frozen
{
	height: 100%;
    overflow: auto;
}
*/
/*
@media (min-width: <?php echo $w_425; ?>) and (max-width: <?php echo $w_575; ?>) {
  .container {
    max-width: 420px;
  }
}


@media (min-width: <?php echo $w_768; ?>) {
  .container {
    max-width: 750px;
  }
}

@media (min-width: <?php echo $w_992; ?>) {
  .container {
    max-width: 970px;
  }
}
@media (min-width: <?php echo $w_1024; ?>) {
  .container {
    max-width: 1000px;
  }
}
@media (min-width: <?php echo $w_1200; ?>) {
  .container {
    max-width: 1200px;
  }
}
*/


img {
  max-width: 100%;
  height: auto;
}

input, button, a, textarea {
  outline: none;
}
input:focus, button:focus, a:focus, textarea:focus {
  outline: none;
}
ul {
  list-style: none;
  margin: 0;
  padding: 0;
}
a {
  text-decoration: none;
  transition: color .3s ease, background-color .3s ease, border-color .3s ease;
}
a:hover {
  color: #000000;
  text-decoration: none;
}
button {
  transition: color .3s ease, background-color .3s ease, border-color .3s ease;
}
h1, h2, h3, h4, h5, h6 {
  margin: 0;
}

@font-face {
  font-family: 'icomoon';
  src: url("../fonts/icomoon.eot?usx0s3");
  src: url("../fonts/icomoon.eot?usx0s3#iefix") format("embedded-opentype"), url("../fonts/icomoon.ttf?usx0s3") format("truetype"), url("../fonts/icomoon.woff?usx0s3") format("woff"), url("../fonts/icomoon.svg?usx0s3#icomoon") format("svg");
  font-weight: normal;
  font-style: normal;
}
/* interface */

.button {
  display: inline-block;
  width: 265px;
  height: 50px;
  padding: 13px 0;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
  font-family: 'Open Sans', sans-serif;
  font-size: 16px;
  font-weight: 600;
  line-height: 20px;
  text-align: center;
  color: #ef7f1a;
  border: 2px solid #ef7f1a;
  background-color: transparent;
  cursor: pointer;
  -webkit-transition: color .3s ease, background-color .3s ease, border-color .3s ease;
  -o-transition: color .3s ease, background-color .3s ease, border-color .3s ease;
  transition: color .3s ease, background-color .3s ease, border-color .3s ease;
}
.button:hover {
  color: #ffffff;
  background-color: #ef7f1a;
}
[class^="icon-"], [class*=" icon-"] {
  font-family: "icomoon" !important;
  speak: none;
  font-style: normal;
  font-weight: normal;
  font-variant: normal;
  text-transform: none;
  line-height: 1;
  color: #ffffff;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}
.title, .title-main, .title-desc {
  color: #000000;
}

.title, .title-before {
  font-family: 'Open Sans', sans-serif;
  font-weight: 700;
  text-transform: uppercase;
}

.title-main, .title-desc {
  font-family: 'Open Sans', sans-serif;
  font-weight: 400;
}

.title {
  margin-bottom: 40px;
  font-size: 36px;
  line-height: 36px;
}
@media (max-width: <?php echo $w_767; ?>) {
  .title {
    font-size: 24px;
    line-height: 24px;
  }
}
.title-main {
  margin-bottom: 40px;
  font-size: 48px;
  line-height: 48px;
  text-align: center;
}
@media (min-width: <?php echo $w_768; ?>) and (max-width: <?php echo $w_1199; ?>) {
  .title-main {
    line-height: 50px;
  }
}
@media (min-width: <?php echo $w_576; ?>) and (max-width: <?php echo $w_767; ?>) {
  .title-main {
    font-size: 30px;
    line-height: 32px;
  }
}
@media (max-width: <?php echo $w_575; ?>) {
  .title-main {
    font-size: 24px;
    line-height: 26px;
    margin-bottom: 28px;
  }
}
.title-before {
  margin-bottom: 13px;
  font-size: 18px;
  line-height: 18px;
  color: #ef7f1a;
}
@media (max-width: <?php echo $w_767; ?>) {
  .title-before {
    font-size: 14px;
    line-height: 14px;
  }
}
.title-desc {
  font-size: 16px;
  line-height: 18px;
  margin-bottom: 15px;
}
.title-desc > div {
  padding-right: 25px;
}
.title-desc img {
  max-width: 11px;
  height: 11px;
}
@media (max-width: <?php echo $w_767; ?>) {
  .title-desc {
    font-size: 14px;
    line-height: 16px;
  }
}
@media (min-width: <?php echo $w_768; ?>) and (max-width: <?php echo $w_991; ?>) {
  .title-desc:last-child {
    margin-bottom: 39px;
  }
}
.title-bg {
  display: block;
  position: absolute;
  top: 0;
  left: 0;
  font-family: 'Open Sans', sans-serif;
  font-size: 140px;
  font-weight: 800;
  line-height: 120px;
  text-transform: uppercase;
  color: #f4f4f4;
  overflow: hidden;
  -o-text-overflow: clip;
     text-overflow: clip;
  white-space: nowrap;
  z-index: -1;
}
@media (max-width: <?php echo $w_767; ?>) {
  .title-bg {
    font-size: 110px;
    line-height: 98px;
  }
}
.wrap {
  position: relative;
  overflow: hidden;
  height: 100%;
}

/*header*/

.menu {
    position: fixed;
    top: 0;
    bottom: 0;
	
    width: 100%;
    margin-left: -100%;
	
    height: 100%;
    background: #000000 url(../img/header/mppusher-bg.jpg) center repeat;
    /* opacity: 0.95; */
    opacity: 0;
    overflow: hidden;
    z-index: 20;
    transition: /* margin-left ease-in-out 0.45s 0s, */ opacity ease-in-out 0.45s 0s, transform ease-in-out 0.45s 0s;
	
    z-index: 10600;
}

@media (min-width: <?php echo $w_576; ?>) {
  .menu { 
    margin-left: <?php echo -$menuWidth_1 . "px"; ?>;
	width: <?php echo $menuWidth_1 . "px"; ?>;
  }
}

@media (min-width: <?php echo $w_768; ?>){
  .menu {
    margin-left: <?php echo -$menuWidth_2 . "px"; ?>;
    width: <?php echo $menuWidth_2 . "px"; ?>;
  }
}

@media (min-width: <?php echo $w_992; ?>){
  .menu {
    margin-left: <?php echo -$menuWidth_3 . "px"; ?>;
    width: <?php echo $menuWidth_3 . "px"; ?>;
  }
}

@media (min-width: <?php echo $w_1200; ?>){
  .menu {
    margin-left: <?php echo -$menuWidth_4 . "px"; ?>;
    width: <?php echo $menuWidth_4 . "px"; ?>;
  }
}

/* контрольная точка, на которой меню перекрывает контент на 100% ширины */
@media (min-width: 400px) { /* КТ 400px */
  .menu {
	margin-left: <?php echo -$menuWidth_1 . "px"; ?>; /*исправляет косяк с transform: translateX(100%); когда ширина не 100%*/
    width: <?php echo $menuWidth_1 . "px"; ?>;
  }
}

.menu-top {
	width: 100%;
	height: 55px;
	margin-top: 31px;
	margin-bottom: 10px;
	padding-right: 14px;
	padding-left: 14px;
}

.menu-top_arrow {
	float: left;
	width: 42px;
	height: 21px;
	background: url(../img/header/arrow.svg) center no-repeat;
	cursor: pointer;
	
	transition: margin-left 0.1s;
}

.menu-top_arrow:hover {
    margin-left: -4px;
}

@media (min-width: <?php echo $w_576; ?>) {
  .menu-top_arrow { 
	height: 18px;
  }
}

.menu-logo {
	float: right;
    display: block;
	width: 84px;
	height: 20px;
}

@media (min-width: <?php echo $w_576; ?>) {
  .menu-logo { 
	display: none;
	width: 0px;
	height: 0px;
  }
}

.menu-logo img {
  height: 18px;
}

.menu-list
{
	padding: 24px 14px 10px 14px;
	
	margin-left: auto;
    margin-right: auto;
    width: max-content;
}

.menu-list .menu-item {
  padding-top: 12px;
  padding-bottom: 12px;
}

.menu-list > li > .menu-link {
	display: inline-block;
	font-family: 'Open Sans', sans-serif;
	font-size: 14px;
	font-weight: 400;
	line-height: 16px;
	color: #ffffff;
	cursor: pointer;
	transition: color linear 0.3s, text-shadow linear 0.3s;
	width: auto; /* позволяют правильно отрисовать transition в Chrome */
    height: auto;
}

.menu-list li > .menu-link:hover, .menu-list li > .menu-link:focus {
	color: #ef7f1a;
	text-shadow: 0px 0px 1px #ef7f1a;
}

.menu-active {
    /* margin: 0; */
    opacity: 0.95;
    transition: /* margin-left ease-in-out 0.45s 0.15s, */ opacity ease-in-out 0.45s 0.15s, transform ease-in-out 0.45s 0.15s;
    transform: translateX(100%);
}

.menu-social {
	padding: 38px 14px 34px 14px;
	position: absolute;
    bottom: 0;
	width: 100%;
    margin-bottom: 0;
	background-color: rgba(0, 0, 0, 0.2);
}

.menu-socials-wrap {
    margin-left: auto;
    margin-right: auto;
    position: relative;
    display: flex;
    width: min-content;
}

/* ---Соц иконки МЕНЮ--- */
.menu-social a {
    display: flex;
    justify-content: center;
    align-items: center;
    width: 24px;
    height: 24px;
    border-radius: 50%;
    border: 1px solid #fff;
    background-color: #8b8b8b00;
	
	margin-left: 6px;
    margin-right: 6px;
}
.menu-social a:hover, .menu-social a:focus {
  background-color: #ef7f1a;
}
.menu-social a .icon-odnoklassniki, .menu-social a .icon-twitter, .menu-social a .icon-telegram, .menu-social a .icon-instagram, .menu-social a .icon-whatsapp, .menu-social a .icon-viber-brands, .menu-social a .icon-pinterest, .menu-social a .icon-facebook {
  font-size: 12px;
}
.menu-social a .icon-odnoklassniki::before {
  content: "\e902";
}
.menu-social a .icon-twitter::before {
  content: "\ea96";
}
.menu-social a .icon-telegram::before {
  content: "\e903";
  margin-left: -3px;
}
.menu-social a .icon-instagram::before {
  content: "\e904";
}
.menu-social a .icon-whatsapp::before {
  content: "\ea93";
}
.menu-social a .icon-viber-brands:before {
  content: "\e90d";
}
.menu-social a .icon-pinterest::before {
  content: "\e906";
}
.menu-social a .icon-facebook::before {
  content: "\ea90";
}
.menu-social a .icon-vkontakte {
  padding-left: 3px;
}
.menu-social a .icon-vkontakte::before {
  content: "\e900";
}
/* ---конец соц иконки меню--- */



.scrollcontent {
    position: relative;
    left: 0;
    max-width: 100%;
    height: 100%;
    transition: width cubic-bezier(0.2, 0, 0.8, 1) 0.45s;
    width: 100%;
    float: right;
    transition: width ease-in-out 0.45s 0.15s;
}

@media (min-width: <?php echo $w_576; ?>)
{
	.scrollcontent_active {
	/*left: <?php echo $menuWidth_1 . "px"; ?>;*/
	width: calc(100% - <?php echo $menuWidth_1 . "px"; ?>);
	opacity: 0.95;
    transition: width ease-in-out 0.45s 0s;
	}
}
@media (min-width: <?php echo $w_768; ?>)
{
	.scrollcontent_active {
	/*left: <?php echo $menuWidth_2 . "px"; ?>;*/
	width: calc(100% - <?php echo $menuWidth_2 . "px"; ?>);
	opacity: 0.95;
    transition: width ease-in-out 0.45s 0s;
	}
}
@media (min-width: <?php echo $w_992; ?>)
{
	.scrollcontent_active {
	/*left: <?php echo $menuWidth_3 . "px"; ?>;*/
	width: calc(100% - <?php echo $menuWidth_3 . "px"; ?>);
	opacity: 0.95;
    transition: width ease-in-out 0.45s 0s;
	}
}
@media (min-width: <?php echo $w_1200; ?>)
{
	.scrollcontent_active {
	/*left: <?php echo $menuWidth_4 . "px"; ?>;*/
	width: calc(100% - <?php echo $menuWidth_4 . "px"; ?>);
	opacity: 0.95;
    transition: width ease-in-out 0.45s 0s;
	}
}


header.header {
	z-index: 10;
	position: fixed;
  /* width: 100%; */
  width: inherit;
  padding: 20px 0;
  background-color: #ffffff;
  
  border-bottom: solid 1px #ffffff; /* для transition когда добавится класс headerFixed */
  transition: border-bottom-color 1s;
}

@media (max-width: <?php echo $w_767; ?>) {
  header.header {
    padding: 10px 0;
  }
}

header.header.headerBottomBorder
{
    border-bottom-color: #8a8947;
}

.header-logo {
  display: block;
  width: 122px;
  height: 26px;
}

@media (max-width: <?php echo $w_767; ?>) {
  .header-logo {
    width: 84px;
    height: 18px;
  }
  .header-logo img {
    height: 18px;
  }
}

.header-menu-link {
	display: block;
	background: url(../img/header/menu.svg) center no-repeat;
	cursor: pointer;
	/* margin-left: 15px; */

	width: 28px;
	height: 12px;
}
@media (min-width: <?php echo $w_768; ?>) {
	.header-menu-link {
		width: 41px;
		height: 18px;
	}
}

.header-menu-close {
	padding: 0px 6px 2px 6px;
    font-size: 40px;
    font-weight: 300;
    line-height: 16px;
    color: #828282;
    background-color: transparent;
    border: none;
    cursor: pointer;
	
	/* width: min-content; */
    /* transition: transform 0.3s 0.2s; */
}
.header-menu-close:hover
{
	/* -webkit-transform: rotate(90deg); */
    /* transform: rotate(90deg); */
	color: #3b3a3a;
    text-shadow: 0px 0px 1px #828282;
}

.header-phone {
  margin-right: 49px;
  font-family: 'Open Sans', sans-serif;
  font-size: 16px;
  font-weight: 300;
  line-height: 16px;
  color: #000000;
}
.header-phone:hover, .header-phone:focus {
  text-decoration: underline;
}
@media (max-width: <?php echo $w_767; ?>) {
  .header-phone {
    margin-right: 14px;
    font-size: 14px;
  }
}

@media (max-width: 555px) { /* КТ 555px */
  .header-phone__mhidden {
    display: none;
  }
}


.header-btn {
	padding: 0;
	font-weight: normal;
	color: #ffffff;
	border-radius: 3px;

	border: 1px solid #ef7f1a;
	background-color: #ef7f1a;

	width: 111px;
	height: 28px;
	line-height: 28px;
	font-size: 12px;
}
.header-btn:hover, .header-btn:focus {
  border: 1px solid rgba(239, 127, 26, 0.4);
  background-color: rgba(239, 127, 26, 0.7);
}
@media (min-width: <?php echo $w_768; ?>) {
	.header-btn {
		width: 150px;
		height: 40px;
		line-height: 40px;
		font-size: 16px;
	}
}

.h-our_awards ul li {
  width: 100%;
  padding-bottom: 15px;
}
.h-our_awards ul li:last-child {
  padding-right: 0;
}
/*header.sticky .h-our_awards ul > li > img {
  display: inline-block;
  width: 55px;
  height: 30px;
}*/


/* highlights */

.highlights {
  padding-top: 73px; /* 25px; */
  padding-bottom: 25px;
}
@media (min-width: <?php echo $w_576; ?>) {
  .highlights {
    padding-top: 89px; /* 40px; */
    padding-bottom: 30px;
  }
}
@media (min-width: <?php echo $w_768; ?>) {
  .highlights {
    padding-top: 109px; /* 60px; */
    padding-bottom: 50px;
  }
}

.highlights_blue {
  display: block;
  width: 80px;
  height: 80px;
  font-family: 'Open Sans', sans-serif;
  font-size: 36px;
  color: #34c6f5;
  line-height: 75px;
  border: 1.25px solid #34c6f5;
  border-radius: 50%;
  text-align: center;
}

.highlights-items li {
  padding-bottom: 20px;
}
.highlights-items li:last-child {
  padding-bottom: 0;
}

.highlights-items__descr {
  display: block;
  width: 84%;
  font-family: 'Open Sans', sans-serif;
  font-size: 20px;
  color: #000000;
  line-height: 20px;
  padding-left: 35px;
}

@media (max-width: <?php echo $w_575; ?>) {
  .highlights_blue {
    width: 53px;
    height: 53px;
    font-size: 24px;
    line-height: 50px;
  }
  .highlights-items__descr {
    padding-left: 20px;
    font-size: 18px;
  }
}
@media (min-width: <?php echo $w_576; ?>) and (max-width: <?php echo $w_768; ?>) { 
  .highlights_blue {
    font-size: 25px;
    line-height: 47px;
    width: 50px;
    height: 50px;
  }
  .highlights-items__descr {
    font-size: 18px;
    line-height: 20px;
    padding-left: 30px;
  }
}
@media (min-width: <?php echo $w_768; ?>) and (max-width: <?php echo $w_1199; ?>) {
  .highlights_blue {
    font-size: 33px;
    line-height: 62px;
    width: 65px;
    height: 65px;
  }
  .highlights-items__descr {
    width: 72%;
    font-size: 18px;
    line-height: 20px;
    padding-left: 15px;
  }
}
@media (min-width: <?php echo $w_992; ?>) and (max-width: <?php echo $w_1199; ?>) {
  .highlights-items__descr {
    width: 62%;
    padding-left: 20px;
  }
}
.highlights-img {
  width: 90%;
}
@media (min-width: <?php echo $w_992; ?>) and (max-width: <?php echo $w_1199; ?>) {
  .highlights-img {
    width: 90%;
  }
}

@media (max-width: <?php echo $w_991; ?>) {
  .highlights-img {
    width: 100%;
  }
}


/*about-services*/

.about-services {
  padding-top: 50px;
  padding-bottom: 50px;
}
@media (max-width: <?php echo $w_767; ?>) {
  .about-services {
    padding-top: 30px;
    padding-bottom: 0;
  }
}
@media (max-width: <?php echo $w_575; ?>) {
  .about-services {
    padding-top: 25px;
  }
}
.about-services-desc {
	padding: 42px 50px 25px 77px;
	background-color: #f9f9f9;

	width: auto;
}
@media (max-width: <?php echo $w_1199; ?>) {
  .about-services-desc {
    padding: 32px 15px 25px 25px;
  }
}
@media (max-width: <?php echo $w_991; ?>) {
  .about-services-desc {
    padding: 32px 10px 25px 10px;
  }
}
@media (max-width: <?php echo $w_768; ?>) {
  .about-services-desc {
    padding: 42px 50px 25px 77px;
    margin-bottom: 50px;
	
	width: fit-content;
	margin-left: auto;
	margin-right: auto;
  }
}
@media (max-width: <?php echo $w_575; ?>) {
  .about-services-desc {
    padding: 25px 15px 25px 15px;
    margin-bottom: 50px;
  }
}

.about-services-desc-content
{
	height: auto;
    width: fit-content;
    position: relative;
    margin-left: auto;
    margin-right: auto;
}

.about-services-title {
  margin-bottom: 30px;
  font-family: 'Open Sans', sans-serif;
  font-size: 30px;
  font-weight: 600;
  line-height: 34px;
  color: #000000;
}
@media (max-width: <?php echo $w_991; ?>) {
  .about-services-title {
    font-size: 24px;
    line-height: 28px;
  }
}
@media (max-width: <?php echo $w_767; ?>) {
  .about-services-title {
    font-size: 22px;
    line-height: 24px;
    margin-bottom: 25px;
  }
}
@media (max-width: <?php echo $w_424; ?>) {
  .about-services-title {
    font-size: 19px;
  }
}
.about-services-price {
  margin-bottom: 30px;
  font-family: 'Open Sans', sans-serif;
  font-size: 55px;
  font-weight: 400;
  line-height: 50px;
  color: #000000;
}
.about-services-price span {
  font-size: 24px;
}
@media (max-width: <?php echo $w_425; ?>) {
  .about-services-price {
    font-size: 40px;
    line-height: 40px;
  }
}

/* subscription */

.subscription {
  padding-top: 40px;
  padding-bottom: 50px;
}
@media (max-width: <?php echo $w_767; ?>) {
  .subscription {
    padding-top: 10px;
    padding-bottom: 30px;
  }
}
@media (max-width: <?php echo $w_575; ?>) {
  .subscription {
    padding-top: 0;
    padding-bottom: 25px;
  }
}
.title-desc span {
  padding-right: 25px;
}
.title-desc span::before {
  content: "\2713";
  color: #000000;
}
.subscription-block {
  padding: 40px 0 20px 0;
}
.subscription-table {
  font-size: 14px;
  width: 100%;
}
@media (max-width: <?php echo $w_575; ?>) {
  .subscription-table {
    /* width: 180%; */
	width: fit-content;
	width: -webkit-fit-content;
	width: -moz-fit-content;
	min-width: 100%;
  }
  /*для IE*/
	@media screen and (-ms-high-contrast: active), (-ms-high-contrast: none) {
	.subscription-table {
	width: calc(180% + 200px);
	}
	}
	
  .subscription-table__scroll {
    width: 100%;
    overflow: scroll;
  }
}
.table_row-grey,.table_name-blue {
  -ms-flex-align: center !important;
  -webkit-box-align: center !important;
          align-items: center !important;
  display: -webkit-box;
  display: -ms-flexbox;
  display: flex;
  -webkit-box-pack: center;
      -ms-flex-pack: center;
          justify-content: center;
}
.table_name-blue {
  font-weight: 600;
  height: 50px;
  background-color: #a5e6fa;
}
.subscription-table .table_row-grey {
  height: 35px;
  padding: 0;
  background-color: #f7f7f7;
}
.t-dark_grey {
  background-color: #e1e1e1;
}
.t-middle_grey {
  background-color: #f1f1f1;
}
.s-table_name, .s-table_row {
  display: -webkit-box;
  display: -ms-flexbox;
  display: flex;
}
.table_name-blue, .table_row-grey {
  width: 15%;
  margin: 0 4px 4px 0;
  padding: 10px;
  text-align: center;
  overflow: hidden;
}
.table_name-blue:first-child, .table_row-grey:first-child {
  width: 38%;
  -webkit-box-pack: start;
      -ms-flex-pack: start;
          justify-content: flex-start;
  padding-left: 15px;
}

@media (max-width: <?php echo $w_575; ?>) {
  .table_name-blue:first-child, .table_row-grey:first-child {
    min-width: 195px;
    -webkit-box-pack: start;
        -ms-flex-pack: start;
            justify-content: flex-start;
    padding-left: 10px;
  }  
}
@media (max-width: <?php echo $w_991; ?>) {
  .subscription-advant {
    margin-top: 40px;
  }
}

.subscription-advant__title {
  margin-bottom: 20px;
  font-family: 'Open Sans', sans-serif;
  font-size: 23px;
  font-weight: 600;
  line-height: 25px;
  color: #000000;
}
@media (max-width: <?php echo $w_767; ?>) {
  .subscription-advant__title {
    font-size: 18px;
    line-height: 20px;
  }
  
}
.subscription-advant p {
  margin-bottom: 20px;
  font-family: 'Open Sans', sans-serif;
  font-size: 14px;
  font-weight: 300;
  line-height: 16px;
  color: rgb(5, 0, 0);
}
.subscription-advant p > b {
  font-weight: 600;
}
.subscription-advant p:last-child {
  margin-bottom: 0;
}
.support-price {
  padding-top: 15px;
  font-family: 'Open Sans', sans-serif;
  font-size: 49px;
  font-weight: 500;
  line-height: 40px;
  color: #000000;
 }
.support-price span {
  font-size: 24px;
}
.support-bonus {
  margin: 30px 0;
  font-family: 'Open Sans', sans-serif;
  font-size: 18px;
  font-weight: 400;
  line-height: 20px;
  color: #000000;
}
.support-detail__btn {
  width: 150px;
  height: 40px;
  padding: 11px 0;
  font-size: 14px;
  font-weight: 400;
  line-height: 16px;
  border: 1px solid #000000;
  border-radius: 3px;
  color: #000000;
}

.support-detail__btn:hover {
  color: #ef7f1a;
  border-color: #ef7f1a;
  background-color: transparent;
}

@media (max-width: <?php echo $w_424; ?>) {
  .subscription-img {
    width: 290px;
    height: 271px;
  }
}
@media (min-width: <?php echo $w_425; ?>) and (max-width: <?php echo $w_575; ?>) {
  .subscription-img {
    height: 330px;
  }
}
@media (min-width: <?php echo $w_992; ?>) and (max-width: <?php echo $w_1199; ?>) {
  .subscription-img {
    width: 463px;
    height: 267px;
  }
}

.subscription-desc {
  position: relative;
  padding-left: 75px;
  padding-top: 25px;
}
@media (min-width: <?php echo $w_768; ?>) {
  .subscription-desc {
    padding-left: 0;
  }
}
@media (max-width: <?php echo $w_575; ?>) {
  .subscription-desc {
    padding-left: 0;
  }
}
@media (max-width: <?php echo $w_991; ?>) {
  .subscription-desc {
    padding-top: 35px;
  }
}

.subscription-bg {
  margin-top: -10px;
  margin-left: -40px;
}
.subscription-bg span {
  margin-left: 175px;
}
@media (max-width: <?php echo $w_575; ?>) {
  .subscription-bg span {
    margin-left: 145px;
  }
}

@media (max-width: <?php echo $w_991; ?>) {
  .subscription-bg {
    margin-top: 0px;
    margin-left: -150px;
  }
}
@media (min-width: <?php echo $w_992; ?>) and (max-width: <?php echo $w_1199; ?>) {
  .subscription-bg {
    margin-left: -90px;
  }
}

/* support */

.support {
  padding-top: 40px;
  padding-bottom: 50px;
}
@media (max-width: <?php echo $w_767; ?>) {
  .support {
    padding-top: 30px;
    padding-bottom: 30px;
  }
}
@media (max-width: <?php echo $w_575; ?>) {
  .support {
    padding-top: 25px;
    padding-bottom: 25px;
  }
}

/* padding-left по образцу subscription-desc */
.support-desc {
  position: relative;
  padding-left: 75px;
  padding-top: 5px;
  margin-top: 20px;
}
@media (max-width: <?php echo $w_1199; ?>) {
  .support-desc {
    margin-top: 0;
  }
}
@media (max-width: <?php echo $w_991; ?>) {
  .support-desc {
    margin-top: 20px;
  }
}
@media (min-width: <?php echo $w_768; ?>) {
  .support-desc {
    padding-left: 0;
  }
}
@media (max-width: <?php echo $w_575; ?>) {
  .support-desc {
    padding-left: 0;
  }
}

@media (min-width: <?php echo $w_992; ?>) and (max-width: <?php echo $w_1199; ?>) {
  .support-title-before {
    margin-top: 25px;
  }
}
.support h3 {
  padding-right: 65px;
}
@media (max-width: <?php echo $w_1199; ?>) {
  .support h3 {
    padding-right: 0;
  }
}
.support-bg {
  margin-top: -30px;
  margin-left: -385px;
}
@media (max-width: <?php echo $w_424; ?>) {
  .support-bg span {
    margin-left: -30px;
  }
}
@media (min-width: <?php echo $w_425; ?>) and (max-width: <?php echo $w_575; ?>) {
  .support-bg span {
    margin-left: 0;
  }
}
@media (min-width: <?php echo $w_992; ?>) and (max-width: <?php echo $w_1199; ?>) {
  .support-bg span {
    margin-left: -35px;
  }
}
@media (max-width: <?php echo $w_991; ?>) {
  .support-bg {
    margin-left: -50px;
  }
}
@media (min-width: <?php echo $w_992; ?>) and (max-width: <?php echo $w_1199; ?>) {
  .support-bg {
    margin-top: 0;
    margin-left: -332px;
  }
}

/*
@media (min-width: <?php echo $w_768; ?>) and (max-width: <?php echo $w_1199; ?>) {
  .support-img {
    width: 403px;
    height: 404px;
  }
}
*/

/*support-services*/

.support-services {
  position: relative;
  padding-top: 40px;
  padding-bottom: 50px;
}
@media (max-width: <?php echo $w_767; ?>) {
  .support-services {
    padding-top: 30px;
    padding-bottom: 30px;
  }
}
@media (max-width: <?php echo $w_575; ?>) {
  .support-services {
    padding-top: 25px;
    padding-bottom: 25px;
  }
}
.support-services-bg {
  margin-left: -195px;
}
.support-services__title {
  margin-top: 55px;
  margin-bottom: 23px;
}
.service-item {
  display: block;
  width: 100%;
  padding-top: 40px;
  padding-left: 15px;
}
@media (min-width: <?php echo $w_768; ?>) and (max-width: <?php echo $w_991; ?>) {
  .service-item {
    width: 85%;
  }
}
@media (min-width: <?php echo $w_375; ?>) and (max-width: <?php echo $w_575; ?>) {
  .service-item {
    width: 85%;
  }
}
.service-item img {
  display: block;
  height: 65px;
  margin: 0 auto 20px 40px;
}
@media (max-width: <?php echo $w_575; ?>) {
  .support-services {
    padding-top: 20px;
  }
  .support-services__title {
    margin-top: 35px;
    margin-bottom: 20px;
  }
}
.service-item_name {
  margin-bottom: 20px;
  font-family: 'Open Sans', sans-serif;
  font-size: 18px;
  font-weight: 600;
  line-height: 18px;
  color: #000000;
}
.service-item_desc {
  font-family: 'Open Sans', sans-serif;
  font-size: 14px;
  font-weight: 300;
  line-height: 16px;
  color: #000000;
}

@media (max-width: <?php echo $w_575; ?>) {
  .service-item_name {
    font-size: 16px;
    line-height: 16px;
  }
}
@media (max-width: <?php echo $w_424; ?>) {
  .support-services-img {
    width: 290px;
    height: 230px;
  }
}
@media (min-width: <?php echo $w_425; ?>) and (max-width: <?php echo $w_575; ?>) {
  .support-services-img {
    width: 390px;
    height: 330px;
  }
}
.service-link {
  display: none;
  padding-top: 40px;
  padding-left: 15px;
  font-family: 'Open Sans', sans-serif;
  font-size: 14px;
  color: #000000;
  line-height: 17px;
  text-decoration: underline;
  vertical-align: bottom;
  cursor: pointer;
}

.service-link:hover {
  color: #ef7f1a;
  text-decoration: underline;
}
@media (max-width: <?php echo $w_767; ?>) {
  .service-link {
    color: #ef7f1a;
  }
  .service-link:hover {
    color: rgba(#ef7f1a, 0.5);
  }

}

@media (max-width: <?php echo $w_991; ?>) {
  .service-link__show {
    display: inline-block;
  }
  .service-link__hide {
      display: none;
    }
  }  
@media (max-width: <?php echo $w_575; ?>) {
  .service-link {
    /*display: block;*/
    padding-left: 0;
  }
}
/*recommend*/

.recommend {
  padding-top: 40px;
  padding-bottom: 50px;
}
@media (max-width: <?php echo $w_767; ?>) {
  .recommend {
    padding-top: 30px;
    padding-bottom: 30px;
  }
}
@media (max-width: <?php echo $w_575; ?>) {
  .recommend {
    padding-top: 25px;
    padding-bottom: 25px;
  }
}
@media (max-width: <?php echo $w_424; ?>) {
  .recommend {
    padding-top: 50px;
  }
}
.recommend-title {
  margin: 60px auto 50px 0;
}
@media (max-width: <?php echo $w_767; ?>) {
  .recommend-title {
    margin: 40px auto 40px 0;
  }
}
@media (max-width: <?php echo $w_424; ?>) {
  .recommend-title {
    margin: 0 auto 40px 0;
  }
}
.recommend-bg {
  margin-left: -115px;
}
@media (max-width: <?php echo $w_424; ?>) {
  .recommend-bg {
    margin-left: -148px;
    margin-top: -35px;
  }
}
@media (min-width: <?php echo $w_425; ?>) and (max-width: <?php echo $w_767; ?>) {
  .recommend-bg {
    margin-left: -160px;
  }
}
@media (min-width: <?php echo $w_768; ?>) and (max-width: <?php echo $w_1199; ?>) {
  .recommend-bg {
    margin-left: -180px;
  }
}
.work-process {
  position: relative;
  padding-top: 60px;
  padding-bottom: 90px;
  margin-left: -15px;
}
@media (max-width: <?php echo $w_767; ?>) {
  .work-process {
    padding-top: 30px;
    padding-bottom: 40px;
    margin-left: 0;
  }
}
.text-bg {
  position: absolute;
  display: block;
  left: 0;
  font-family: 'Open Sans', sans-serif;
  font-size: 85px;
  font-weight: 700;
  line-height: 85px;
  text-transform: uppercase;
  color: #f4f4f4;
  overflow: hidden;
  -o-text-overflow: clip;
     text-overflow: clip;
  white-space: nowrap;
  z-index: -1;
}

.wp-text-bg__top {
  top: 0;
  margin-left: 15px;
}
.wp-text-bg__bottom {
  bottom: 0;
  margin-left: -60px;
}
@media (max-width: <?php echo $w_767; ?>) {
  .text-bg {
    font-size: 45px;
    line-height: 45px;
  }
  .wp-text-bg__top {
    margin-left: 15px;
  }
  .wp-text-bg__bottom {
    margin-left: 15px;
  }
}
.wp-tree {
  position: relative;
  padding: 40px 0 20px 0;
  border-left: 1px solid #ef7f1a;
}
.wp-cell {
  width: 350px;
  margin-left: 115px;
  position: relative;
}
.wp-cell:nth-child(even) {
  margin-top: -50px;
}
.wp-cell:nth-child(odd) {
  margin-left: -465px;
  text-align: right;
  margin-top: -25px;
}
@media (min-width: <?php echo $w_768; ?>) and (max-width: <?php echo $w_991; ?>) {
  .wp-cell {
    width: 250px;
  }
  .wp-cell:nth-child(odd) {
    margin-left: -365px;
  }  
}
@media (max-width: <?php echo $w_767; ?>) {
  .wp-cell {
    width: 250px;
    margin-bottom: 30px;
  }
  .wp-cell:nth-child(odd) {
    margin-left: 115px;
    text-align: left;
    margin-top: 0;
  }
  .wp-cell:nth-child(even) {
    margin-top: 0;
  }
}
@media (max-width: <?php echo $w_424; ?>) {
  .wp-cell {
    margin-left: 40px;
  }
  .wp-cell:nth-child(odd) {
    margin-left: 40px;
  }
}
.wprocess-number {
  margin-bottom: 13px;
  font-family: 'Open Sans', sans-serif;
  font-size: 30px;
  font-weight: 700;
  color: #686868;
  line-height: 30px;
}
.wprocess-step {
  margin-bottom: 13px;
  font-family: 'Open Sans', sans-serif;
  font-size: 18px;
  font-weight: 600;
  color: #000000;
  line-height: 18px;
}
.wprocess-desc {
  font-family: 'Open Sans', sans-serif;
  font-size: 14px;
  color: #686868;
  line-height: 18px;
}
.wp-cell:nth-child(even) .wp-cell-bg {
  margin-left: 115px;
}
.wp-cell:nth-child(odd) .wp-cell-bg {
  margin-left: -115px;
}
@media (max-width: <?php echo $w_767; ?>) {
  .wp-cell:nth-child(even) .wp-cell-bg {
    margin-left: 25px;
  }
  .wp-cell:nth-child(odd) .wp-cell-bg {
    margin-left: 25px;
  }
}
.wp-line {
  color: #ef7f1a;
  display: block;
  width: 30px;
  height: 1px;
  margin: 0;
  top: 50px;
  position: absolute;
  background-color: #ef7f1a;
}
.wp-cell:nth-child(even) .wp-line {
  margin-left: -115px;
}
.wp-cell:nth-child(odd) .wp-line {
  right: 0;
  margin-right: -115px;
}
@media (max-width: <?php echo $w_767; ?>) {
  .wp-cell:nth-child(odd) .wp-line {
    margin-right: 0;
    left: 0;
    margin-left: -115px;
  }
}
@media (max-width: <?php echo $w_424; ?>) {
  .wp-cell:nth-child(even) .wp-line {
    margin-left: -40px;
  }
  .wp-cell:nth-child(odd) .wp-line {
    margin-right: 0;
    left: 0;
    margin-left: -40px;
  }
}
.wp-img {
  position: absolute;
  display: block;
  top: 30px;
}
@media (max-width: <?php echo $w_424; ?>) {
  .wp-img {
    display: none;
  }
}
.wp-cell:nth-child(even) .wp-img {
  margin-left: -65px;
}
.wp-cell:nth-child(odd) .wp-img {
  right: 0;
  margin-right: -65px;
}
@media (max-width: <?php echo $w_767; ?>) {
  .wp-cell:nth-child(odd) .wp-img {
    left: 0;
    margin-left: -65px;
  }
}

/*calculation*/

.calculation {
  padding-top: 40px;
  padding-bottom: 100px;
}

@media (max-width: <?php echo $w_991; ?>) {
  .calculation {
    padding-top: 0;
    padding-bottom: 60px;
  }
}
@media (max-width: <?php echo $w_424; ?>) {
  .calculation {
    padding-top: 5px;
    padding-bottom: 50px;
  }
}
.calculation-item-title {
  position: relative;
  margin: 60px auto 50px 0;
}

@media (max-width: <?php echo $w_424; ?>) {
  .calculation-item-title {
    margin: 40px 0;
  }
}
.calculation-title {
  margin-bottom: 0;   
}
.calculation-bg {
  margin-top: -65px;
  margin-left: -245px;
}
@media (max-width: <?php echo $w_991; ?>) {
  .calculation-bg {
    margin-top: -35px;
  }
}
@media (min-width: <?php echo $w_425; ?>) and (max-width: <?php echo $w_767; ?>) {
  .calculation-bg {
    margin-left: -190px;
  }
}
@media (max-width: <?php echo $w_424; ?>) {
  .calculation-bg {
    margin-left: -178px;
  }
}

.calculation p {
  margin-bottom: 30px;
  font-family: 'Open Sans', sans-serif;
  font-size: 17px;
  font-weight: 300;
  line-height: 18px;
  color: rgb(111, 109, 110);
}
@media (max-width: <?php echo $w_767; ?>) {
  .calculation p {
    font-size: 14px;
    line-height: 16px;
    margin-top: 0px;
  }
}
.calculation-form__input {
  width: 100%;
  height: 50px;
  margin-bottom: 30px;
  padding-left: 30px;
  font-family: 'Open Sans', sans-serif;
  font-size: 14px;
  line-height: 14px;
  font-weight: 300;
  color: #000000;
  border: 1px solid #b7b7b7;
  border-bottom: 2px solid #ef7f1a;
  
  background: none;
  z-index: 2;
}
@media (max-width: <?php echo $w_767; ?>) {
  .calculation-form__input {
    padding-left: 15px;
    margin-bottom: 15px;
  }
}
.calculation-form__ta {
  padding-top: 16px;
  padding-right: 15px;
  height: 89px;
  line-height: 16px;
  resize: none;
}
.calculation-label {
  height: 50px;
  line-height: 50px;
  /*margin-bottom: 30px;*/
  border-bottom: 1px solid #b7b7b7;
  cursor: pointer;
  width: 100%;
  color: #000000;
}
.calculation-label:hover
{
	color: #ef7f1a;
    border-bottom: 1px solid #ef7f1a;
}
@media (min-width: <?php echo $w_767; ?>) {
  .calculation-label:hover {
	border-bottom: 1px solid transparent;  /* чтобы не сбивать отчтупы при наведении */
	outline: 1px solid #ef7f1a;
	box-shadow: none;
  }
}

.calculation-label img {
  margin-right: 30px;
  margin-left: 11px;
}
@media (max-width: <?php echo $w_991; ?>) {
  .calculation-label img {
    margin-right: 15px;
  }
}
@media (max-width: <?php echo $w_767; ?>) {
  .calculation-label img {
    margin-left: 0;
  }
}
.calculation-label span {
  font-family: 'Open Sans', sans-serif;
  font-size: 16px;
  font-weight: 300;
  line-height: 16px;
}   
@media (max-width: <?php echo $w_991; ?>) {
  .calculation-label span {
    font-size: 14px;
    line-height: 14px;
  }
}
.calculation-small {
	display: block;
	margin-left: auto;
	margin-right: auto;
	position: relative;
	width: max-content;
	font-weight: 300;
}
@media (max-width: <?php echo $w_767; ?>) {
  .calculation-small {
    margin: 1px auto 15px 35px;
  }
}

.calculation-form__checkbox {
  margin-top: 8px;
  margin-bottom: 38px;
}
@media (max-width: <?php echo $w_767; ?>) {
  .calculation-form__checkbox {
	  margin-top: 4px;
	  margin-bottom: 22px;
  }
}

.calculation-form__checkbox input[type='checkbox'] {
  -webkit-appearance: none;
  position: relative;
  display: block;
  width: 30px;
  height: 30px;
  border: 1px solid #b7b7b7;
  outline: none;
  cursor: pointer;
}
.calculation-form__checkbox input[type='checkbox']:checked::before {
  content: "\2713";
  position: absolute;
  top: 30%;
  left: 55%;
  -webkit-transform: translate(-50%, -50%);
      -ms-transform: translate(-50%, -50%);
          transform: translate(-50%, -50%);
  font-size: 34px;
  line-height: 29px;
  color: #ef7f1a;
}
@media (max-width: <?php echo $w_767; ?>) {
  .calculation-form__checkbox input[type='checkbox'] {
    width: 22px;
    height: 22px;
  }
  .calculation-form__checkbox input[type='checkbox']:checked::before {
    font-size: 28px;
    line-height: 22px;
  }
}
.calculation-form__checkbox label {
  font-family: 'Open Sans', sans-serif;
  font-weight: 300;
  padding-left: 15px;
  cursor: pointer;
  font-size: 14px;
  line-height: 14px;
  margin-bottom: 0;
}
.calculation-form__consent {
  margin-bottom: 30px;
  font-family: 'Open Sans', sans-serif;
  font-size: 12px;
  font-weight: 400;
  line-height: 12px;
  color: rgba(3, 0, 0, 255);
}
.calculation-form__btn {
  width: 284px;
}

@media (max-width: <?php echo $w_767; ?>) {
  .calculation-form__btn {
    width: 279px;
    font-size: 16px;
    line-height: 18px; 
  }
}

/*footer*/

.footer-top {
  padding-top: 40px;
  padding-bottom: 40px;
  background: rgba(165, 165, 165, 0.8) url(../img/footer/bg-top.jpg) center repeat;
}
.footer-top__list > li {
  border-bottom: 1px solid transparent;
}
.footer-top__list > li > a {
  font-family: 'Open Sans', sans-serif;
  font-size: 20px;
  font-weight: 600;
  color: #323232;
  line-height: 35px;
}
.footer-top__list > li > a:hover, .footer-top__list > li > a:focus {
  text-decoration: underline;
}
@media (max-width: <?php echo $w_767; ?>) {
  .footer-top__list > li > a {
    font-size: 14px;
    line-height: 28px;
  }
}
@media (max-width: <?php echo $w_767; ?>) {
  .footer-top__list {
    margin-bottom: 26px;
  }
  .list-3 {
    margin-bottom: 0;
  }
}
@media (max-width: <?php echo $w_575; ?>) {
  .footer-top__list {
	/* margin-left: 30px; */
    margin-left: 70px;
  }
}
@media (min-width: <?php echo $w_576; ?>) and (max-width: <?php echo $w_767; ?>) {
  .footer-top__list {
    /* margin-left: 70px; */
	margin-left: auto;
    margin-right: auto;
  }
}
.footer-bottom {
  padding-top: 24px;
  padding-bottom: 24px;
  background-color: #2f2f2f;
}
.footer-bottom-social a {
  display: -webkit-box;
  display: -ms-flexbox;
  display: flex;
  -webkit-box-pack: center;
      -ms-flex-pack: center;
          justify-content: center;
  -webkit-box-align: center;
      -ms-flex-align: center;
          align-items: center;
  width: 38px;
  height: 38px;
  border-radius: 50%;
  background-color: #a5a5a5;
}
.footer-bottom-social a:hover, .footer-bottom-social a:focus {
  background-color: #ef7f1a;
}
.footer-bottom-social a .icon-odnoklassniki, .footer-bottom-social a .icon-twitter, .footer-bottom-social a .icon-telegram, .footer-bottom-social a .icon-instagram, .footer-bottom-social a .icon-whatsapp, .footer-bottom-social a .icon-viber-brands, .footer-bottom-social a .icon-pinterest, .footer-bottom-social a .icon-facebook {
  font-size: 20px;
}
.footer-bottom-social a .icon-odnoklassniki::before {
  content: "\e902";
}
.footer-bottom-social a .icon-twitter::before {
  content: "\ea96";
}
.footer-bottom-social a .icon-telegram::before {
  content: "\e903";
  margin-left: -3px;
}
.footer-bottom-social a .icon-instagram::before {
  content: "\e904";
}
.footer-bottom-social a .icon-whatsapp::before {
  content: "\ea93";
}
.footer-bottom-social a .icon-viber-brands:before {
  content: "\e90d";
}
.footer-bottom-social a .icon-pinterest::before {
  content: "\e906";
}
.footer-bottom-social a .icon-facebook::before {
  content: "\ea90";
}
.footer-bottom-social a .icon-vkontakte {
  padding-left: 3px;
}
.footer-bottom-social a .icon-vkontakte::before {
  content: "\e900";
}

@media (max-width: <?php echo $w_991; ?>) {
  .footer-bottom-social a {
    margin-bottom: 10px;
  }
}
@media (max-width: <?php echo $w_767; ?>) {
  .footer-bottom-social {
    margin-bottom: 26px;
    padding-left: 30px;
  }
}
@media (min-width: <?php echo $w_425; ?>) and (max-width: <?php echo $w_575; ?>) {
  .footer-bottom-social {
    padding-left: 0;
    /*padding-right: 60px; */
	padding-right: 80px;
  }
}
@media (max-width: <?php echo $w_424; ?>) {
  .footer-bottom-social {
    padding-left: 0;
  }
}
@media (min-width: <?php echo $w_375; ?>) and (max-width: <?php echo $w_424; ?>) {
  .footer-bottom-social {
    padding-right: 50px;
  }
}
@media (max-width: <?php echo $w_374; ?>) {
  .footer-bottom-social {
    padding-right: 0;
  }
}
.footer-bottom-privacy, .footer-bottom-copy {
  font-family: 'Open Sans', sans-serif;
  font-size: 14px;
  font-weight: 400;
  color: #a5a5a5;
  line-height: 14px;
  white-space: nowrap;
}
@media (max-width: <?php echo $w_575; ?>) {
  .footer-bottom-copy {
    margin-left: 30px;
  }
}
@media (min-width: <?php echo $w_576; ?>) and (max-width: <?php echo $w_767; ?>) {
  .footer-bottom-copy {
    margin-left: 70px;
  }
}
.footer-bottom-privacy:hover, .footer-bottom-privacy:focus {
  color: #ef7f1a;
  text-decoration: underline;
}
@media (max-width: <?php echo $w_575; ?>) {
  .footer-bottom-privacy {
    margin-left: 30px;
  }
}
@media (min-width: <?php echo $w_576; ?>) and (max-width: <?php echo $w_767; ?>) {
  .footer-bottom-privacy {
    margin-left: 70px;
  }
}
@media (max-width: <?php echo $w_767; ?>) {
  .footer-bottom-privacy {
    margin-bottom: 17px;
  }
}

/*modal - send an application*/

.send-request .popup {
  position: absolute;
  top: 50%;
  left: 50%;
  max-width: 657px;
  width: 100%;
  /*height: 600px;*/
  background-color: #ffffff;
  /*overflow: auto;*/
  border-radius: 4px;
  -webkit-box-shadow: 0px 10px 18px 0px rgba(0, 0, 0, 0.26);
          box-shadow: 0px 10px 18px 0px rgba(0, 0, 0, 0.26);
  z-index: 0;
  pointer-events: auto;
}
@media (max-width: <?php echo $w_991; ?>) {
  .send-request .popup {
    max-width: 450px;
  }
}


@media (max-width: <?php echo $w_575; ?>) {
  .send-request .popup {
    top: 5%;
    max-width: 400px;
    width: 90%;
    margin: 10px 0;
    overflow: hidden;
  }
}

.send-request .popup-close {
  position: absolute;
  top: 15px;
  right: 20px;
  font-size: 34px;
  font-weight: 300;
  line-height: 17px;
  color: #ef7f1a;
  cursor: pointer;
  text-shadow: none;
  opacity: 1;
}

@media (max-width: <?php echo $w_575; ?>) {
  .send-request .popup-close {
    top: 11px;
    right: 8px;
  }
}
.send-request .popup-form {
  padding: 40px 52px 40px 60px;
}
@media (max-width: <?php echo $w_991; ?>) {
  .send-request .popup-form {
    padding: 30px;
  }
}
.send-request .popup-form-header__title {
  margin-bottom: 40px;
  font-family: 'Open Sans', sans-serif;
  font-weight: 400;
  font-size: 18px;
  line-height: 18px;
  color: #000000;
  text-transform: uppercase;
}
@media (max-width: <?php echo $w_991; ?>) {
  .send-request .popup-form-header__title {
    margin-bottom: 20px;
    font-size: 16px;
  }
}
.send-request .popup-form-header__descr {
  margin-bottom: 30px;
  font-family: 'Open Sans', sans-serif;
  font-weight: 300;
  font-size: 17px;
  line-height: 20px;
  color: rgb(111, 109, 110);
}
@media (max-width: <?php echo $w_991; ?>) {
  .send-request .popup-form-header__descr {
    margin-bottom: 20px;
    font-size: 14px;
    line-height: 17px;
  }
}

.popup-form-box__input {
  width: 100%;
  height: 50px;
  margin-bottom: 30px;
  padding-left: 30px;
  font-family: 'Open Sans', sans-serif;
  font-size: 14px;
  line-height: 14px;
  font-weight: 300;
  color: #000000;
  border: 1px solid #b7b7b7;
  border-bottom: 2px solid #ef7f1a;
}
@media (max-width: <?php echo $w_991; ?>) {
  .popup-form-box__input {
    margin-bottom: 20px;
  }  
}
@media (max-width: <?php echo $w_767; ?>) {
  .popup-form-box__input {
    margin-bottom: 15px;
	padding-left: 15px;
  }  
}

.popup-form-box__ta {
  padding-top: 17px;
  line-height: 16px;
  resize: none;
}
.popup-form-desc {
  font-family: 'Open Sans', sans-serif;
  font-size: 12px;
  font-weight: 400;
  line-height: 12px;
  color: rgba(3, 0, 0, 255);
}

.popup-form__button {
  width: 100%;
}
.popup-form__btn {
  width: 284px;
  margin-top: 40px;
}
@media (max-width: <?php echo $w_991; ?>) {
  .popup-form__btn {
    margin-top: 20px;
  }  
}
.modal.fade {
  -webkit-transition: opacity .3s linear;
  -o-transition: opacity .3s linear;
  transition: opacity .3s linear;
  z-index: 10600;
}    
.modal.fade .modal-dialog {
  -webkit-transform: translate(-50%, -50%);
  -ms-transform: translate(-50%, -50%);
      transform: translate(-50%, -50%);
}

@media (max-width: <?php echo $w_575; ?>) {
  .modal.fade .modal-dialog {
    -webkit-transform: translate(-50%, 0);
    -ms-transform: translate(-50%, 0);
        transform: translate(-50%, 0);
  }
}
.modal.show .modal-dialog {
	max-height: 100%;
	overflow: auto;

	top: 50%;
	left: 50%;
	-webkit-transform: translate(-50%, -50%);
	-ms-transform: translate(-50%, -50%);
	  transform: translate(-50%, -50%);
}

@media (max-width: <?php echo $w_575; ?>) {
  .modal.show .modal-dialog {
    top: 5%;
    -webkit-transform: translate(-50%, 0);
    -ms-transform: translate(-50%, 0);
        transform: translate(-50%, 0);
  }
}


/* label в роли placeholder'а */
.Flying_Placeholder
{
	position: relative;
}

.Flying_Placeholder label
{
	/* background: green; */
	position: absolute;
	transition: top .25s linear, font-size .25s linear;
	font-family: 'Open Sans', sans-serif;
	font-weight: 300;
	color: rgb(111, 109, 110); /* как у остального шрифта сайта */
	cursor: text;
	z-index: 1;
	font-size: 1em;
	top: 1.3em;
    left: 30px;
}

/* активируется с помощью js при фокусе input или textarea рядом с label */
.Flying_Placeholder label.focus
{
	/* background: red; */
	top: 4px;/* -1.25em; */
	font-size: 0.86em;
	color: #acacac;
}
@media (max-width: <?php echo $w_767; ?>) {
	.Flying_Placeholder label
	{
		left: 15px;
	}
}

/* см. как у .calculation-form__input */

/* --------- Блок предзагрузки файлов ------------- */
/* главная обертка предзагрузки */
.preloads
{
	width: 100%;
	height: auto;
	margin-bottom: 15px;
	padding-top: 10px;
	padding-bottom: 10px;
	padding-left: 15px;
	padding-right: 15px;
	margin-bottom: -20px;
	margin-top: -13px;
	/* background: green; */
}

/* 1 загруженный файл */
.preloads .p_item
{
	height: 35px;
	width: 100%;
	margin-bottom: 5px;
	
	/* background: olive; */
}

.preloads .p_item .p_text
{
	/* должны быть равные: */
	height: 35px;
	line-height: 35px;
	padding-right: 15px;
	
	width: calc(100% - 95px);
	float: left;
	margin-right: 5px;
	white-space: nowrap;
	overflow: hidden;
	
	/* background: pink; */
}

.preloads .p_item .p_close
{
	/* должны быть равные: */
	height: 35px;
	width: 35px;
	font-size: 35px;
    line-height: 35px;
	
	cursor: pointer;
    text-align: center;
	color: lightgray;
	float: right;
	/* background: grey; */
}

.preloads .p_item .p_close:hover
{
	color: black;
}

.preloads .p_item .p_preview
{
	height: 100%;
	width: 45px;
	margin-left: 5px;
	margin-right: 5px;
	overflow: hidden;
	float: left;
	background-repeat: no-repeat;
    background-position: center;
    background-size: contain;
	/* 	background: black; */
}

.preloads.my0_py0
{
	margin-top: 0px;
	margin-bottom: 0px;
	padding-top: 0px;
	padding-bottom: 0px;
}


/*-----------------------------------------------------------------------*/
/*             Костыли для виджета                                       */
/*-----------------------------------------------------------------------*/


/* --- переписывает, убирает пульсацию виджета --- *//*
.b24-widget-button-pulse-animate {
     -webkit-animation: widgetPulse 7 1.5s !important;
     animation: widgetPulse 7 1.5s !important; 
}
.b24-widget-button-pulse-animate_noAnim {
     -webkit-animation: none !important;
     animation: none !important; 
}
.b24-widget-button-pulse-animate_1anim {
     -webkit-animation: widgetPulse 2 1.5s !important;
     animation: widgetPulse 2 1.5s !important; 
}
/* --- конец --- переписывает, убирает пульсацию виджета --- */


/*-----------------------------------------------------------------------*/
/*             Кастомный список                                          */
/*-----------------------------------------------------------------------*/
/* https://select2.org/ */

.select2, .select2.select2-container.select2-container--default
{
	
	width: 100%;
    height: 50px;
    margin-bottom: 30px;
    padding-left: 30px;
    font-family: 'Open Sans', sans-serif;
    font-size: 14px;
    line-height: 14px;
    font-weight: 300;
    color: #000000;
	
	border: 1px solid #b7b7b7;
	border-radius: 0;
    border-bottom: 2px solid #ef7f1a;
    background: none;
	
	overflow: auto;
}
@media (max-width: <?php echo $w_767; ?>) {
  .select2, .select2.select2-container.select2-container--default {
    padding-left: 15px;
    margin-bottom: 15px;
  }
}

.select2-container--default.select2-container--focus .select2-selection--multiple, .select2-container--default .select2-selection--multiple
{
	width: 100%;
    height: 98%;
    border: none;
    outline: none;
    border-radius: 0;
    box-shadow: none;
}

/* опции выпадающего списка */
.select2-results__option
{
	font-family: 'Open Sans', sans-serif;
    font-size: 14px;
    line-height: 14px;
    font-weight: 300;
}

/* выбранные сверху */
.select2-container--default .select2-selection--multiple .select2-selection__choice
{
	background: none;
    border: none;
    border-radius: 0;
    margin-top: 17px;
    padding: 0 5px;
}

/* выбранные в списке */
.select2-container--default .select2-results__option[aria-selected=true] {
    background-color: #ef7f1a;
    color: white;
	text-align: center;
	font-weight: bold;
}

/* наведение на список */
.select2-container--default .select2-results__option--highlighted[aria-selected]
{
	background-color: #da771d;
    color: white;
}

/* поисковое поле */
.select2-container--default .select2-search--inline .select2-search__field {
    margin-top: 14px;
}

/* https://stackoverflow.com/questions/37943730/how-can-i-dynamically-resize-a-select2-input-to-be-the-same-width-as-the-selecte */
.select2-container {
    width: 100% !important;
}

/*-----------------------------------------------------------------------*/
/*             Валидация форм                                            */
/*-----------------------------------------------------------------------*/

.myTooltip {
    display: block;
    color: red;
    position: absolute;
    margin: 0;
	background: transparent;
    width: fit-content;
    font-size: 0.9em;
	top: calc(100% - 28px);
    left: 30px;
}
@media (max-width: <?php echo $w_767; ?>) {
  .myTooltip {
    top: calc(100% - 16px);
	left: 15px;
  }
}
.popup-form .myTooltip
{
    top: calc(100% - 19px);
}
@media (max-width: <?php echo $w_767; ?>) {
  .popup-form .myTooltip {
    top: calc(100% - 16px);
	left: 15px;
  }
}

.error {	
    border: 1px solid red;
    animation: simple-red-pulse infinite 1.5s;
	background: #ff000801;
}


/* анимация полей, отмеченных классом .error */
@keyframes simple-red-pulse {
  0% {
	  box-shadow: 0 0 0px 0px rgb(255, 255, 255), 0 0 0px 0px rgba(255, 0, 0, 0.5);
  }
  
  1% {
	  box-shadow: 0 0 0px 0px rgb(255, 255, 255), 0 0 1px 0px rgba(255, 0, 0, 0.5);
  }
 
  50% {
	  box-shadow: 0 0 0px 7px rgb(255, 255, 255), 0 0 0px 8px rgba(255, 0, 0, 0.0);
  }
}

/*bitrix24*/
	body div.b24-widget-button-position-bottom-right{
		right: 0;
		bottom: 0;
	}
	.b24-widget-button-wrapper .b24-widget-button-social.b24_adm {
		-webkit-animation: show .5s linear;
		animation: show .5s linear;
		display: block!important;
	}
	.b24-widget-button-wrapper .b24-widget-button-social.b24_adm {
		-webkit-animation: hide .5s linear;
		animation: hide .5s linear;
	}
	.b24-widget-button-inner-container{
		display: none!important;
	}
	.b24-adm-unbind {
		pointer-events: none;
	}
/*bitrix24*/

/************/
.headerBottomBorder .header-logo {
  width: 106px;
}
.headerBottomBorder .header-menu-link {
  width: 35px;
}
header.headerBottomBorder {
  padding: 5px 0;
}

header.headerBottomBorder .header-btn {
  width: 130px;
  height: 30px;
  line-height: 30px;
  font-size: 13px;
}
.header * {
  transition: 0.3s;
}
/************/
