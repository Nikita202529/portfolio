/*!
 * select3, GNU General Public License
 *
 * using jQuery
 * Author: S-a-n-d-r-0 (Alexander Kryuchkov), adm-center digital agency, Novocherkassk
 *
 * using jQuery
 * Date: 2019-08-27 17:25
 */

//ВХОДНЫЕ ПАРАМЕТРЫ:
//queryselector - селектор, по которому найти и применить скрипт. Применится к первому найденному.
//params - ассоциативный массив. Ключи:
//		params.optionsWrapClass			- имя класса обертки списка. По умолчанию S3_OptionsWrap. Тип string.
//		params.optionClass				- имя класса элемента списка. По умолчанию S3_Option. Тип string.
//		params.mainDisplayClass			- имя класса дисплея. По умолчанию S3_MainDisplay. Тип string.
//		params.arrowClass				- имя класса стрелки показать/скрыть на дисплее. По умолчанию S3_Arrow. Тип string.
//		params.mDisplay_n_ArrowWrapClass- имя класса обертки дисплея и стрелки. По умолчанию S3_MainDisplay_n_ArrowWrap. Тип string.
//		params.placeholderClass			- имя класса обертки placeholder'а. По умолчанию S3_Placeholder. Тип string.
//		params.eachValueWrapperClass	- нужно при params.addEachValueAsDiv == true. Имя класса обертки значения в MainDisplay, если каждое заносится в отдельный тег div. По умолчанию S3_EachValueWrapper. Тип string.
//		params.hiddenOptionsWrapClass	- имя класса, добавляемое на скрытую обертку списка, на стрелку показать/скрыть, на MainDisplay и на placeholder. По умолчанию hide. Тип string.
//		params.multipleChoiсe			- разрешить пользователю множественный выбор. По умолчанию false. Тип boolean.
//		params.allowNullChoice			- разрешить пользователю ничего не выбрать. По умолчанию false. Тип boolean.
//		params.focusWhenHover			- фокусироваться на элементе списка при наведении курсора мыши. По умолчанию true. Тип boolean.
//		params.addEachValueAsDiv		- добавить каждое значение в MainDisplay как отдельный тег div (когда == true). Когда == false, все значения записываются в одну строку через запятую. По умолчанию false. Тип boolean.
//		params.hidePlaceholderWhenShow	- скрывать placeholder при открытии списка, когда true. Если =false, скрывает только при изменении Value(). По умолчанию false. Тип boolean.
//		params.placeholderText			- текст placeholder'а. По умолчанию "". Тип string.
//МЕТОДЫ:
//(методы вызываются у экземпляра select3)
//		Show()		- показать весь список;
//		Hide()		- скрыть весь список;
//		Toggle()	- скроет список, если он открыт, и откроет, если он скрыт;
//		Value()		- возвращает значение;
//		CheckOnIndex(int index>=0)	- выберет указанный индекс. После этого сфокусируется на выбранном элементе, если список открыт.
//СОБЫТИЯ:
//(событие вызывает элемент с указанным в первом аргументе queryselector)
//		select3ValueChanged		- изменилось Value();
//		select3Shown			- открылся список;
//		select3Hidden			- список закрылся.
function select3(queryselector, params)
{	
	var _this = this;
	function select3execute() {
		//------------------------
		//Задаем входные параметры
		//------------------------
		
		//Значения по умолчанию
		let _optionsWrapClass = 'S3_OptionsWrap';
		let _optionClass = 'S3_Option';
		let _mainDisplayClass = 'S3_MainDisplay';
		let _arrowClass = 'S3_Arrow';
		let _mDisplay_n_ArrowWrapClass = 'S3_MainDisplay_n_ArrowWrap';
		let _placeholderClass = 'S3_Placeholder';
		let _eachValueWrapperClass = 'S3_EachValueWrapper';
		let _hiddenOptionsWrapClass = 'hide';
		let _multipleChoiсe = false;
		let _allowNullChoice = false;
		let _focusWhenHover = true;
		let _hidePlaceholderWhenShow = false;
		let _addEachValueAsDiv = false;
		let _placeholderText = "";
		
		//Пользовательские значения
		if (params)
		{
			if (params.optionsWrapClass)
				_optionsWrapClass = params.optionsWrapClass;
			if (params.mainDisplayClass)
				_mainDisplayClass = params.mainDisplayClass;
			if (params.arrowClass)
				_arrowClass = params.arrowClass;
			if (params.mDisplay_n_ArrowWrapClass)
				_mDisplay_n_ArrowWrapClass = params.mDisplay_n_ArrowWrapClass;	
			if (params.placeholderClass)
				_placeholderClass = params.placeholderClass;
			if (params.eachValueWrapperClass)
				_eachValueWrapperClass = params.eachValueWrapperClass;
			if (params.hiddenOptionsWrapClass)
				_hiddenOptionsWrapClass = params.hiddenOptionsWrapClass;
			
			if (params.multipleChoiсe === true)
				_multipleChoiсe = true;
			else
				_multipleChoiсe = false;
			
			if (params.allowNullChoice === true)
				_allowNullChoice = true;
			else
				_allowNullChoice = false;
				
			if (params.focusWhenHover === false)
				_focusWhenHover = false;
			else 
				_focusWhenHover = true;
			
			if (params.hidePlaceholderWhenShow === true)
				_hidePlaceholderWhenShow = true;
			else
				_hidePlaceholderWhenShow = false;
			
			if (params.addEachValueAsDiv === true)
				_addEachValueAsDiv = true;
			else
				_addEachValueAsDiv = false;
				
			if (params.placeholderText)
				_placeholderText = params.placeholderText;
		}
		
		//------------------------
		//Вспомогательные функции
		//------------------------
		
		//создает элемент по заданному outerHTML
		function createElement(elementOuterHTML)
		{
			var e = document.createElement('div');
			e.innerHTML = elementOuterHTML;
			return e.childNodes;
		}
		
		//сменить тег элемента на указанный
		function switchTag(e, toTag) {
			var outerHTML = e.outerHTML.replace(/(\r\n|\n|\r)/gm, ""); // удалить все символы переноса строки
			outerHTML = outerHTML.replace(/^<([a-z]*)(.*?)>(.*)<\/\1>$/ig, '<' + toTag + '$2>$3</' + toTag + '>');
			return createElement(outerHTML);
		};
		
		//первый элемент, удовлетворяющий заданному селектору
		let select3 = $(queryselector)[0];
		
		let DS3 = switchTag(select3, 'div');
		
		let AllOption3s = $(DS3).find('option');
		$(DS3).empty();
		
		//окно, в которое выводится результат
		let MainDisplay = document.createElement('div');
		$(MainDisplay).attr("class", _mainDisplayClass);
		$(MainDisplay).attr("tabindex", 0);
		//обертка для списка
		let OptionsWrap = document.createElement('div');
		$(OptionsWrap).attr("class", _optionsWrapClass);
		//placeholder
		let placeholder = document.createElement('div');
		$(placeholder).attr("class", _placeholderClass);
		$(placeholder).append(_placeholderText);
		
		//событие изменения значения. Подготовка события. select3ValueChanged
		var _select3ValueChangedEvent = document.createEvent('Event'); // Создание события
		_select3ValueChangedEvent.initEvent('select3ValueChanged', true, true); // Назначить имя событию
		
		//событие список показан. Подготовка события. select3Shown
		var _select3ShownEvent = document.createEvent('Event'); // Создание события
		_select3ShownEvent.initEvent('select3Shown', true, true); // Назначить имя событию
		
		//событие список скрыт. Подготовка события. select3Shown
		var _select3HiddenEvent = document.createEvent('Event'); // Создание события
		_select3HiddenEvent.initEvent('select3Hidden', true, true); // Назначить имя событию
		
		//Массив выбранных индексов, array[int], формируется в порядке добавления индексов. НЕ предусматривается, что может быть равен null
		var _selectedIndices = [];//Для реализации управления клавиатурой (клавишами ↑ и ↓) и не только. Для атрибута select3-index (причем нумерация с разницей в единицу)

		//генерирует click по элементу
		//Используется для checkOnIndex
		/*
		function eventFire(el, etype){ //взято с https://stackoverflow.com/questions/2705583/how-to-simulate-a-click-with-javascript
			if (el.fireEvent) {
				el.fireEvent('on' + etype);
				} else {
				var evObj = document.createEvent('Events');
				evObj.initEvent(etype, true, false);
				el.dispatchEvent(evObj);
			}
		}
		*/
		function checkOnIndex(index) //вспомогательная. Для реализации управления клавиатурой (клавишами ↑ и ↓). 
		{
			if (index < 0 || index > AllOption3s.length - 1) return;
			let qs = queryselector + " ." + _optionsWrapClass + " ." + _optionClass + "[select3-index = '" + (index + 1) + "']";
			let opt = document.querySelector(qs);
			if (!opt) return;
			chooseOption(opt); //eventFire(opt, 'click');
			if (hideState === false)
				focusOnIndex(index); //сфокусироваться на выбранном элементе
		}
		// нестатическая Функция CheckOnIndex(int index>=0) экземпляра select3
		_this.CheckOnIndex = function (index)
		{
			checkOnIndex(index);
		}
		function focusOnIndex(index) //вспомогательная. Для реализации управления клавиатурой (клавишами ↑ и ↓). 
		{
			if (index < 0 || index > AllOption3s.length - 1) return;
			let qs = queryselector + " ." + _optionsWrapClass + " ." + _optionClass + "[select3-index = '" + (index + 1) + "']";
			let opt = document.querySelector(qs);
			opt.focus();
			//opt.scrollIntoView(); //прокрутить полосу прокрутки обертки до этого элемента (срабатывает само по умолчанию, но не всегда)
		}
		
		var value = "";
		// нестатическая Функция Value() экземпляра select3
		_this.Value = function () {
			return value;
		};
		
		//обновляет innerHTML и value у MainDisplay
		function changeMainDisplay()
		{
			let innerHTMLtext = "";
			let valueText = ""; //строка со значениями через запятую
			let valuesArr = []; //массив значений (для _addEachValueAsDiv)
			let indArr = []; //массив соответствующих значениям индексов элементов списка
			let sortedSelectedIndices = _selectedIndices.slice(0); //клонируем массив
			sortedSelectedIndices.sort(function(a, b) { return a - b; }); //сортируем. Без функции сортировки отсортирует как символы
			
			//готовим значения innerHTML и value, записывая в переменные innerHTMLtext и valueText
			for (let so3i = 0; so3i < sortedSelectedIndices.length; so3i++)
			{
				let index = sortedSelectedIndices[so3i];
				let qs = queryselector + " ." + _optionsWrapClass + " ." + _optionClass + "[select3-index = '" + (index + 1) + "']";
				let opt = document.querySelector(qs);
				
				//добавляем innerHTML
				innerHTMLtext += (so3i == 0) ? opt.innerHTML : ", " + opt.innerHTML;
				
				//добавляем value
				let valAttr = $(opt).attr('value');
				let val = (typeof valAttr != typeof undefined && valAttr != false) ? valAttr : opt.innerHTML;
				valueText += (so3i == 0) ? val : ", " + val;
				valuesArr.push(val); //массив значений (для _addEachValueAsDiv)
				indArr.push(index); //массив исходных индексов
			}
			
			value = valueText;
			
			$(MainDisplay).empty(); //очищаем innerHTML
			$(MainDisplay).attr("value", ""); //очищаем value
			
			 //добавляем подготовленные значения
			if (_addEachValueAsDiv)
			{
				for (let vd3i = 0; vd3i < valuesArr.length; vd3i++)
				{
					let valDiv = document.createElement('div');
					$(valDiv).attr("class", _eachValueWrapperClass);
					
					$(valDiv).attr("select3-option-index", (indArr[vd3i] + 1));
					$(valDiv).append(valuesArr[vd3i]);
					$(MainDisplay).append(valDiv);
				}
			}
			else
			{
				$(MainDisplay).append(innerHTMLtext);
			}
			$(MainDisplay).attr("value", valueText);
			
			if (_hidePlaceholderWhenShow === false)
			{
				$(placeholder).removeClass(_hiddenOptionsWrapClass);
			}
			if (valueText || innerHTMLtext)
					$(placeholder).addClass(_hiddenOptionsWrapClass);
		}
		
		//последний сфокусированный элемент списка
		var lastFocusedOption = null;
		
		//var _this = this;
		
		//Выбирает нужный элемент списка. 
		//Эффект как от щелчка по нему
		//opt - элемент списка
		function chooseOption(opt)
		{
			let indAttr = $(opt).attr('select3-index');
			let clickedIndex = (typeof indAttr != typeof undefined && indAttr != false) ? indAttr - 1 : -1; //Разница в 1 !!!!
			if (clickedIndex == -1) return;
			let ValueChanged = (_selectedIndices.length == 0 || _selectedIndices.indexOf(clickedIndex) == -1);

			if (ValueChanged == false)
			{
				if (_allowNullChoice === true || ((_multipleChoiсe === true) && (_selectedIndices.length > 1)))
				{
					//снять вывыбор, если выбран повторно
					$(opt).removeAttr('checked');
					
					//Убираем индекс элемента из _selectedIndices
					_selectedIndices.splice(_selectedIndices.indexOf(clickedIndex), 1);
					
					changeMainDisplay();
					
					//открывает список (вызывая соб. focused)
					hide();
					
					//Вызов события select3ValueChanged, т.к. значение изменилось (стало null, если _multipleChoiсe == false, стало другим или null, если _multipleChoiсe == true)
					$(queryselector)[0].dispatchEvent(_select3ValueChangedEvent);
				}
			}
			else if (ValueChanged == true)
			{
				//не зависит от _allowNullChoice
				
					if (_multipleChoiсe === false)
					{
						$(opt).parent().children().removeAttr('checked'); //если _multipleChoiсe == false
					}
					opt.setAttribute('checked', '');
					
					
					//Меняем _selectedIndices
					if (_multipleChoiсe === false)
					{
						_selectedIndices = []; //если _multipleChoiсe == false
					}
					_selectedIndices.push(clickedIndex);
					
					changeMainDisplay();
					
					hide();
					
					//Вызов события select3ValueChanged
					$(queryselector)[0].dispatchEvent(_select3ValueChangedEvent);
			}
		}
		
		for (let option3i = 0; option3i < AllOption3s.length; option3i++)
		{
			let option3 = AllOption3s[option3i];
			
			let DO3 = switchTag(option3, 'div');
			$(DO3).addClass(_optionClass);
			$(DO3).attr("tabindex", 0);
			$(DO3).attr("select3-index", option3i + 1); // собственный аттрибут индекса. Вспомогательный. Для реализации управления клавиатурой (клавишами ↑ и ↓). Для _selectedIndices.
			//select3-index = selectedIndex + 1. !!!!!!!   selectedIndex = select3-index - 1 !!! - КОСТЫЛЬ--------------
			
			//Для lastFocusedOption (для того, чтобы зафиксировать последний сфокусированный элемент списка)
			$(DO3).on("focus", function () {
				lastFocusedOption = this;
			});
			
			if (_focusWhenHover)
			{
				$(DO3).on("mouseenter", function () {
					this.focus();
				});
			}
			
			//если у option атрибута 'value' нет, то ставим этот атрибут равным innerHTML
			let ValueAttr = $(DO3).attr('value');
			if (typeof ValueAttr == typeof undefined || ValueAttr == false)
				$(DO3).attr("value", DO3[0].innerHTML);
			
			$(DO3).on("click", function () {
				chooseOption(this);
			});
			$(OptionsWrap).append(DO3);
		}
		
		let MainDisplay_n_ArrowWrap = document.createElement('div');
		$(MainDisplay_n_ArrowWrap).attr("class", _mDisplay_n_ArrowWrapClass);

		//стрелка показать/скрыть
		let arrow = document.createElement('div');
		$(arrow).attr("class", _arrowClass);
		
		$(MainDisplay_n_ArrowWrap).append(arrow);

		//placeholder
		$(MainDisplay_n_ArrowWrap).append(placeholder);
		
		//=true, если список скрыт, = false иначе
		let hideState;// = true;
		
		function show() {
			let hideStateChanged = (hideState !== false);
			hideState = false;
			$(OptionsWrap).removeClass(_hiddenOptionsWrapClass);
			$(arrow).removeClass(_hiddenOptionsWrapClass);
			$(MainDisplay).removeClass(_hiddenOptionsWrapClass);
			//Сфокусироваться на последнем выбранном индексе, а если выбранных индексов нет, то сфокусироваться на первом
			let indToFocus = (_selectedIndices.length == 0) ? 0 : _selectedIndices[_selectedIndices.length - 1];
			focusOnIndex(indToFocus);
			
			if (_hidePlaceholderWhenShow === true)
				$(placeholder).addClass(_hiddenOptionsWrapClass);
			
			if (hideStateChanged === true)
				$(queryselector)[0].dispatchEvent(_select3ShownEvent); //Вызов события select3Shown
		};
		// нестатическая Функция Show() экземпляра select3
		_this.Show = function ()
		{
			show();
		}
		
		function hide() {
			let hideStateChanged = (hideState !== true);
			hideState = true;
			$(OptionsWrap).addClass(_hiddenOptionsWrapClass);
			$(arrow).addClass(_hiddenOptionsWrapClass);
			$(MainDisplay).addClass(_hiddenOptionsWrapClass);
			
			if (hideStateChanged === true)
				$(queryselector)[0].dispatchEvent(_select3HiddenEvent); //Вызов события select3Hidden
			
			if (_hidePlaceholderWhenShow === true)
				if (!value)
					$(placeholder).removeClass(_hiddenOptionsWrapClass);
		};
		// нестатическая Функция Show() экземпляра select3
		_this.Hide = function ()
		{
			hide();
		}
		
		//скроет список, если он открыт, и откроет, если он скрыт
		function toggle() {
			if (hideState == true)
				show();
			else
				hide();
		};
		// нестатическая Функция Toggle() экземпляра select3
		_this.Toggle = function ()
		{
			toggle();
		}
		
		$(arrow).on("click", function (event) {
			event.stopPropagation();
			toggle();
		});
		
		$(MainDisplay_n_ArrowWrap).append(MainDisplay);
		$(DS3).append(MainDisplay_n_ArrowWrap);
		$(DS3).append(OptionsWrap);
		
		hide();
		
		$(MainDisplay_n_ArrowWrap).on("click", function () {
					show();
					});
		
		$(select3).parent().append(DS3);
		$(select3).remove();
		
		// Если click вне элемента - список скрывается
		document.addEventListener('click', function( e ) {
			let target = e.target;
			
			let its_select3 = target == $(queryselector)[0] || $(queryselector)[0].contains(target);
			
			if (!its_select3)
				hide();
		});
		
		/*
		//при фокусе на весь элемент $(queryselector) сразу откроется и сфокусируется на первом
		$(queryselector).on('focus', function(event) {
			//Сфокусироваться на последнем выбранном индексе, а если выбранных индексов нет, то сфокусироваться на первом
			//let indToFocus = (_selectedIndices.length == 0) ? 0 : _selectedIndices[_selectedIndices.length - 1];
			show();
			//focusOnIndex(indToFocus);
		});
		*/
		
		//Управление клавиатурой
		$(queryselector).attr('tabindex', '0');	
		$(queryselector).on('keydown', function(event) {
		
			if (hideState == true) //если список скрыт
			{
				if (event.keyCode == "9") /*tab*/
				{
					show();
					event.stopPropagation();
					event.preventDefault();
				}
				else if (event.keyCode == "13" /*enter*/
							|| event.keyCode == "38" /*up*/
							|| event.keyCode == "37" /*left*/
							|| event.keyCode == "40" /*down*/
							|| event.keyCode == "39" /*right*/)
				{
					show();
				}
			}
			else if (hideState == false) //если список открыт
			{
				if (event.keyCode == "13") //enter
				{
					let opt = lastFocusedOption; //ищем элемент с фокусом (при открытии обязательно сфокусируется на какой-то option)
					let indexAttr = $(opt).attr('select3-index'); //ищем у него аттрибут select3-index
					if (typeof indexAttr != typeof undefined && indexAttr != false)
						checkOnIndex(indexAttr - 1);
				}
				
				if (event.keyCode == "38" /*up*/
					|| event.keyCode == "37" /*left*/)
				{
					let opt = lastFocusedOption; //ищем элемент с фокусом (при открытии обязательно сфокусируется на какой-то option)
					let indexAttr = $(opt).attr('select3-index'); //ищем у него аттрибут select3-index
					if (typeof indexAttr != typeof undefined && indexAttr != false)
						focusOnIndex((indexAttr - 1) - 1);
				}
				
				if (event.keyCode == "40" /*down*/
					|| event.keyCode == "39" /*right*/)
				{
					let opt = lastFocusedOption; //ищем элемент с фокусом (при открытии обязательно сфокусируется на какой-то option)
					let indexAttr = $(opt).attr('select3-index'); //ищем у него аттрибут select3-index
					if (typeof indexAttr != typeof undefined && indexAttr != false)
						focusOnIndex((indexAttr - 1) + 1);
				}				
			}
		});

		//Выбрать те элементы списка, которые уже отмечены checked
		let qs = "." + _optionClass + "[checked]";
		let newOptions = OptionsWrap.querySelectorAll(qs);
		for (let o3i = 0; o3i < newOptions.length; o3i++)
		{
			let opt = newOptions[o3i];
			let checkedAttr = $(opt).attr('checked'); //ищем у него аттрибут checked
			if (typeof checkedAttr != typeof undefined && checkedAttr != false)
			{
				let indexAttr = $(opt).attr('select3-index'); //ищем у него аттрибут select3-index
				if (typeof indexAttr != typeof undefined && indexAttr != false)
					checkOnIndex((indexAttr - 1));
			}
		}
	}
	
	//https://stackoverflow.com/questions/14644558/call-javascript-function-after-script-is-loaded
	function loadScript( url, callback ) {
		var script = document.createElement( "script" )
		script.type = "text/javascript";
		if(script.readyState) {  // only required for IE <9
			script.onreadystatechange = function() {
				if ( script.readyState === "loaded" || script.readyState === "complete" ) {
					script.onreadystatechange = null;
					callback();
				}
			};
		} else {  //Others
				script.onload = function() {
				callback();
			};
		}

		script.src = url;
		document.getElementsByTagName( "head" )[0].appendChild( script );
	}
	
	//если нет jQuery, подключаем его
	if (!window.jQuery)
	{
		loadScript('https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js', select3execute);
		console.log("select3: jQuery was not found. The jquery 3.4.1 was loaded.");
		return;
	}
	else
		select3execute();
}