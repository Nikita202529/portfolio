﻿<!DOCTYPE html>
<html lang="ru">
	<head>
		<meta charset="UTF-8">
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	
		<title>Техподдержка сайтов на 1С-Битрикс</title>	
		<link rel="icon" href="favicon.ico" type="image/x-icon">
		<!-- Bootstrap -->
		<!--link href="css/bootstrap.css" rel="stylesheet"-->
		<!--link href="css/bootstrap_modified_16.07.19.php" rel="stylesheet"-->
		<link href="css/bootstrap_modified_16.07.19.min.css" rel="stylesheet">
		<!-- Custom -->
		<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800&amp;subset=cyrillic" rel="stylesheet">
		
		<!--link rel="stylesheet" href="css/style.php"-->
		<link rel="stylesheet" href="css/style.min.css">
		
	</head>

<!-- виджет -->
<script>
        (function(w,d,u){
               var s=d.createElement('script');s.async=true;s.src=u+'?'+(Date.now()/60000|0);
               var h=d.getElementsByTagName('script')[0];h.parentNode.insertBefore(s,h);
       })(window,document,'https://cdn.bitrix24.ru/b97479/crm/site_button/loader_2_by2fyy.js');
</script>
<!-- конец -- виджет -->	
	
	<body>
	    
<!-- Yandex.Metrika counter -->
<script type="text/javascript" >
   (function(m,e,t,r,i,k,a){m[i]=m[i]||function(){(m[i].a=m[i].a||[]).push(arguments)};
   m[i].l=1*new Date();k=e.createElement(t),a=e.getElementsByTagName(t)[0],k.async=1,k.src=r,a.parentNode.insertBefore(k,a)})
   (window, document, "script", "https://mc.yandex.ru/metrika/tag.js", "ym");

   ym(54779350, "init", {
        clickmap:true,
        trackLinks:true,
        accurateTrackBounce:true,
        webvisor:true
   });
</script>
<noscript><div><img src="https://mc.yandex.ru/watch/54779350" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
<!-- /Yandex.Metrika counter -->
	          
		<div class="wrap">
			
			
		  <div class="hamburger"></div>
			
		  <div class="menu">
		  <div class="container-fluid pl-0 pr-0 h-100">
		  <div class="row no-gutters h-100">
		  <div class="col-12">
				<!-- лого и стрелочка -->
				<div class="menu-top">
					<div class="menu-top_arrow"></div>
				  <div class="menu-logo">
						<img src="img/header/logo-white.svg" alt="ADM">
				  </div>
				</div>
				<!-- ./menu-top -->
		  
				<ul class="menu-list">
				  <li class="menu-item">
					<a href="#aboutServices" class="menu-link btn-scroll">
					  Что мы предлагаем
					</a>
				  </li>
				  <!-- li -->
				  <li class="menu-item">
					<a href="#subscription" class="menu-link btn-scroll">
					  Постоянная техподдержка
					</a>
				  </li>
				  <!-- li -->
				  <li class="menu-item">
					<a href="#support" class="menu-link btn-scroll">
					  Почасовая оплата
					</a>
				  </li>
				  <!-- li -->
				  <li class="menu-item">
					<a href="#support-services" class="menu-link btn-scroll">
					  Услуги техподдержки
					</a>
				  </li>
				  <!-- li -->
				  <li class="menu-item">
					<a href="#recommend" class="menu-link btn-scroll">
					  Как мы работаем
					</a>
				  </li>
				  <!-- li -->
				  <li class="menu-item">
					<a href="#calculation" class="menu-link btn-scroll">
					  Оставить заявку
					</a>
				  </li>
				  <!-- li -->
				  <li class="menu-item">
					<a href="#footer" class="menu-link btn-scroll">
					  Контакты
					</a>
				  </li>
				  <!-- li -->          
				</ul>
				<!-- ul -->
				
				<div class="menu-social">
				<div class="menu-socials-wrap">
						<a href="https://www.facebook.com/admcenter.ru/"><span class="icon-facebook"></span></a>
						<!--a href="#"><span class="icon-vkontakte"></span></a-->
						<!--a href="#"><span class="icon-odnoklassniki"></span></a-->
						<!--a href="#"><span class="icon-twitter"></span></a-->
						<a href="tg://resolve?domain=admasya"><span class="icon-telegram"></span></a>
						<a href="https://www.instagram.com/admcenter/"><span class="icon-instagram"></span></a>
						<a href="whatsapp://send?phone=+79281631100"><span class="icon-whatsapp"></span></a>
						<a href="viber://add?number=79281631100"><span class="icon-viber-brands"></span></a>
						<!--a href="#"><span class="icon-pinterest"></span></a-->
				</div>
				</div>
		  </div>
		  </div>
		  </div>
		  </div>
		  <!-- ./menu -->
		  
		  <div class="scrollcontent">
			<header class="header">
			  <div class="container">
				<div class="row align-items-center">
				  <div class="col-6 col-sm-4 col-md-6 col-lg-4">
					<div class="row align-items-end">
					  <div class="col-5 col-sm-6 col-md-4 col-lg-6">
						<!-- тут был гамбургер -->
					  </div>

					  <div class="col-7 col-sm-6 col-md-8 col-lg-6"> 
						<div href="http://adm-center.ru/" class="header-logo">
						  <img src="img/header/logo.svg" alt="ADM">
						</div>
					  </div>
					</div>
				  </div>

				  <div class="col-6 col-sm-8 col-md-6 col-lg-8 d-flex justify-content-end align-items-center">
					<a class="header-phone header-phone__mhidden" href="tel:+7(863)226-90-95">+7 (863) 226-90-95</a>
					<a class="header-btn btn-scroll button" href="#calculation">Оставить заявку</a>
					<!-- <button type="button" class="header-btn button" title>
					  Оставить заявку
					</button> -->
				  </div>
				</div>
				<!-- /.row -->
			  </div>
			  <!-- /.container -->
			</header>
			<!-- /.header -->

			<div class="highlights">
			  <div class="container">
				<div class="row">
				  <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
					<div class="row justify-content-center">
					  <div class="col-12 col-sm-11 col-md-12 col-lg-12 col-xl-12">
						<h1 class="title-main">Техническая поддержка сайтов на 1С&#8209;Битрикс</h1>
					  </div>
					  <!-- /.col-12 -->
					</div>
					<!-- /.row -->
					
				  </div>
				  <!-- /.col-12 -->
				</div>
				<!-- /.row -->
				<div class="row align-items-center">
				  <div class="col-12 col-sm-12 col-md-5 col-lg-4 col-xl-4 order-2 order-md-0">
					<div class="highlights-items d-flex justify-content-center justify-content-md-start">
					  <ul>
						<li class="d-flex align-items-center justify-content-start">
						  <div class="highlights_blue">11</div>
						  <div class="highlights-items__descr">11 лет опыта разработки сайтов</div>
						</li>
						<li class="d-flex align-items-center justify-content-start">
						  <div class="highlights_blue">15</div>
						  <div class="highlights-items__descr">15 специалистов, готовых вам помочь</div>
						</li>
						<li class="d-flex align-items-center justify-content-start">
						  <div class="highlights_blue">50</div>
						  <div class="highlights-items__descr">Более 50 проектов на техподдержке</div>
						</li>
					  </ul>
					</div>
				  </div>
				  <!-- /.col-6 -->
				  <div class="col-12 col-sm-12 col-md-7 col-lg-8 col-xl-8 pl-lg-0 pb-4 pb-sm-5 pb-md-0">                  
					<div class="row align-items-center">
					  <div class="col-9 col-sm-8 col-md-9 col-lg-9 col-xl-9 pr-xl-5 pl-md-0 d-flex justify-content-start justify-content-lg-center justify-content-xl-end align-items-center">
						<div class="highlights-img">
						  <img src="img/support/support-adm.png" alt="Техподдержка ADM">
						</div>
						<!-- /.highlights-img -->
					  </div>
					  <!-- /.col-12 -->
					  <div class="col-3 col-sm-4 col-md-3 col-lg-3 col-xl-3 pl-0 d-flex justify-content-center">
						<div class="h-our_awards">
						  <ul class="d-flex flex-column justify-content-center">
							<li>
							  <a href="https://www.1c-bitrix.ru/partners/293096.php" target="_blank"><img src="img/support/gold-partner.jpg" alt="1C-Bitrix Gold Partner" title="Золотой партнер 1С-Битрикс"></a>
							</li>
							<li>
							  <a href="https://www.1c-bitrix.ru/partners/293096.php" target="_blank"><img src="img/support/monitoring.jpg" alt="Monitoring Participant" title="Участник программы качества внедрений 1С-Битрикс"></a>
							</li>
							<li>
							  <a href="https://www.1c-bitrix.ru/partners/293096.php" target="_blank"><img src="img/support/kompozit.jpg" alt="Kompozit" title="Композитный сайт"></a>
							</li>
							<li>
							  <a href="https://www.1c-bitrix.ru/partners/293096.php" target="_blank"><img src="img/support/1c.jpg" alt="1c-integration" title="Интеграция с 1С"></a>
							</li>
						  </ul>
						</div>
						<!-- /.header-middle-sale -->
					  </div>
					  <!-- /.col-5 -->
					</div>
					<!-- /.row -->
				  </div>
				  <!-- /.col-6 -->
				</div>
				<!-- /.row -->
			  </div>
			  <!-- /.container -->
			</div>
			<!-- /.highlights -->
			
			<section id="aboutServices" class="about-services">
			<a name="aboutServices"></a><!--якорь-->
			  <div class="container">
				<div class="row">
				  <div class="col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
					<div class="row justify-content-center">
					  <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
						<div class="about-services-desc">
						<div class="about-services-desc-content">
						  <h2 class="about-services-title">Ежемесячная техподдержка</h2>

						  <!-- <div class="about-services-subtitle">Подходит для:</div> -->
						  <div class="about-services-price">
							<span>от</span> 1800 <span>руб/мес</span>
						  </div>
						  <div class="title-desc d-flex align-items-center">
							<div class="d-flex align-items-center"><img src="img/done.png" alt="#"></div>
							Для небольших проектов
						  </div>
						  <div class="title-desc d-flex align-items-center">
							<div class="d-flex align-items-center"><img src="img/done.png" alt="#"></div>
							Если нет своего системного администратора
						  </div>
						  <!-- <h3 class="title-desc-time">Время реакции на заявку 15 мин</h3> -->
						  <div class="support-bonus">
							Перенос сайта на наш сервер БЕСПЛАТНО!
						  </div>
						  <div class="about-services__btn d-flex justify-content-center">
							<a class="button btn-scroll support-detail__btn" href="#subscription">Подробнее</a>
						  </div>
						  <!-- /.about-services__btn -->
						</div>
						</div>
						<!-- /.about-services-desc -->
					  </div>
					  <!-- /.col-12 -->
					</div>
					<!-- /.row -->
				  </div>
				  <!-- /.col-6 -->

				  <div class="col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
					<div class="row justify-content-center">
					  <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
						<div class="about-services-desc">
						<div class="about-services-desc-content">
						  <h2 class="about-services-title">Почасовая разработка</h2>

						  <!--  <div class="about-services-subtitle">Подходит для:</div> -->
						  <div class="about-services-price">
							<span>от</span> 1200 <span>руб/ч</span>
						  </div>
						  <div class="title-desc d-flex align-items-center">
							<div class="d-flex align-items-center"><img src="img/done.png" alt="#"></div>
							Для крупных проектов
						  </div>
						  <div class="title-desc d-flex align-items-center">
							<div class="d-flex align-items-center"><img src="img/done.png" alt="#"></div>
							Если не хватает собственных IT-специалистов
						  </div>
						  <!-- <h3 class="title-desc-time">Время реакции на заявку до 24 часов</h3> -->
						  <div class="support-bonus">
							СКИДКИ до 20% при внесении депозита
						  </div>

						  <div class="about-services__btn d-flex justify-content-center">
							<a class="button btn-scroll support-detail__btn" href="#support">Подробнее</a>
						  </div>
						  <!-- /.about-services__btn -->
						</div>
						</div>
						<!-- /.about-services-desc -->
					  </div>
					  <!-- /.col-9 -->
					</div>
					<!-- /.row -->
				  </div>
				  <!-- /.col-6 -->
				</div>
				<!-- /.row -->
			  </div>
			  <!-- /.container -->
			</section>
			<!-- /.about-service -->

			<section id="subscription" class="subscription">
			<a name="subscription"></a><!--якорь-->
			  <div class="container">  
				<div class="row">
				  <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
					<div class="row align-items-center">
					  <div class="col-12 col-md-6 col-lg-6 col-xl-6 d-none d-md-flex justify-content-center">
						<div class="subscription-img">
						  <img src="img/support/subscription-fee.png" alt="Постоянная поддержка">
						</div>
						<!-- /.subscription-img -->
					  </div>
					  <!-- /.col-6 -->
					  <div class="col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
						<div class="subscription-desc">
						  <div class="subscription-bg title-bg">subscription fees</div>
						  <div class="title-before">Ежемесячная поддержка</div>
						  <h2 class="title">Абонентская плата</h2>

						  <div class="title-desc d-flex align-items-center">
							<div class="d-flex align-items-center"><img src="img/done.png" alt="#"></div>
							Заботимся о жизнеспособности сайта
						  </div>
						  <div class="title-desc d-flex align-items-center">
							<div class="d-flex align-items-center"><img src="img/done.png" alt="#"></div>
							Ставим регулярные задачи на поток
						  </div>
						  <div class="title-desc d-flex align-items-center">
							<div class="d-flex align-items-center"><img src="img/done.png" alt="#"></div>
							Отчитываемся о выполненных работах
						  </div>
						  <div class="support-price">
							<span>от</span> 1800 <span>руб/мес</span> 
						  </div>
						  <div class="support-bonus">
							Перенесём ваш сайт на наши сервера БЕСПЛАТНО!
						  </div>
						  <button class="button" data-toggle="modal" data-target="#ModalLong">Отправить заявку</button>
						</div>
						<!-- /.subscription-desc -->
					  </div>
					  <!-- /.col-6 -->
					</div>
					<!-- /.row -->
				  </div>
				  <!-- /.col-12 -->

				  <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
					<div class="subscription-block">
					  <div class="row align-items-start">
                    <div class="col-12 col-lg-6 col-xl-6">
                      <div class="subscription-table__scroll">
                        <div class="subscription-table">
                          <div class="s-table_name">
                            <div class="table_name-blue">Тарифы</div>
                            <div class="table_name-blue">Стандарт</div>
                            <div class="table_name-blue">Эксперт</div>
                            <div class="table_name-blue">Бизнес</div>
                            <div class="table_name-blue">Бизнес Pro</div>
                          </div>
                          <div class="s-table_row">
                            <div class="table_row-grey t-dark_grey">Количество часов</div>
                            <div class="table_row-grey t-middle_grey">1 ч</div>
                            <div class="table_row-grey t-middle_grey">4 ч</div>
                            <div class="table_row-grey t-middle_grey">16 ч</div>
                            <div class="table_row-grey t-middle_grey">36 ч</div>
                          </div>
                          <div class="s-table_row">
                            <div class="table_row-grey t-middle_grey">Лендинг/Сайт-визитка</div>
                            <div class="table_row-grey">1800 р</div>
                            <div class="table_row-grey">7200 р</div>
                            <div class="table_row-grey">– </div>
                            <div class="table_row-grey">– </div>
                          </div>
                          <div class="s-table_row">
                            <div class="table_row-grey t-middle_grey">Корпоративный сайт/<br>Сайт-каталог</div>
                            <div class="table_row-grey">2400 р</div>
                            <div class="table_row-grey">7800 р</div>
                            <div class="table_row-grey">23200 р</div>
                            <div class="table_row-grey">– </div>
                          </div>
                          <div class="s-table_row">
                            <div class="table_row-grey t-middle_grey">Интернет-магазин</div>
                            <div class="table_row-grey">2800 р</div>
                            <div class="table_row-grey">8200 р</div>
                            <div class="table_row-grey">23600 р</div>
                            <div class="table_row-grey">48200 р</div>
                          </div>
                        </div>
                      </div>
                    </div>

						<div class="col-12 col-lg-6 col-xl-6">
						  <div class="subscription-advant">
							<div class="subscription-advant__title">
							  Когда нужен контроль текущих задач
							</div>

								<p>Отлаженный процесс взаимодействия Клиент-Менеджер-Специалист.</p>
		                        <b>Вам не нужно думать о том, а вдруг если… Вашу заботу по работе сайта и с сайтом мы берем на себя.</b> 
		                        <br><br>
		                        <p>Размещаем сайт на сервере. 
		                          Контролируем работоспособность сайта. </p>
		                          Вовремя продлеваем домены/лицензии Битрикс (успеваем в скидку 60%).<br><br>
		                          
		                          <p>Обновляем установленные модули и решения.
		                          Подсказываем, что и где можно улучшить.</p>
						  </div>
						</div>
					  </div>
					  <!-- /.row -->
					</div>
					<!-- /.subscription-block -->
				  </div>
				  <!-- /.col-12 -->
				  
				  <div class="col-12 col-sm-12 col-md-12 col-lg-6 col-xl-6">
					<button class="button" data-toggle="modal" data-target="#ModalLong">Отправить заявку</button>
				  </div>
				</div>
				<!-- /.row -->
			  </div>
			  <!-- /.container -->
			</section>
			<!-- /.subscription -->

			<section id="support" class="support">
			<a name="support"></a><!--якорь-->
			  <div class="container">
				<div class="row">
				  <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
					<div class="row align-items-center align-items-xl-center">
					  <div class="col-12 col-md-6 col-lg-6 col-xl-6">
						<div class="support-desc">
						  <div class="support-bg title-bg">Hourly Pay</div>
						  <div class="title-before support-title-before">Всегда на связи</div>
						  <h2 class="title">Почасовая оплата</h2>
						  <div class="title-desc d-flex align-items-center">
							<div class="d-flex align-items-center"><img src="img/done.png" alt="#"></div>
							Реализовываем нестандартные решения через типовые возможности 1С-Битрикс
						  </div>
						  <div class="title-desc d-flex align-items-center">
							<div class="d-flex align-items-center"><img src="img/done.png" alt="#"></div>
							Разрабатываем и внедряем новый функционал
						  </div>
						  <div class="title-desc d-flex align-items-center">
                        <div class="d-flex align-items-center"><img src="img/done.png" alt="#"></div>
                        Консультируем и поддерживаем в процессе ведения проекта
                      </div>
						  <div class="support-price">
							<span>от</span> 1200 <span>руб/ч</span>
						  </div>
						  <div class="support-bonus">
						   Проработаем решение ПОД ВАШИ ЦЕЛИ
						  </div>
						  <a class="button btn-scroll" href="#calculation">Рассчитать стоимость</a>
						</div>
						<!-- /.support-desc -->
					  </div>
					  <!-- /.col-6 -->

					  <div class="col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6 d-none d-md-flex justify-content-center">
						<div class="support-img d-flex align-items-center">
						  <img src="img/support/hourly-fee.png" alt="Техническая поддержка">
						</div>
						<!-- /.support-img -->
					  </div>
					  <!-- /.col-6 -->
					</div>
					<!-- /.row -->
				  </div>
				  <!-- /.col-12 -->    

				  <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
					<div class="subscription-block">
					  <div class="row align-items-start">
						<div class="col-12 col-lg-6 col-xl-6">
	                      <div class="subscription-table__scroll">
	                        <div class="subscription-table">
	                          <div class="s-table_name">
	                            <div class="table_name-blue">Тарифы</div>
	                            <div class="table_name-blue">Стандарт</div>
	                            <div class="table_name-blue">Базовый</div>
	                            <div class="table_name-blue">Бизнес</div>
	                            <div class="table_name-blue">Бизнес Pro</div>
	                          </div>
	                          <div class="s-table_row">
	                            <div class="table_row-grey t-dark_grey">Количество часов</div>
	                            <div class="table_row-grey t-middle_grey">10</div>
	                            <div class="table_row-grey t-middle_grey">30</div>
	                            <div class="table_row-grey t-middle_grey">50</div>
	                            <div class="table_row-grey t-middle_grey">70</div>
	                          </div>
	                          <div class="s-table_row">
	                            <div class="table_row-grey t-middle_grey">Стоимость депозита, руб</div>
	                            <div class="table_row-grey">17000</div>
	                            <div class="table_row-grey">45000</div>
	                            <div class="table_row-grey">70000</div>
	                            <div class="table_row-grey">84000</div>
	                          </div>
	                          <div class="s-table_row">
	                            <div class="table_row-grey t-dark_grey">Стоимость часа специалиста</div>
	                            <div class="table_row-grey t-middle_grey">1700 р</div>
	                            <div class="table_row-grey t-middle_grey">1500 р</div>
	                            <div class="table_row-grey t-middle_grey">1400 р</div>
	                            <div class="table_row-grey t-middle_grey">1200 р</div>
	                          </div>
	                          <div class="s-table_row">
	                            <div class="table_row-grey t-dark_grey">Срок действия, месяц</div>
	                            <div class="table_row-grey t-middle_grey">1</div>
	                            <div class="table_row-grey t-middle_grey">3</div>
	                            <div class="table_row-grey t-middle_grey">3</div>
	                            <div class="table_row-grey t-middle_grey">6</div>
	                          </div>
	                        </div>
						  </div>  
						</div>
						<div class="col-12 col-lg-6 col-xl-6">
	                      <div class="subscription-advant">
	                        <div class="subscription-advant__title">
	                         Когда нужны не просто «руки программистов»
	                        </div>
	                        <p>Помогаем правильно оценить конечную цель. Прорабатываем оптимальное решение задачи.</p>
	                        <p>Решаем объемные и сложные задачи. Знаем, как справиться с потоком задач и не утонуть в нем. </p>
	                        <p>Подсказываем, что и как можно улучшить в процессе выполнения работы.</p>
	                        <p>Берём сайты на проведение аудита с визуальной и технической части.</p>

	                        <p></p>
	                      </div>
						</div>
					  </div>
					  <!-- /.row -->
					</div>
					<!-- /.subscription-block -->
				  </div>
				  <!-- /.col-12 -->

				  <div class="col-12 col-sm-12 col-md-12 col-lg-6 col-xl-6">
					<a class="button btn-scroll" href="#calculation">Рассчитать стоимость</a> 
				  </div>
				</div>
				<!-- /.row --> 
			  </div>
			  <!-- /.container -->
			</section>
			<!-- /.support -->

			<section  id="support-services" class="support-services">
			<a name="support-services"></a><!--якорь-->
			  <div class="container">
				<div class="row align-items-center">
				  <div class="col-12">
					<div class="support-services-bg title-bg">Type of work</div> 
					<h2 class="title support-services__title">Виды услуг техподдержки</h2>
				  </div>
				</div>
				<!-- /.row -->
				<div class="row align-items-start">
				  <div class="col-10 col-sm-4 col-md-4 col-lg-3 col-xl-3 d-flex justify-content-center justify-content-lg-start">
					<div class="service-item">
					  <img src="img/support/development.svg" class="service-item_img" alt="Размещение на сервере">
					  <h3 class="service-item_name">Разработка</h3>
					  <div class="service-item_desc">
						Разработка на bitrix нового функционала, модулей, отдельных блоков, форм и компонентов сайта.
					  </div>
					</div>
				  </div>
				  	<div class="col-10 col-sm-4 col-md-4 col-lg-3 col-xl-3 d-flex justify-content-center justify-content-lg-start">
					<div class="service-item">
					   <img src="img/support/diagnosis.svg" class="service-item_img" alt="Размещение на сервере">
					  <h3 class="service-item_name">Диагностика</h3>
					  <div class="service-item_desc">
						Диагностика скорости загрузки сайта, безопасности и ошибок на сайте, корректности кода и вёрстки.
					  </div>
					</div>
				  </div> 
				  <div class="col-10 col-sm-4 col-md-4 col-lg-3 col-xl-3 d-flex justify-content-center justify-content-lg-start">
					<div class="service-item">
					  <img src="img/support/modification.svg" class="service-item_img" alt="Размещение на сервере">
					  <h3 class="service-item_name">Доработка</h3>
					  <div class="service-item_desc">
						Доработка функционала и модулей, правки компонентов рабочего сайта, настройка форм и уведомлений.
					  </div>
					</div>
				  </div> 
				  <div class="col-10 col-sm-4 col-md-4 col-lg-3 col-xl-3 d-flex justify-content-center justify-content-lg-start">
					<div class="service-item">
					  <img src="img/support/responsive.svg" class="service-item_img" alt="Размещение на сервере">
					  <h3 class="service-item_name">Адаптив</h3>
					  <div class="service-item_desc">
						Разработка дизайна и вёрстка адаптива для готового сайта. Переработка элементов сайта.
					  </div>
					</div>
				  </div>
				  <div class="col-10 col-sm-4 col-md-4 col-lg-3 col-xl-3 d-flex justify-content-center justify-content-lg-start">
					<div class="service-item">
					  <img src="img/support/1cintegration.svg" class="service-item_img" alt="Интеграция систем">
					  <h3 class="service-item_name">Интеграция с 1С</h3>
					  <div class="service-item_desc">
						Настройка выгрузки товаров и обмена с 1С. Настройка обмена с нестандартными конфигурациями.
					  </div>
					</div>
				  </div> 
				  <div class="col-10 col-sm-4 col-md-4 col-lg-3 col-xl-3 d-flex justify-content-center justify-content-lg-start">
					<div class="service-item">
					  <img src="img/support/mystorageint.svg" class="service-item_img" alt="Интеграция систем">
					  <h3 class="service-item_name">Интеграция с Мой.Склад</h3>
					  <div class="service-item_desc">
						Настройка синхронизации сайта с Мой склад. Настройка выгрузки каталога и заказов с сайта. Настройка Мой. Склад
					  </div>
					</div>
				  </div> 
				  <div class="col-10 col-sm-4 col-md-4 col-lg-3 col-xl-3 d-flex justify-content-center justify-content-lg-start">
					<div class="service-item">
					  <img src="img/support/bitrix24.svg" class="service-item_img" alt="Интеграция систем">
					  <h3 class="service-item_name">Интеграция с Битрикс24</h3>
					  <div class="service-item_desc">
						Настройка автоматизированных бизнес-процессов в едином пространстве.
					  </div>
					</div>
				  </div> 
				  <div class="col-10 col-sm-4 col-md-4 col-lg-3 col-xl-3 d-flex justify-content-center justify-content-lg-start">
					<div class="service-item">
					  <img src="img/support/1c.svg" class="service-item_img" alt="Интеграция систем">
					  <h3 class="service-item_name">Интеграции с модулями</h3>
					  <div class="service-item_desc">
						Подключение онлайн-касс. Платёжные и бонусные системы. Модули из marketplace.
					  </div>
					</div>
				  </div>
				  <div class="col-10 col-sm-4 col-md-4 col-lg-3 col-xl-3 d-flex justify-content-center justify-content-lg-start">
					<div class="service-item">
					  <img src="img/support/vidjets.svg" class="service-item_img" alt="Виджеты">
					  <h3 class="service-item_name">Виджеты</h3>
					  <div class="service-item_desc">
					   Подключение внешних виджетов и систем аналитики. Яндекс Метрика, Google Analytics. 
					  </div>
					</div>
				  </div> 
				  <div class="col-10 col-sm-4 col-md-4 col-lg-3 col-xl-3 d-flex justify-content-center justify-content-lg-start">
					<div class="service-item">
					  <img src="img/support/audit.svg" class="service-item_img" alt="Технический аудит">
					  <h3 class="service-item_name">Технический аудит</h3>
					  <div class="service-item_desc">
						Выявление ошибок в работе компонентов сайта. Варианты оптимизации работы сайта.
					  </div>
					</div>
				  </div> 
				  <div class="col-10 col-sm-4 col-md-4 col-lg-3 col-xl-3 d-flex justify-content-center justify-content-lg-start">
					<div class="service-item">
					  <img src="img/support/design.svg" class="service-item_img" alt="Дизайн/Редизайн">
					  <h3 class="service-item_name">Дизайн/Редизайн</h3>
					  <div class="service-item_desc">
						Разработка дизайна сайта. Дизайн и редизайн отдельных элементов. Доработка дизайна интерфейса. 
					  </div>
					</div>
				  </div> 
				  <div class="col-10 col-sm-4 col-md-4 col-lg-3 col-xl-3 d-flex justify-content-center justify-content-lg-start">
					<div class="service-item">
					  <img src="img/support/content.svg" class="service-item_img" alt="Контент">
					  <h3 class="service-item_name">Контент</h3>
					  <div class="service-item_desc">
						Копирайтинг и размещение контента. Поиск и обработка графических материалов, видео и презентаций. 
					  </div>
					</div>
				  </div>  
				  <div class="col-10 col-sm-4 col-md-4 col-lg-3 col-xl-3 d-flex justify-content-center justify-content-lg-start">
					<div class="service-item">
					  <img src="img/support/instruction.svg" class="service-item_img" alt="Инструкции">
					  <h3 class="service-item_name">Инструкции</h3>
					  <div class="service-item_desc">
						Написание пошаговых инструкций по работе с сайтом на bitrix для пользователей и администраторов.  
					  </div>
					</div>
				  </div> 
				  <div class="col-10 col-sm-4 col-md-4 col-lg-3 col-xl-3 d-flex justify-content-center justify-content-lg-start">
					<div class="service-item">
					  <img src="img/support/learning.svg" class="service-item_img" alt="Обучение">
					  <h3 class="service-item_name">Обучение</h3>
					  <div class="service-item_desc">
						Обучение работе с сайтом на bitrix: заполнение и редактирование каталога, новостей. Работа с заказами.
					  </div>
					</div>
				  </div>
				  <div class="col-12 col-sm-12 col-md-12 col-lg-12 d-block d-lg-none">
					<div class="service-links">
					  <div class="service-link service-link__show">Показать все &#187;</div>
					  <div class="service-link service-link__hide">Скрыть &#187;</div>
					</div>
				  </div>
				</div>
				<!-- /.row -->
			  </div>
			  <!-- /.container -->
			</section>
			<!-- /.support-services -->
		
			<section id="recommend" class="recommend">
			<a name="recommend"></a><!--якорь-->
			  <div class="container">
				<div class="row">
				  <div class="col-12">
					<div class="recommend-bg title-bg">Recommend</div>
					<h2 class="title recommend-title">Как мы обрабатываем заявки</h2>
				  </div>
				  <!-- /.col-12 -->

				  <div class="col-12 col-sm-12 offset-sm-2 col-md-6 offset-md-6">
					<div class="work-process">
					  <div class="wp-text-bg__top text-bg">Заявка</div>
					  <div class="wp-tree">
						
						<div class="wp-cell">
						  <div class="wp-cell-bg text-bg">15 мин</div>
						  <div class="wprocess-number">1</div>
						  <div class="wp-line"></div>
						  <div class="wp-img"><img src="img/recommend/1.svg" alt="#"></div>
						  <div class="wprocess-step">Реагирование</div>
						  <div class="wprocess-desc">Время реагирования на заявку клиента на техподдержке - 15 мин. 1-2 часа для всех клиентов.</div>
						</div>
						
						<div class="wp-cell">
						  <div class="wp-cell-bg text-bg">1 день</div>
						  <div class="wprocess-number">2</div>
						  <div class="wp-line"></div>
						  <div class="wp-img"><img src="img/recommend/2.svg" alt="#"></div>
						  <div class="wprocess-step">Обсуждение</div>
						  <div class="wprocess-desc">К обсуждению привлекаются все заинтересованные специалисты. Время на обсуждение и выборку заявок - 1-2 дня.</div>
						</div>
						
						<div class="wp-cell">
						  <div class="wprocess-number">3</div>
						  <div class="wp-line"></div>
						  <div class="wp-img"><img src="img/recommend/3.svg" alt="#"></div>
						  <div class="wprocess-step">Составление условий</div>
						  <div class="wprocess-desc">Обсуждаются условия, сроки, стоимость, исполнитель. Заявке присваивается статус "задача".</div>
						</div>
						
						<div class="wp-cell">
						  <div class="wprocess-number">4</div>
						  <div class="wp-line"></div>
						  <div class="wp-img"><img src="img/recommend/4.svg" alt="#"></div>
						  <div class="wprocess-step">Согласование</div>
						  <div class="wprocess-desc">Согласование с клиентом стоимости и сроков исполнения задачи.</div>
						</div>
						
						<div class="wp-cell">
						  <div class="wp-cell-bg text-bg">очередь</div>
						  <div class="wprocess-number">5</div>
						  <div class="wp-line"></div>
						  <div class="wp-img"><img src="img/recommend/5.svg" alt="#"></div>
						  <div class="wprocess-step">Постановка задачи в план</div>
						  <div class="wprocess-desc">Учитывая загруженность специалиста, задача ставится в план.</div>
						</div>
						
						<div class="wp-cell">
						  <div class="wp-cell-bg text-bg">проверка</div>
						  <div class="wprocess-number">6</div>
						  <div class="wp-line"></div>
						  <div class="wp-img"><img src="img/recommend/6.svg" alt="#"></div>
						  <div class="wprocess-step">Контроль процесса</div>
						  <div class="wprocess-desc">Клиенту сообщается о готовности задачи. Проводится сдача задачи.
						  </div>
						</div>
						
						<div class="wp-cell">
						  <div class="wprocess-number">7</div>
						  <div class="wp-line"></div>
						  <div class="wp-img"><img src="img/recommend/7.svg" alt="#"></div>
						  <div class="wprocess-step">Сохранение</div>
						  <div class="wprocess-desc">Обязательное сохранение результата после выполнения задачи.</div>
						</div>
					  </div>
					  <div class="wp-text-bg__bottom text-bg">выполнено</div>
					</div>
				  </div>
				  <!-- /.col-12 -->
				</div>
				<!-- /.row -->
			  </div>
			  <!-- /.container -->
			</section>
			<!-- /.recommend -->

			<section id="calculation" class="calculation">
			<a name="calculation"></a><!--якорь-->
			  <div class="container">
				<div class="row">
				  <div class="col-12">
					<div class="calculation-item-title"> 
					  <div class="calculation-bg title-bg">Cost calculation</div>
					  <h2 class="title calculation-title">Нужно рассчитать стоимость задачи?</h2>  
					</div>
					<!-- /.calculation-item-title -->
				  </div>
				  <!-- /.col-12 -->
				</div>
				<!-- /.row -->
				
				<div class="row justify-content-between">
				  <div class="col-12 d-flex">
					<p>Если не знаете, сколько часов займет ваша заявка, предлагаем рассчитать.  Заполните форму и наши специалисты помогут вам.</p>
				  </div>
				</div>
				<div class="calculation-form">
					<form action="" id="calculation_form" class="calculation-form__form" method="post" enctype="multipart/form-data">
						<input type="hidden" name="my_file_upload" id="my_file_upload">
						<div class="row">
							<!-- левая колонка формы -->
							<div class="col-12 col-sm-12 col-md-6 col-lg-6">
								<div class="Flying_Placeholder">
									<label>Адрес Вашего сайта *</label>
									<input class="calculation-form__input" type="text" name="site-name" id="site-name" >
								</div>
								<div class="Flying_Placeholder">
									<select name="bitrix" id="bitrix" class="S3_type_1">  
										<option value="Старт">Старт</option>
										<option value="Стандарт">Стандарт</option>
										<option value="Малый бизнес">Малый бизнес</option>
										<option value="Бизнес">Бизнес</option>
										<option value="Энтерпрайз">Энтерпрайз</option>
									</select>
								</div>
								<div class="Flying_Placeholder">
									<label>Имя *</label>
									<input class="calculation-form__input" type="text" name="user-name" id="user-name" >
								</div>
								<div class="Flying_Placeholder">
									<label>Почта *</label>
									<input class="calculation-form__input" type="mail" name="user-mail" id="user-mail" >
								</div>
								<div class="Flying_Placeholder">
									<label>Телефон</label>
									<input class="calculation-form__input" type="tel" name="user-phone" id="user-phone" >
									
									<select id="calculation-form-contact_way" class="contact_way">
										<option class="Manager" value="manager">Звонок менеджера</option>
										<option class="WhatsApp" value="WhatsApp">WhatsApp</option>
										<option class="Viber" value="Viber">Viber</option>
										<option class="Telegram" value="Telegram">Telegram</option>
									</select>
								</div>
			
								<!--div class="way_to_contact row no-gutters" >
									<div class="col-6">
										Как с Вами связаться?
									</div>
									<div class="col-6">
										<input type="radio" name="contact_way" class="contact_way_radio" id="wtc_manager" value="manager" checked>
										<label for="wtc_manager">Звонок менеджера</label>
										<br>
										<input type="radio" name="contact_way" class="contact_way_radio" value="WhatsApp" id="wtc_WhatsApp">
										<label for="wtc_WhatsApp">WhatsApp</label>
										<br>
										<input type="radio" name="contact_way" class="contact_way_radio" value="Viber" id="wtc_Viber">
										<label for="wtc_Viber">Viber</label>
										<br>
										<input type="radio" name="contact_way" class="contact_way_radio" value="Telegram" id="wtc_Telegram">
										<label for="wtc_Telegram">Telegram</label>
										<br>
									</div>
								</div-->
							</div>
							<!-- конец левая колонка формы -->
							
							<!-- правая колонка формы -->
							<div class="col-12 col-sm-12 col-md-6 col-lg-6">
								<div class="Flying_Placeholder">
									<label>Опишите Ваш вопрос/задачу/проблему *</label>
									<textarea class="calculation-form__input calculation-form__ta" name="site-problem" ></textarea>
								</div>	
								<div class="Flying_Placeholder">
									<label>Ссылки на страницы, где обнаружена проблема</label>
									<textarea class="calculation-form__input calculation-form__ta" name="site-problem-links" ></textarea>
								</div>
								
								<div class="calculation-form__checkbox d-inline-flex align-items-center">
									<div>
										<input type="checkbox" name="user-device" class="options" id="user-device" >
									</div>
									<label for="user-device">Я пишу с устройства, на котором обнаружилась проблема</label>
								</div>	
								
								<div class="preloads">
									<!-- добавляется js при загрузке файлов -->
									<!--div class="p_item">
										<div class="p_text">
										</div>
										<div class="p_preview">
										<div class="p_close">×</div>
										</div>
									</div-->
								</div>
								
								<label class="calculation-label d-inline-flex align-items-center" for="file-upload">
									<img src="img/calculation/icon.svg" alt="#">
									<span>Загрузить скриншот, отображаюший проблему</span>
									<input class="calculation-form__input d-none" type="file" name="file-upload" id="file-upload" multiple accept="image/jpeg,image/png,image/bmp">
								</label>
								<small class="calculation-small">формат файла: png/jpg/bmp, размер до 5Мб</small>

								<div class="calculation-form__consent d-flex align-items-center justify-content-start">
									Нажимая на кнопку, я даю согласие на передачу личных данных ФЗ РФ №152 «О защите персональных данных»
								</div>
								<div class="d-flex align-items-center justify-content-start">
									<button type="submit" class="button calculation-form__btn">
										Отправить заявку
									</button>
								</div> 
							</div>  
							<!-- конец правая колонка формы -->
							
							<!-- низ формы -->
							<div class="col-12">
								 
							</div>
							<!-- конец низ формы -->
						</div>
					</form>
				</div>
				<!-- /.calculation-form --> 
			  </div>
			  <!-- /.container -->
			</section>
			<!-- /.calculation -->

			<footer class="footer">
			<a id="footer" name="footer"></a><!--якорь-->
			  <div class="footer-top">
				<div class="container">
				  <div class="row">
					<div class="col-12 col-sm-4 col-md-4 col-lg-4 d-flex justify-content-start justify-content-md-center">
					  <ul class="footer-top__list list-1">
						<li><a href="tel:+7(863)226-90-95" class="footer-top-link">+7 (863) 226-90-95</a></li>
					  </ul>
					</div>
					<!-- /.col-4 -->
					<div class="col-12 col-sm-4 col-md-4 col-lg-4 d-flex justify-content-start justify-content-md-center">
					  <ul class="footer-top__list list-2">
						<li><a href="tel:+7(928)163-11-00" class="footer-top-link">+7 (928) 163-11-00</a></li>
					  </ul>
					</div>
					<!-- /.col-4 -->
					<div class="col-12 col-sm-4 col-md-4 col-lg-4 d-flex justify-content-start justify-content-md-center">
					  <ul class="footer-top__list list-3">
						<li><a href="mailto:mail@adm-center.ru" class="footer-top-link">mail@adm-center.ru</a></li>
					  </ul>
					</div>
					<!-- /.col-4 -->
				  </div>
				  <!-- /.row -->
				</div>
				<!-- /.container -->  
			  </div>
			  <!-- /.footer-top -->
			  <div class="footer-bottom">
				<div class="container">
				  <div class="row align-items-center">
					<div class="col-9 col-sm-6 offset-1 offset-md-0 col-md-4 col-lg-5">
					  <div class="footer-bottom-social d-flex flex-wrap flex-lg-nowrap justify-content-between align-items-center">
						<a href="https://www.facebook.com/admcenter.ru/" target="_blank"><span class="icon-facebook"></span></a>
						<!--a href="#"><span class="icon-vkontakte"></span></a-->
						<!--a href="#"><span class="icon-odnoklassniki"></span></a-->
						<!--a href="#"><span class="icon-twitter"></span></a-->
						<a href="tg://resolve?domain=admasya" target="_blank"><span class="icon-telegram"></span></a>
						<a href="https://www.instagram.com/admcenter/" target="_blank"><span class="icon-instagram"></span></a>
						<a href="whatsapp://send?phone=+79281631100" target="_blank"><span class="icon-whatsapp"></span></a>
						<a href="viber://add?number=79281631100" target="_blank"><span class="icon-viber-brands"></span></a>
						<!--a href="#"><span class="icon-pinterest"></span></a-->
					  </div>
					  <!-- /.footer-bottom-social -->
					</div>
					<!-- /.col-6 -->
					<div class="col-12 col-md-7 col-lg-7">
					  <div class="row align-items-center">
						<div class="col-12 col-md-7 col-lg-8 d-flex justify-content-start justify-content-lg-end">
						  <a href="policy.php" target="_blank" class="footer-bottom-privacy">
							Политика конфиденциальности
						  </a>
						  <!-- /.footer-bottom-privacy -->
						</div>
						<!-- /.col-12 collg-6 -->
						<div class="col-12 col-md-5 col-lg-4 d-flex justify-content-start justify-content-md-end">
						  <div class="footer-bottom-copy">
							&#169; 2008-2019 ЦИТ «ADM»
						  </div>
						  <!-- /.footer-bottom-copy -->
						</div>
						<!-- /.col-12 collg-6 -->
					  </div>
					  <!-- /.row -->
					  
					</div>
					<!-- /.col-6 -->
				  </div>
				  <!-- /.row -->
				</div>
				<!-- /.container -->  
			  </div>
			  <!-- /.footer-bottom -->
			</footer>
			<!-- /.footer -->
				</div>
		  <!-- /.scrollcontent -->

				<div class="send-request modal fade" id="ModalLong" tabindex="-1" role="dialog" aria-labelledby="ModalLongTitle" aria-hidden="true">
			  <div class="popup modal-dialog m-0" role="document">
			  <button type="button" class="popup-close close" data-dismiss="modal" aria-label="Close">
				<span aria-hidden="true">&times;</span>
			  </button>
				<!-- <div class="popup-close close" data-dismiss="modal" aria-label="Close">&times;</div>-->
				<!-- /.popup-close -->

				<div class="popup-form">
					<div class="popup-form-header" id="ModalLongTitle">
						<div class="popup-form-header__title">Оставьте заявку на постоянное обслуживание</div>
						<div class="popup-form-header__descr">Заполните анкету и наши специалисты свяжутся с вами для обсуждения возможностей сотрудничества</div>
					</div>
				  <form action="" id="popup_form" class="popup-form__form" method="POST">
					<div class="popup-form-box">
						<div class="Flying_Placeholder">
							<label>Имя *</label>
							<input class="popup-form-box__input" type="text" name="user-name_modal" id="user-name_modal" >
						</div>
						<div class="Flying_Placeholder">
							<label>Адрес сайта *</label>
							<input class="popup-form-box__input popup-form-box__ta" name="user-linksite_modal" id="user-linksite_modal" ></input>
						</div>
						<div class="row no-gutters">
							<div class="col-6">
								<select name="package" id="package" class="S3_type_1">  
									<option value="Абонентская плата">Абонентская плата</option>
									<option value="Почасовая оплата">Почасовая оплата</option>
								</select>
							</div>
							<div class="col-6">
								<select name="tariff" id="tariff" class="S3_type_1">  
									<option value="Стандарт">Стандарт</option>
									<option value="Базовый">Базовый</option>
									<option value="Бизнес">Бизнес</option>
									<option value="Бизнес Pro">Бизнес Pro</option>
								</select>
							</div>
						</div>
						<div class="Flying_Placeholder">
							<label>E-mail *</label>
							<input class="popup-form-box__input" type="mail" name="user-mail_modal" id="user-mail_modal" >
						</div>

						<div class="Flying_Placeholder">
							<label>Телефон</label>
							<input class="popup-form-box__input" type="tel" name="user-phone_modal" id="user-phone_modal" >

							<select id="popup-form-contact_way" class="contact_way">
								<option class="Manager" value="manager">Звонок менеджера</option>
								<option class="WhatsApp" value="WhatsApp">WhatsApp</option>
								<option class="Viber" value="Viber">Viber</option>
								<option class="Telegram" value="Telegram">Telegram</option>
							</select>
						</div>
						<!--div class="Flying_Placeholder">
							<label>Телефон</label>
							<input class="popup-form-box__input" type="tel" name="user-phone_modal" id="user-phone_modal" >
						</div-->

						<div class="popup-form-desc">
						Нажимая на кнопку я соглашаюсь на передачу личных данных ФЗ РФ № 152 «О защите персональных данных»
						</div>
					</div>
					<!-- /.popup-form-box -->

					<div class="popup-form__button d-flex justify-content-center">
					  <button class="button popup-form__btn">
						Отправить заявку
					  </button>                
					</div>       
					<!-- /.popup-form__btn -->
				  </form>
				</div>
				<!-- /.popup-form -->
			  </div>
			  <!-- /.popup -->
			</div>
			<!-- /.send-request -->
		</div>
		<!-- /.wrap -->


		<script src="js/jquery.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<script src="js/jquery.maskedinput.min.js"></script>
		<!--script src="https://cdn.jsdelivr.net/gh/S-a-n-d-r-0/select3@master/select3.min.js"></script-->
		<script src="js/select3.js"></script>
		
		<!-- костыль для корректного подключения jquery.mobile - его конфигурация перед подключением -->
		<!--script>$(document).on("mobileinit", function() {
		$.mobile.autoInitializePage = false;
		});</script>
		
		<script src="js/jquery.mobile-1.5.0-rc1.min.js"></script-->
		<script src="js/detect.min.js"></script>
		<script src="js/main.js"></script>
		<!--script src="js/select2.min.js"></script-->
		
		
	</body>
</html>