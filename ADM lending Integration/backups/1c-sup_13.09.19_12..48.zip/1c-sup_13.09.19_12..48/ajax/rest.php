<?

// CRM (система управления взаимоотношениями с клиентами) - это битрикс24
// CRM is Bitrix24

// CRM server conection data
// Данные соединения с сервером CRM
define('CRM_HOST', 'admcenter.bitrix24.ru');		// your CRM domain name			//Ваше доменное имя CRM
define('CRM_PORT', '443');							// CRM server port				//Порт сервера CRM
define('CRM_PATH', '/crm/configs/import/lead.php'); // CRM server REST service path	// Путь службы REST сервера CRM

// CRM server authorization data
// Данные авторизации CRM-сервера
define('CRM_LOGIN', 'lid@adm-center.ru');			// login of a CRM user able to manage leads	// логин пользователя CRM, которому доступно управление лидами
define('CRM_PASSWORD', 'Lidadmcenter.001');			// password of a CRM user					// пароль этого пользователя
// OR you can send special authorization hash which is sent by server after first successful connection with login and password
// ИЛИ вы можете отправить специальный хеш авторизации, который отправляется сервером после первого успешного подключения с логином и паролем
define('CRM_AUTH', 'bf3dec9d8996af9fa4225e6f90019476111');	// authorization hash				// хеш авторизации

/********************************************************************************************/
//									ВОЗВРАЩАЕМЫЕ ДАННЫЕ
//С помощью Die() отсылается массив в формате json. Ключи массива
//'success'		=>	
//					'true'	- все прошло успешно
//					'false'	- есть ошибки
//'error_type' =>
//					''					
//					'internal_error'	- внутренняя ошибка - неправильно написан php-файл. Выводится в консоль js
//					'external_error'	- внешняя ошибка - пользователь ввел неправильные данные. Выводится не только в консоль js, но и в alert()
//'error_message' - текст ошибки
/********************************************************************************************/


//--------------------------------------------------------------------------------------------
//									ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ
//--------------------------------------------------------------------------------------------

// Transliteration of Cyrillic characters
// Транслитерация кирилических символов
// Used for the names of downloaded files
// Используется для названий загруженных файлов
function cyrillic_translit( $title ){
    $iso9_table = array(
        'А' => 'A', 'Б' => 'B', 'В' => 'V', 'Г' => 'G', 'Ѓ' => 'G',
        'Ґ' => 'G', 'Д' => 'D', 'Е' => 'E', 'Ё' => 'YO', 'Є' => 'YE',
        'Ж' => 'ZH', 'З' => 'Z', 'Ѕ' => 'Z', 'И' => 'I', 'Й' => 'J',
        'Ј' => 'J', 'І' => 'I', 'Ї' => 'YI', 'К' => 'K', 'Ќ' => 'K',
        'Л' => 'L', 'Љ' => 'L', 'М' => 'M', 'Н' => 'N', 'Њ' => 'N',
        'О' => 'O', 'П' => 'P', 'Р' => 'R', 'С' => 'S', 'Т' => 'T',
        'У' => 'U', 'Ў' => 'U', 'Ф' => 'F', 'Х' => 'H', 'Ц' => 'TS',
        'Ч' => 'CH', 'Џ' => 'DH', 'Ш' => 'SH', 'Щ' => 'SHH', 'Ъ' => '',
        'Ы' => 'Y', 'Ь' => '', 'Э' => 'E', 'Ю' => 'YU', 'Я' => 'YA',
        'а' => 'a', 'б' => 'b', 'в' => 'v', 'г' => 'g', 'ѓ' => 'g',
        'ґ' => 'g', 'д' => 'd', 'е' => 'e', 'ё' => 'yo', 'є' => 'ye',
        'ж' => 'zh', 'з' => 'z', 'ѕ' => 'z', 'и' => 'i', 'й' => 'j',
        'ј' => 'j', 'і' => 'i', 'ї' => 'yi', 'к' => 'k', 'ќ' => 'k',
        'л' => 'l', 'љ' => 'l', 'м' => 'm', 'н' => 'n', 'њ' => 'n',
        'о' => 'o', 'п' => 'p', 'р' => 'r', 'с' => 's', 'т' => 't',
        'у' => 'u', 'ў' => 'u', 'ф' => 'f', 'х' => 'h', 'ц' => 'ts',
        'ч' => 'ch', 'џ' => 'dh', 'ш' => 'sh', 'щ' => 'shh', 'ъ' => '',
        'ы' => 'y', 'ь' => '', 'э' => 'e', 'ю' => 'yu', 'я' => 'ya'
    );

    $name = strtr( $title, $iso9_table );
    $name = preg_replace('~[^A-Za-z0-9\'_\-\.]~', '-', $name );	//Находим любые символы, кроме A-Z, a-z, 0-9, ', _, - или . и заменяем на сивмол -
    $name = preg_replace('~\-+~', '-', $name );		// --- на -
    $name = preg_replace('~^-+|-+$~', '', $name );	// кил - на концах

    return $name;
}

//Turns the number of bytes into a string
//Преобразует количество байтов в строку
//Example: formatBytes (2500) will output "2.44 Kb"
//Пример: formatBytes(2500) выведет "2.44 Kb"
function formatBytes($bytes, $precision = 2) { 
    $units = array('b', 'Kb', 'Mb', 'Gb', 'Tb'); 

    $bytes = max($bytes, 0); 
    $pow = floor(($bytes ? log($bytes) : 0) / log(1024)); 
    $pow = min($pow, count($units) - 1); 
    $bytes /= pow(1024, $pow);

    return round($bytes, $precision) . ' ' . $units[$pow]; 
} 

//----------------------------------ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ
	//----------------------------------Запись отчета в TSV

//Возвращает количество строк в файле $filename
function fileLinesCount($filename)
{
	$file = new \SplFileObject($filename, 'r');
	$file->seek(PHP_INT_MAX);

	return $file->key() + 1; 
}

//Массив в строку формата TSV
function toTsvLine($array)
{
	//экранирование табуляции	
	foreach ($array as $k => $v) { $array[$k] = str_ireplace("\t", "\\t", $array[$k]); }
	//Соединение массива в строку через табуляцию
	return implode("\t", $array);// . PHP_EOL;
}

//Добавляет 1 строку в файл
//$filename - имя файла, строка
//$str - строка, которую нужно добавить в файл
//$addLineNumber - добавлять номер строки вначале, boolean, необязательный, по умолчанию = true
//После добавления строки переходит на новую строку
//Создаст файл $filename, если его не существует
function appendTsvLine($filename, $str, $addLineNumber = true)
{
	try	{
		if ($addLineNumber == true)
			$linesCount = (file_exists($filename)) ? fileLinesCount($filename) - 1 : 0;
		else
			$linesCount = "";
		
		file_put_contents($filename, $linesCount . "\t" . $str . PHP_EOL, FILE_APPEND);
	}
	catch (Exception $e) {
		file_put_contents($filename, 'Выброшено исключение: ' . $e->getMessage() . PHP_EOL, FILE_APPEND);
	}
}

//Добавляет 1 строку в файл
//$filename - имя файла, строка
//$array - массив строк, который будет добавлен в файл как 1 строка, разделенная знаком табуляции
//$addLineNumber - добавлять номер строки вначале, boolean, необязательный, по умолчанию = true
//После добавления строки переходит на новую строку
//Создаст файл $filename, если его не существует
function appendTsvArray($filename, $array, $addLineNumber = true)
{
	appendTsvLine($filename, toTsvLine($array), $addLineNumber);
}

//Добавляет каждую строку массива строк в файл с новой строки
//$filename - имя файла, строка
//$array - массив строк
//$addLineNumber - добавлять номер строки вначале, boolean, необязательный, по умолчанию = true
//Создаст файл $filename, если его не существует
function appendTsvLines($filename, $array, $addLineNumber = true)
{
	foreach($array as $v) appendTsvLine($filename, $v, $addLineNumber);
}


//----------------------------------ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ
	//----------------------------------ЛОГИ

//Тип сообщения (код), Сообщение, Файл, Строка, Прочие поля...
function appendLog($error_type, $error_message, $fileName, $lineNumber, $others)
{
	$path = "../logs/"; //путь к папке с логами
	
	if(!is_dir($path)) //если этой папки не существует
		mkdir($path); //то создать её
		
	$filename = $path . "errlogs.txt"; //имя файла с логами
	
	//Если файла еще нет, создаем и заполняем его заголовки
	if (!file_exists($filename))
	{
		$header = array("Дата", "Время", "Тип сообщения (код)", "Тип сообщения (расшифровка)", "Сообщение", "Файл", "Строка", "Прочие поля...");
		$header_description = array(
							"__________________________________________________________________________________________________________",
							"Дата - дата создания записи",
							"Время - время создания записи",
							"Тип сообщения (код) - типа external_error,internal_error,bot_detected и пр.",
							"Тип сообщения (расшифровка) - описание для кода сообщения",
							"Сообщение - сам текст сообщения",
							"Файл - файл, записавший это сообщение",
							"Строка - строка этого файла, вызвавшая запись сообщения",
							"Прочие поля... - далее указываются любые другие значения, которые потребовалось записать. Например, в json",
							"__________________________________________________________________________________________________________",
							);
		
		appendTsvLines($filename, $header_description, false);
		appendTsvLine($filename, "", false);
		appendTsvArray($filename, $header, false);
		appendTsvLine($filename, "", false);
	}
	
	$MESS = array(	'external_error' =>	'Ошибка, выводимая пользователю',
					'internal_error' =>	'Ошибка разработки',
					'bot_detected' => 	'СПАМ'
				);
	
	$lineData = array(date('Y-m-d'), date('H:i:s'), $error_type, ($MESS[$error_type]) ? $MESS[$error_type] : '', $error_message, $fileName, $lineNumber, json_encode($others));
	appendTsvArray($filename, $lineData);
}

//--------------------------------------------------------------------------------------------
//									ЗАЩИТА ОТ БОТОВ
//--------------------------------------------------------------------------------------------
/*
Защита от ботов состоит из 2 проверок:
1) Проверка того, что обязательные поля заполнены
2) Проверка того, что было совершено минимальное количество кликов мыши/нажатий клавишами клавиатуры по форме

Минимальное кол-во щелчков мышью и нажатий клавиш:
ДЛЯ НИЖНЕЙ ФОРМЫ:
1) Заполнить поле "Редакция 1С-Битрикс *" - (1 щелчок И 1 клавиша) ИЛИ (2 щелчка) ИЛИ (3 клавиши)	//Самодельное поле "Редакция 1С-Битрикс *", не являющееся стандартным input'ом/textarea'ей/select'ом и управляемое только с помощью js не заполнится ни ботом, ни автозаполнением
2) Чтобы отправить форму - 1 щелчок ИЛИ 1 клавиша													//щелчок по кнопке отправить, клавиша Enter
3) Автозаполнение на прочие обязательные поля - 2 клавиши ИЛИ 2 щелчка ИЛИ (1 щелчок И 1 клавиша)	//Автозаполнение на прочие обязательные поля - 2 клавиши ИЛИ 2 щелчка ИЛИ (1 щелчок И 1 клавиша). Автозаполнение по факту невозможно выключить в некоторых браузерах, например, в Chrome.
ИТОГО:
Суммарное количество щелчков мыши и нажатий клавишей должно быть >= 5.
ДЛЯ ВСПЛЫВАЮЩЕЙ ФОРМЫ:
то же, но без поля "Редакция 1С-Битрикс *"
ИТОГО:
Суммарное количество щелчков мыши и нажатий клавишей должно быть >= 3.
*/

if ($_SERVER['REQUEST_METHOD'] == 'POST')
{
	$postData = $_POST;
	
	//1) Проверка того, что обязательные поля заполнены
	if ($postData['formId'])//1.1)
	{
		switch ($postData['formId']) //1.2)
		{
			case 'calculation_form':
				if ($postData['site'] && $postData['bitrix'] && $postData['name'] && $postData['mail'] && $postData['problem']) //1.3)
				{
					if (isset($postData['c']) && isset($postData['k'])) //1.4)
					{
						//2) Проверка минимального кол-ва нажатий клавиши/кликов мыши
						if (is_numeric($postData['c']) && is_numeric($postData['k'])) //2.1)
						{
							$sum = $postData['c'] + $postData['k'];
							if ($sum >= 5) //2.2)
							{
								//ВСЕ ПРОВЕРКИ ПРОЙДЕНЫ
							}
							else
							{
								$error_message = "Зафиксированы признаки спама. Проверка 2.2. Обратитесь в службу поддержки по номеру, указанному на сайте.";
								appendLog('bot_detected', $error_message, __FILE__, __LINE__, json_encode($_POST));
								DIE(json_encode(array('success'=>'false','error_type'=>'bot_detected','error_message'=>$error_message)));
							}
						}
						else
						{
							$error_message = "Зафиксированы признаки спама. Проверка 2.1. Обратитесь в службу поддержки по номеру, указанному на сайте.";
							appendLog('bot_detected', $error_message, __FILE__, __LINE__, json_encode($_POST));
							DIE(json_encode(array('success'=>'false','error_type'=>'bot_detected','error_message'=>$error_message)));
						}
					}
					else
					{
						$error_message = "Зафиксированы признаки спама. Проверка 1.4. Обратитесь в службу поддержки по номеру, указанному на сайте.";
						appendLog('bot_detected', $error_message, __FILE__, __LINE__, json_encode($_POST));
						DIE(json_encode(array('success'=>'false','error_type'=>'bot_detected','error_message'=>$error_message)));
					}
				}
				else
				{
					$error_message = "Зафиксированы признаки спама. Проверка 1.3. Обратитесь в службу поддержки по номеру, указанному на сайте.";
					appendLog('bot_detected', $error_message, __FILE__, __LINE__, json_encode($_POST));
					DIE(json_encode(array('success'=>'false','error_type'=>'bot_detected','error_message'=>$error_message)));
				}
				break;
			case 'popup_form':
				if ($postData['name'] && $postData['site'] && $postData['mail'] && $postData['tariff'] && $postData['package']) //1.3)  //12.09.19 
				{
					if (isset($postData['c']) && isset($postData['k'])) //1.4)
					{
						//2) Проверка минимального кол-ва нажатий клавиши/кликов мыши
						if (is_numeric($postData['c']) && is_numeric($postData['k'])) //2.1)
						{
							$sum = $postData['c'] + $postData['k'];
							if ($sum >= 3) //2.2)
							{
								//ВСЕ ПРОВЕРКИ ПРОЙДЕНЫ
							}
							else
							{
								$error_message = "Зафиксированы признаки спама. Проверка 2.2. Обратитесь в службу поддержки по номеру, указанному на сайте.";
								appendLog('bot_detected', $error_message, __FILE__, __LINE__, json_encode($_POST));
								DIE(json_encode(array('success'=>'false','error_type'=>'bot_detected','error_message'=>$error_message)));
							}
						}
						else
						{
							$error_message = "Зафиксированы признаки спама. Проверка 2.1. Обратитесь в службу поддержки по номеру, указанному на сайте.";
							appendLog('bot_detected', $error_message, __FILE__, __LINE__, json_encode($_POST));
							DIE(json_encode(array('success'=>'false','error_type'=>'bot_detected','error_message'=>$error_message)));
						}
					}
					else
					{
						$error_message = "Зафиксированы признаки спама. Проверка 1.4. Обратитесь в службу поддержки по номеру, указанному на сайте.";
						appendLog('bot_detected', $error_message, __FILE__, __LINE__, json_encode($_POST));
						DIE(json_encode(array('success'=>'false','error_type'=>'bot_detected','error_message'=>$error_message)));
					}
				}
				else
				{
					$error_message = "Зафиксированы признаки спама. Проверка 1.3. Обратитесь в службу поддержки по номеру, указанному на сайте.";
					appendLog('bot_detected', $error_message, __FILE__, __LINE__, json_encode($_POST));
					DIE(json_encode(array('success'=>'false','error_type'=>'bot_detected','error_message'=>$error_message)));
				}
				break;
			default:
				$error_message = "Зафиксированы признаки спама. Проверка 1.2. Обратитесь в службу поддержки по номеру, указанному на сайте.";
				appendLog('bot_detected', $error_message, __FILE__, __LINE__, json_encode($_POST));
				DIE(json_encode(array('success'=>'false','error_type'=>'bot_detected','error_message'=>$error_message)));
		}
	}
	else
	{
		$error_message = "Зафиксированы признаки спама. Проверка 1.1. Обратитесь в службу поддержки по номеру, указанному на сайте.";
		appendLog('bot_detected', $error_message, __FILE__, __LINE__, json_encode($_POST));
		DIE(json_encode(array('success'=>'false','error_type'=>'bot_detected','error_message'=>$error_message)));
	}
}

//--------------------------------------------------------------------------------------------
//									ОБРАБОТКА ФАЙЛОВ
//--------------------------------------------------------------------------------------------

if($_POST['my_file_upload']=="123" && $_FILES){  
    // ВАЖНО! тут должны быть все проверки безопасности передавемых файлов и вывести ошибки, если нужно
	$allowed_filetypes = array('jpg','jpeg','jfif','pjpeg','pjp','png','bm','bmp', 'dib'); // Допустимые типы файлов
	$max_filesize = 5242880; // Максимальный размер файла в байтах (в данном случае он равен 5 Мб = 5242880 байт).

    $uploaddir = './uploads'; // . - текущая папка где находится submit.php
    
    // cоздадим папку если её нет
    if(!is_dir($uploaddir))mkdir($uploaddir, 0777);

    $files = $_FILES; // полученные файлы
    $done_files = array();

    // переместим файлы из временной директории в указанную
    foreach($files as $file){
		$filename = $file['name']; // В переменную $filename заносим имя файла (включая расширение).
		$ext = strtoupper(pathinfo($filename, PATHINFO_EXTENSION)); // В переменную $ext заносим расширение загруженного файла.
		
		if(in_array($ext, array_map('strtoupper', $allowed_filetypes))) // array_map(strtoupper, $array) - переведет весь массив $array в верхний регистр
		{
			if(filesize($file['tmp_name']) < $max_filesize) // Проверим размер загруженного файла.
			{
				$file_name = cyrillic_translit($file['name']);
				if(move_uploaded_file($file['tmp_name'], "$uploaddir/$file_name")){
					$done_files[] = realpath( "$uploaddir/$file_name" );
				}
			}
			else
			{
				//ОШИБКА:
				$error_message = "Ошибка загрузки файлов: \n";
				$error_message .= $file['name'] . " - Файл слишком большой. Максимальный размер файла - " . formatBytes($max_filesize) . "\n";
				appendLog('external_error', $error_message, __FILE__, __LINE__, json_encode($_POST));
				DIE(json_encode(array('success'=>'false','error_type'=>'external_error','error_message'=>$error_message)));
			}
		}
		else
		{
			//ОШИБКА:
			$error_message = "Ошибка загрузки файлов: \n";
			$error_message .= "\"" . $ext . "\"" . " - Этот тип файлов не разрешен. \n";
			appendLog('external_error', $error_message, __FILE__, __LINE__, json_encode($_POST));
			DIE(json_encode(array('success'=>'false','error_type'=>'external_error','error_message'=>$error_message)));
		}
    }

	$datafile = array('files' => $done_files);
	
}
else if($_POST['my_file_upload']!="123" && $_FILES)
{
	$error_message = "Неверная отправка файлов";
	appendLog('external_error', $error_message, __FILE__, __LINE__, json_encode($_POST));
	DIE(json_encode(array('success'=>'false','error_type'=>'bot_detected','error_message'=>$error_message)));
}

//--------------------------------------------------------------------------------------------
//										ВАЛИДАЦИЯ
//--------------------------------------------------------------------------------------------

//Возвращает массив в 3мя ключами:
//							error			=> true/false,
//							error_message	=> 'сообщение об ошибке'/'',
//							value			=> отформатированное значение
function validate($key_id, $value_in, $description, $form_id = null)
{
	$value_in = trim($value_in);
	
	$error = 'false';
	$error_message = '';
	$value_out = $value_in;
	
	switch ($key_id)
	{
		case 'email':
			if (filter_var($value_in, FILTER_VALIDATE_EMAIL) == false)
			{
				$error = 'true';
				$error_message = "Ошибка: \n";
				$error_message .= "Поле \"" . $description . "\" не прошло валидацию на сервере. Заполните поле правильно.";
			}
			break;
			
		case 'problem_device_yn':
			$value_out = ($value_in == "on") ? "Да" : "Нет";
			break;
			
		case 'way_to_contact':
			$value_out = ($value_in == "manager") ? "Звонок менеджера" : $value_in;
			break;
		
		case 'site':
			$pattern = "/^(http(s)?:\/\/)?([a-zA-Z0-9а-яА-ЯеЁ]{1}[-a-zA-Z0-9а-яА-ЯеЁ]{0,254}[a-zA-Z0-9а-яА-ЯеЁ]{1}[.]{0,1}){1,}[.]{1}([a-zA-Z0-9рРфФ]{1}[-a-zA-Z0-9рРфФ]{0,6}[a-zA-Z0-9рРфФ]{1}){1}([:\/?#]{1}([-a-zA-Z0-9а-яА-ЯеЁ@:%_+.~#?&\/=$!*'()\[\],]{0,})){0,}$/iu";
			$result = preg_match($pattern , $value_in);
			if ($result === 0)
			{
				$error = 'true';
				$error_message = "Ошибка: \n";
				$error_message .= "Поле \"" . $description . "\" не прошло валидацию на сервере. Заполните поле правильно.";
			}
			else if ($result === false)
			{
				//ВНУТРЕННЯЯ ОШИБКА: 3
				$error_message = "Ошибка 3: \n";
				$error_message .= "Ошибка в preg_match. \$value_in: " . $value_in . "\n";
				appendLog('internal_error', $error_message, __FILE__, __LINE__, json_encode($_POST));
				DIE(json_encode(array('success'=>'false','error_type'=>'internal_error','error_message'=>$error_message)));
			}
			break;
		
		default:
			$error = 'false';
			$error_message = '';
			$value_out = $value_in;
	}
	
	return array('error' => $error, 'error_message' => $error_message, 'value' => $value_out);
}

//--------------------------------------------------------------------------------------------
//										КЛЮЧИ
//--------------------------------------------------------------------------------------------

//description - используется для заполнения поля комментариев COMMENTS в bitrix24.
//		Поскольку все поля дублируются в комментариях, должно быть заполнено. Также
//		используется для вывода сообщений об ошибках для пользователей
//b24_key - ключ массива для API bitrix24. Взять можно здесь:
//		https://dev.1c-bitrix.ru/community/blogs/chaos/crm-sozdanie-lidov-iz-drugikh-servisov.php
//form_id - id формы, см. в её html
//input_name - имя параметра в массиве $_POST. Равно аттрибуту name в html формы, но
//		могло быть изменено в js. См. html и js.
//internal_vals - значения полей, которые не приходят с формы. Кроме параметров
//		соединения с сервером и авторизации в CRM. Они задавались выше
//post_vals - описание параметров, которые передаются через $_POST.

$_MyKEYS = array(
	
	//форма, которая снизу. Расчет стоимости задачи.
    array(
        'form_id' => "calculation_form", 
        'internal_vals' => array(
			array(
                'b24_key'			=> 'TITLE',
                'value'				=> '1c-bitrixsupport.ru. Расчет стоимости задачи.'
            ),
			array(
                'b24_key'			=> 'SOURCE_DESCRIPTION',
                'value'				=> '1c-bitrixsupport.ru'
            ),
            array(
                'b24_key'			=> 'ASSIGNED_BY_ID',
                'value'				=> 126	//id ответственного за Лид
            ),
			array(
                'b24_key'			=> 'UF_CRM_1566303971',			//поле для id формы в b24
                'value'				=> "sup_calc_form",	//id формы в b24
            ),
        ),
        'post_vals' => array(
            array(
                'id'					=> 'name',
                'input_name'			=> 'name',
                'b24_key'				=> 'NAME',
                'description'			=> 'Имя'
            ),
            array(
                'id'					=> 'phone',
                'input_name'			=> 'phone',
                'b24_key'				=> 'PHONE_MOBILE',
                'description'			=> 'Телефон'
            ),
			array(
                'id'					=> 'site',
                'input_name'			=> 'site',
                'b24_key'				=> 'WEB_WORK',
                'description'			=> 'Сайт'
            ),
			array(
                'id'					=> 'email',
                'input_name'			=> 'mail',
                'b24_key'				=> 'EMAIL_WORK',
                'description'			=> 'E-mail'
            ),
			array(
                'id'					=> 'bitrix_edition',
                'input_name'			=> 'bitrix',
                'b24_key'				=> 'COMMENTS',
                'description'			=> 'Редакция 1С-Битрикс'
            ),
			array(
                'id'					=> 'problem_description',
                'input_name'			=> 'problem',
                'b24_key'				=> 'COMMENTS',
                'description'			=> 'Описание проблемы'
            ),
			array(
                'id'					=> 'problem_links',
                'input_name'			=> 'links',
                'b24_key'				=> 'COMMENTS',
                'description'			=> 'Ссылки на страницы, где обнаружена проблема'
            ),
			array(
                'id'					=> 'problem_device_yn',
                'input_name'			=> 'device',
                'b24_key'				=> 'COMMENTS',
                'description'			=> 'Я пишу с устройства, на котором обнаружилась проблема'
            ),
			array(
                'id'					=> 'problem_device_details',
                'input_name'			=> 'device_details',
                'b24_key'				=> 'COMMENTS',
                'description'			=> 'Устройство'
            ),
			array(
                'id'					=> 'way_to_contact',
                'input_name'			=> 'way_to_contact',
                'b24_key'				=> 'COMMENTS',
                'description'			=> 'Способ связаться'
            ),
        )
    ),
	
	//всплывающая форма. Заявка на постоянное обслуживание.
    array(
        'form_id' => "popup_form", 
        'internal_vals' => array(
			array(
                'b24_key'			=> 'TITLE',
                'value'				=> '1c-bitrixsupport.ru. Заявка на постоянное обслуживание.' //Заголовок
            ),
			array(
                'b24_key'			=> 'SOURCE_DESCRIPTION',
                'value'				=> '1c-bitrixsupport.ru'  //Дополнительно об источнике
            ),
            array(
                'b24_key'			=> 'ASSIGNED_BY_ID',
                'value'				=> 126 //id ответственного за Лид
            ),
			array(
                'b24_key'			=> 'UF_CRM_1566303971',			//поле для id формы в b24
                'value'				=> "sup_service_request_form",	//id формы в b24
            ),
        ),
        'post_vals' => array(
            array(
                'id'					=> 'name',
                'input_name'			=> 'name',
                'b24_key'				=> 'NAME',
                'description'			=> 'Имя'
            ),
			array(												//12.09.19
                'id'					=> 'package',			//12.09.19
                'input_name'			=> 'package',			//12.09.19
                'b24_key'				=> 'COMMENTS',			//12.09.19
                'description'			=> 'Пакет услуг'		//12.09.19
            ),													//12.09.19
			array(												//12.09.19
                'id'					=> 'tariff',			//12.09.19
                'input_name'			=> 'tariff',			//12.09.19
                'b24_key'				=> 'COMMENTS',			//12.09.19
                'description'			=> 'Тариф'				//12.09.19
            ),													//12.09.19
            array(
                'id'					=> 'phone',
                'input_name'			=> 'phone',
                'b24_key'				=> 'PHONE_MOBILE',
                'description'			=> 'Телефон'
            ),
			array(
                'id'					=> 'site',
                'input_name'			=> 'site',
                'b24_key'				=> 'WEB_WORK',
                'description'			=> 'Сайт'
            ),
			array(
                'id'					=> 'email',
                'input_name'			=> 'mail',
                'b24_key'				=> 'EMAIL_WORK',
                'description'			=> 'E-mail'
            ),
			array(
                'id'					=> 'way_to_contact',
                'input_name'			=> 'way_to_contact',
                'b24_key'				=> 'COMMENTS',
                'description'			=> 'Способ связаться'
            ),
        )
    ),
);


//--------------------------------------------------------------------------------------------
//								ОБРАБОТКА $_POST КРОМЕ ФАЙЛОВ
//--------------------------------------------------------------------------------------------

// POST processing
if ($_SERVER['REQUEST_METHOD'] == 'POST')
{
	// get lead data from the form
	$leadData = $_POST;

	$postData = array();
	
	//Проверяем существование нужного $leadData['formId'] в $_MyKEYS
	$form_exists = false;	
	foreach ($_MyKEYS as $form)
		if ($form['form_id'] == $leadData['formId'])
		{
			$form_exists = true;
			break;
		}
	if (!$form_exists)
	{
		//ВНУТРЕННЯЯ ОШИБКА: 1
		$error_message = "Ошибка 1: \n";
		$error_message .= "Неизвестный id формы: " . "\"" . $leadData['formId'] . "\"" . "\n";
		appendLog('internal_error', $error_message, __FILE__, __LINE__, json_encode($_POST));
		DIE(json_encode(array('success'=>'false','error_type'=>'internal_error','error_message'=>$error_message)));
	}
	
	foreach ($_MyKEYS as $form)
		if ($form['form_id'] == $leadData['formId'])
		{
			//Заполняем поля, значения которых задавались здесь (кроме параметров соединения с сервером и авторизации в CRM)
			foreach ($form['internal_vals'] as $v)
				if ($v['b24_key'] && $v['value'])
					$postData[$v['b24_key']] = $v['value'];
				else
				{
					//ВНУТРЕННЯЯ ОШИБКА: 2
					$error_message = "Ошибка 2: \n";
					appendLog('internal_error', $error_message, __FILE__, __LINE__, json_encode($_POST));
					DIE(json_encode(array('success'=>'false','error_type'=>'internal_error','error_message'=>$error_message)));
				}
				
				
			//Готовим поле комментариев COMMENTS
			$comm = '<div style="font-size: 18px; line-height: 22px;"><b>Комментарии, ответы пользователя</b></div><br>';
			$comm .= "<div style=\"font-weight: normal; \">";//открывающий div
			
			//Добавим в комментарии заголовок
			foreach ($form['internal_vals'] as $v)
				if ($v['b24_key'] == 'TITLE')
					$comm .= '<b>' . $v['value'] . '</b><br><br>';
			
			foreach ($form['post_vals'] as $v)
				if ($leadData[$v['input_name']])
				{
					$validate_result = validate($v['id'], $leadData[$v['input_name']], $v['description']);
					if ($validate_result['error'] == 'false')
					{
						//заполняем поля, не являющиеся комментариями
						if ($v['b24_key'] != 'COMMENTS' && $v['b24_key'] != '')
							$postData[$v['b24_key']] = $validate_result['value'];
						
						//заполняем комментарии
						if ($v['description'])
							$comm .= '<b>' . $v['description'] . ': </b>';
						$comm .= $validate_result['value'];
						$comm .=  '<br><br>';
					}
					else
					{
						//ОШИБКА:
						appendLog('external_error', $validate_result['error_message'], __FILE__, __LINE__, json_encode($_POST));
						DIE(json_encode(array('success'=>'false','error_type'=>'external_error','error_message'=>$validate_result['error_message'])));
					}
				}
				
			//Добавим в комментарии ссылки на загруженные файлы (подготовлены выше)
			if($datafile['files'])
			{
				$comm .= '<b>Загруженные файлы: </b><br>';
				foreach($datafile['files'] as $file)
				{
					//ПРИ ПЕРЕНОСЕ ИЗМЕНИТЬ:
					$_url = str_replace('/home/users/a/admservice/domains/', 'http://', $file); //-------!!!!!!!ПРИ ПЕРЕНОСЕ ИЗМЕНИТЬ
					$comm .= "<a href=\"".$_url."\">".$_url."</a>";
					$comm .= '<br>';
				}
				$comm .= '<br>';
			}
					
			$comm .= "</div>"; //закрывающий div комментариев
			$postData['COMMENTS'] = $comm;
			
			break;
		}
		
		
	

	// append authorization data
	if (defined('CRM_AUTH'))
	{
		$postData['AUTH'] = CRM_AUTH;
	}
	else
	{
		$postData['LOGIN'] = CRM_LOGIN;
		$postData['PASSWORD'] = CRM_PASSWORD;
	}
	
	//!!!!!!!!!!---------------------ОТЛАДКА
	//DIE(json_encode(array('success'=>'true')));//!!!!!!!!!!---------------------ОТЛАДКА
	//!!!!!!!!!!---------------------ОТЛАДКА
	
	
	// open socket to CRM
	$fp = fsockopen("ssl://".CRM_HOST, CRM_PORT, $errno, $errstr, 30);
	if ($fp)
	{
		// prepare POST data
		$strPostData = '';
		foreach ($postData as $key => $value)
			$strPostData .= ($strPostData == '' ? '' : '&').$key.'='.urlencode($value);

		// prepare POST headers
		$str = "POST ".CRM_PATH." HTTP/1.0\r\n";
		$str .= "Host: ".CRM_HOST."\r\n";
		$str .= "Content-Type: application/x-www-form-urlencoded\r\n";
		$str .= "Content-Length: ".strlen($strPostData)."\r\n";
		$str .= "Connection: close\r\n\r\n";

		$str .= $strPostData;

		// send POST to CRM
		fwrite($fp, $str);

		// get CRM headers
		$result = '';
		while (!feof($fp))
		{
			$result .= fgets($fp, 128);
		}
		fclose($fp); 
		
		// cut response headers
		$response = explode("\r\n\r\n", $result);
		
		//$output = '<pre>'.print_r($response[1], 1).'</pre>';
		
	    //Получение ID
		$response[1] = str_replace('\'', '"', $response[1]);//взяли вторую строку массива(перезаписали) и заменили в ней ' на "  
		$arr_resp = json_decode($response[1], true);//в новую переменную записали декодированный массив json
		$leadid = $arr_resp['ID'];
		
		if ((!$leadid) || (!is_numeric($leadid)))
		{
			//ВНУТРЕННЯЯ ОШИБКА 4: ОШИБКА Bitrix24
			$error_message = "Ошибка 4. Ошибка bitrix24. \n";
			$error_message .= json_encode($arr_resp);
			appendLog('internal_error', $error_message, __FILE__, __LINE__, json_encode($_POST));
			DIE(json_encode(array('success'=>'false','error_type'=>'internal_error','error_message'=>$error_message)));
		}
		
		DIE(json_encode(array('success'=>'true', 'leadid'=>$leadid)));
	}
	else
	{
		//ОШИБКА:
		$error_message = "Соединение было прервано! \n";
		$error_message .= $errstr. " (" . $errno . ")";
		appendLog('external_error', $error_message, __FILE__, __LINE__, json_encode($_POST));
		DIE(json_encode(array('success'=>'false','error_type'=>'external_error','error_message'=>$error_message)));
	}
}
else
{
	$output = '';
}

// HTML form
?>
<?/*=$output;*/?>