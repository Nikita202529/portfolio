//-----------------------------------------------------------------------
//             Точное сравнение объектов js
//-----------------------------------------------------------------------

//Используется при загрузке файлов, чтобы пользователь не смог загрузить один файл дважды. 
//При попытке загрузки загруженный файл сравнивается с предыдущими. Если он уже есть, в 
//его загрузке отказывается

function deepCompare () {
  var i, l, leftChain, rightChain;

  function compare2Objects (x, y) {
    var p;

    // remember that NaN === NaN returns false
    // and isNaN(undefined) returns true
    if (isNaN(x) && isNaN(y) && typeof x === 'number' && typeof y === 'number') {
         return true;
    }

    // Compare primitives and functions.     
    // Check if both arguments link to the same object.
    // Especially useful on the step where we compare prototypes
    if (x === y) {
        return true;
    }

    // Works in case when functions are created in constructor.
    // Comparing dates is a common scenario. Another built-ins?
    // We can even handle functions passed across iframes
    if ((typeof x === 'function' && typeof y === 'function') ||
       (x instanceof Date && y instanceof Date) ||
       (x instanceof RegExp && y instanceof RegExp) ||
       (x instanceof String && y instanceof String) ||
       (x instanceof Number && y instanceof Number)) {
        return x.toString() === y.toString();
    }

    // At last checking prototypes as good as we can
    if (!(x instanceof Object && y instanceof Object)) {
        return false;
    }

    if (x.isPrototypeOf(y) || y.isPrototypeOf(x)) {
        return false;
    }

    if (x.constructor !== y.constructor) {
        return false;
    }

    if (x.prototype !== y.prototype) {
        return false;
    }

    // Check for infinitive linking loops
    if (leftChain.indexOf(x) > -1 || rightChain.indexOf(y) > -1) {
         return false;
    }

    // Quick checking of one object being a subset of another.
    // todo: cache the structure of arguments[0] for performance
    for (p in y) {
        if (y.hasOwnProperty(p) !== x.hasOwnProperty(p)) {
            return false;
        }
        else if (typeof y[p] !== typeof x[p]) {
            return false;
        }
    }

    for (p in x) {
        if (y.hasOwnProperty(p) !== x.hasOwnProperty(p)) {
            return false;
        }
        else if (typeof y[p] !== typeof x[p]) {
            return false;
        }

        switch (typeof (x[p])) {
            case 'object':
            case 'function':

                leftChain.push(x);
                rightChain.push(y);

                if (!compare2Objects (x[p], y[p])) {
                    return false;
                }

                leftChain.pop();
                rightChain.pop();
                break;

            default:
                if (x[p] !== y[p]) {
                    return false;
                }
                break;
        }
    }

    return true;
  }

  if (arguments.length < 1) {
    return true; //Die silently? Don't know how to handle such case, please help...
    // throw "Need two or more arguments to compare";
  }

  for (i = 1, l = arguments.length; i < l; i++) {

      leftChain = []; //Todo: this can be cached
      rightChain = [];

      if (!compare2Objects(arguments[0], arguments[i])) {
          return false;
      }
  }

  return true;
}

Array.prototype.unique = function() {
    var a = this.concat();
    for(var i=0; i<a.length; ++i) {
        for(var j=i+1; j<a.length; ++j) {
            if(deepCompare(a[i],a[j])) //было if(a[i] === a[j])
                a.splice(j--, 1);
        }
    }

    return a;
};

//-----------------------------------------------------------------------
//             Вывод всплывающих сообщений
//-----------------------------------------------------------------------

//Замена alert'у
//функция ShowMyMessage
var MyQueue = [];
//alert_message - сообщение, можно html
//bs_type - тип alert'а в bootstrap'е, влияет только на цвет, bstype = primary, secondary, success, danger, warning, info, light, dark
function ShowMyMessage(alert_message, bs_type)
{
	if (!bs_type) bs_type = 'light';
	function ShowMessageRightNow(message, bstype)
	{
		//генерация случайного id
		let id =  String.fromCharCode.apply(null, Date.now().toString().split('').map(function(i){ return parseInt(i) + 65;}));
		let MyDiv1 = $('<div/>', { 'id': id, 'class': 'modal fade MyAlertsClass', 'role': 'dialog', 'aria-hidden':'true' });
		let MyDiv2 = $('<div/>', { 'class': 'modal-dialog' });
		let MyDiv3 = $('<div/>', { 'class': 'alert alert-' + bstype });
		MyDiv3.append(message);
		MyDiv2.append(MyDiv3);
		MyDiv1.append(MyDiv2);

		$('body').append(MyDiv1);
		$('#' + id).modal('show');
		$('#' + id).on('hidden.bs.modal', function (e) {
			$('#' + id).remove();
			NextMassage();
		});
	}
	
	MyQueue.push([alert_message, bs_type]);
	if (MyQueue.length == 1)
		NextMassage();
		
	function NextMassage()
	{
		if ($('.MyAlertsClass').length == 0)
			setTimeout( function() {
			if (MyQueue.length != 0)
				{
					ShowMessageRightNow(MyQueue[0][0], MyQueue[0][1]);
					MyQueue.shift()
				}
			}, 500);
	}
}

//-----------------------------------------------------------------------
//             Маски на телефонные номера
//-----------------------------------------------------------------------

//Маски на телефонные номера
jQuery(function($){
	
  $("#user-phone").mask("+7 (999) 999-99-99", {autoclear: false});
  $("#user-phone_modal").mask("+7 (999) 999-99-99", {autoclear: false});
});


//-----------------------------------------------------------------------
//             Показать все сервисы/Скрыть все сервисы
//-----------------------------------------------------------------------

$(document).ready( function () {
	//show some blocks when you click on a link
	  let serviceItem = document.querySelectorAll('.service-item'),
		  serviceLinks = document.querySelector('.service-links'),
		  serviceLink = document.querySelectorAll('.service-link');
	
	  function showserviceItem() {
		for (let i = 0; i < serviceItem.length; i++) {
		  serviceItem[i].style.display = '';
		}
	  }
	
	  function hideserviceItem() {
		for (let i = 0; i < serviceItem.length; i++) {
		  if (i > 5) {
			serviceItem[i].style.display = 'none';
		  } else {
			serviceItem[i].style.display = '';
		  }
		}
	  }
	  //Все сервисы показываются только на широком экране:
	  function serviceBlock() {
		//if ($(window).width() < 992) {
		if (window.innerWidth < 992) {
		  hideserviceItem();
		  //serviceLink[0].style.display = 'inline-block';
		} else {
		  showserviceItem();
		  // serviceLink[1].style.display = 'none';
		}
	  }
	
	  //Показать все сервисы/Скрыть все сервисы
	  serviceLinks.addEventListener('click', function(e) {
		let target = e.target;
		if (target && target.classList.contains('service-link__show')) {
		  showserviceItem();
		  serviceLink[0].style.display = 'none';
		  serviceLink[1].style.display = 'inline-block';
		} 
	  });  
	  serviceLinks.addEventListener('click', function(e) {
		let target = e.target;
		if (target && target.classList.contains('service-link__hide')) {
		  hideserviceItem();
		  serviceLink[0].style.display = 'inline-block';
		  serviceLink[1].style.display = 'none';
		}
	  });
	
	  serviceBlock();
	
});

//-----------------------------------------------------------------------
//             Меню
//-----------------------------------------------------------------------


$(document).ready( function () {
  'use strict';
  
  // start main menu
    var hamburger = document.querySelector('.hamburger'),
        menu = document.querySelector('.menu'),
        scrollcontent = document.querySelector('.scrollcontent'),
        menuArrowBack = document.querySelector('.menu-top_arrow'),
        menuItem = document.querySelectorAll('.menu-item'),
        menuLink = document.querySelectorAll('.menu-link'),
        body = document.querySelector('body'),
        headerLogo = document.querySelector('.header-logo');

    // show main menu
    function showMenu() {

		menu.classList.add('menu-active');
		scrollcontent.classList.add('scrollcontent_active');

		$( '.hamburger' ).css('opacity', '0' );
    }

    // hide main menu
    function hideMenu() {
		menu.classList.remove('menu-active');
		scrollcontent.classList.remove('scrollcontent_active');

		$( '.hamburger' ).css('opacity', '1' );
    }

    //Event when you click on a hamburger and then the menu appears
    hamburger.addEventListener('click', function(e) {
        e.stopPropagation();
		
		let menu_is_active = $(menu).hasClass( 'menu-active' );
		if (menu_is_active)
			hideMenu();
		else
			showMenu();
    });

    // Event when you click outside menu - menu hide
    document.addEventListener('click', function( e ) {
      let target = e.target;
      let its_menu = target == menu || menu.contains(target);
	  
	  //e.stopPropagation();
      let its_hamburger = target == hamburger;
      let menu_is_active = menu.classList.contains('menu-active');

      
      if (!its_menu && !its_hamburger && menu_is_active) {
        hideMenu(); 
      }  
    });


    // Event when you click on the arrow main menu and then the menu is hidden
    menuArrowBack.addEventListener('click', function( e ) {
		e.stopPropagation();
		hideMenu();
    });
	
//-----------------------------------------------------------------------
//             Плавная прокрутка
//-----------------------------------------------------------------------

//плавный скролл страницы до элемента с указанным селектором. Время в миллисекундах.
function scrollTo( _selector, _time ) {
	var page = $("html, body");
	page.on("scroll mousedown wheel DOMMouseScroll mousewheel keyup touchmove", function(){ //добавляем обработчик события на любое действии пользователя
	   page.stop(); //остановить анимацию
	});

	page.animate({
		scrollTop: $( _selector ).offset().top - 30}, //Список свойств и значений CSS, к которым будет двигаться анимация.
		_time, //Время анимации
		function() { //Функция, вызываемая после завершения анимации
			page.off("scroll mousedown wheel DOMMouseScroll mousewheel keyup touchmove"); //удалить ранее добавленные обработчики событий
	});
}

// Плавная прокрутка
// Элемент, после нажатия на который прокручивается должен иметь класс "btn-scroll", а в href должна быть ссылка на якорь
// Пример:
// 		<a class="button btn-scroll" href="#calculation">Оставить заявку</a>


	$('.btn-scroll').click( function() {
		let destinationSelector = $(this).attr("href");
		scrollTo(destinationSelector, 1500); 
		//Hide menu when mobile 
		if(($(window).width() <= 845)){
			hideMenu();
		}
	});
  

	//свайп по окну
	/*
	$( window ).on( "swipeleft", function( e ) { 
		e.stopPropagation();
		hideMenu();
	} );
	
	$( window ).on( "swiperight", function( e ) { 
		e.stopPropagation();
		showMenu();
	} );
	*/
	
  // end main menu


//-----------------------------------------------------------------------
//             AJAX-отправка форм
//-----------------------------------------------------------------------

	//-----------------------------------------------------------------------
	//             Кастомные списки
	//-----------------------------------------------------------------------
	
	//Редакция 1С-Битрикс
	
	//http://cdn.jsdelivr.net/gh/S-a-n-d-r-0/select3/select3.js
	let params1 = {	'optionsWrapClass' : 'S3_OptionsWrap',
				'optionClass' : 'S3_Option',
				'mainDisplayClass' : 'S3_MainDisplay',
				'arrowClass' : 'S3_Arrow',
				'mDisplay_n_ArrowWrapClass' : 'S3_MainDisplay_n_ArrowWrap',
				'placeholderClass' : 'S3_Placeholder',
				'hiddenOptionsWrapClass' : 'hide',
				'allowNullChoice' : false,
				'multipleChoiсe' : false,
				'focusWhenHover' : true,
				'hidePlaceholderWhenShow' : true,
				'addEachValueAsDiv' : false,	
				'placeholderText' : 'Редакция 1С-Битрикс *'};
	var mySelect3bitrix = new select3('#bitrix', params1); //нижняя форма //12.09.19

	let params2 = {	'optionsWrapClass' : 'S3_OptionsWrap',
				'optionClass' : 'S3_Option',
				'mainDisplayClass' : 'S3_MainDisplay',
				'arrowClass' : 'S3_Arrow',
				'mDisplay_n_ArrowWrapClass' : 'S3_MainDisplay_n_ArrowWrap',
				'placeholderClass' : 'S3_Placeholder',
				'hiddenOptionsWrapClass' : 'hide',
				'allowNullChoice' : true,
				'multipleChoiсe' : true,
				'focusWhenHover' : true,
				'hidePlaceholderWhenShow' : true,
				'addEachValueAsDiv' : true,
				'eachValueWrapperClass' : 'S3_EachValueWrapper',		
				'placeholderText' : 'Как связаться?'}; //12.09.19
	var mySelect3calcform_contactWay = new select3('#calculation-form-contact_way', params2); //нижняя форма //12.09.19
	var mySelect3popupform_contactWay = new select3('#popup-form-contact_way', params2); //всплывающая форма //12.09.19
	
	let params3 = {	'optionsWrapClass' : 'S3_OptionsWrap', 							//12.09.19
				'optionClass' : 'S3_Option',										//12.09.19
				'mainDisplayClass' : 'S3_MainDisplay',								//12.09.19
				'arrowClass' : 'S3_Arrow',											//12.09.19
				'mDisplay_n_ArrowWrapClass' : 'S3_MainDisplay_n_ArrowWrap',			//12.09.19
				'placeholderClass' : 'S3_Placeholder',								//12.09.19
				'hiddenOptionsWrapClass' : 'hide',									//12.09.19
				'allowNullChoice' : false,											//12.09.19
				'multipleChoiсe' : false,											//12.09.19
				'focusWhenHover' : true,											//12.09.19
				'hidePlaceholderWhenShow' : true,									//12.09.19
				'addEachValueAsDiv' : false,										//12.09.19
				'placeholderText' : 'Пакет *'};										//12.09.19
	var mySelect3package = new select3('#package', params3); //всплывающая форма	//12.09.19
	let params4 = {	'optionsWrapClass' : 'S3_OptionsWrap', 							//12.09.19
				'optionClass' : 'S3_Option',										//12.09.19
				'mainDisplayClass' : 'S3_MainDisplay',								//12.09.19
				'arrowClass' : 'S3_Arrow',											//12.09.19
				'mDisplay_n_ArrowWrapClass' : 'S3_MainDisplay_n_ArrowWrap',			//12.09.19
				'placeholderClass' : 'S3_Placeholder',								//12.09.19
				'hiddenOptionsWrapClass' : 'hide',									//12.09.19
				'allowNullChoice' : false,											//12.09.19
				'multipleChoiсe' : false,											//12.09.19
				'focusWhenHover' : true,											//12.09.19
				'hidePlaceholderWhenShow' : true,									//12.09.19
				'addEachValueAsDiv' : false,										//12.09.19
				'placeholderText' : 'Тариф *'};										//12.09.19
	var mySelect3tariff = new select3('#tariff', params4); //всплывающая форма		//12.09.19
	
	/*костыли для кастомного списка*/
	
	var _1stFocus = true;
	$('#user-phone').on("focus", function (event) {
		if (_1stFocus === true)
		{
			_1stFocus = false;
			setTimeout(function () { mySelect3calcform_contactWay.Show(); $('#user-phone').focus(); }, 500);
		}
	});
	var _1stFocusPopup = true;
	$('#user-phone_modal').on("focus", function (event) {
		if (_1stFocusPopup === true)
		{
			_1stFocusPopup = false;
			setTimeout(function () { mySelect3popupform_contactWay.Show(); $('#user-phone_modal').focus(); }, 500);
		}
	});

//-------------AJAX-отправка форм
	//-----------------------------------------------------------------------
	//             Загрузка файлов
	//-----------------------------------------------------------------------

	//Загруженные файлы
	var files = [];
	
	$('input[type="file"]').change( function()
	{
		//files = this.files;//старая версия
		
		//новая версия - важно
		for (let i = 0; i < this.files.length; i++)
			files.push( this.files[i]);
		
		files = files.unique();//не стандартная функция. Прописана в начале файла. Удаляет все совпадения в массиве
		
		$('#my_file_upload').val("123");//важно
		
		refresh_all_preloads_html();
	});

//-------------AJAX-отправка форм
	//-----------------------------------------------------------------------
	//             Обновление превьюшек загрузок
	//-----------------------------------------------------------------------


	/* //Чистый пример:
	$('input[type="file"]').change(function(e){
				var fileName = e.target.files[0].name;
				alert('The file "' + fileName +  '" has been selected.');
			});
	*/
	//https://stackoverflow.com/questions/4459379/preview-an-image-before-it-is-uploaded
	//http://qaru.site/questions/24784/javascript-image-resize

	function refresh_all_preloads_html()
	{
		//если файлов нет, убираем отступы по y 
		if (files.length == 0)
			$('.preloads').addClass('my0_py0');
		else
			$('.preloads').removeClass('my0_py0');
		
		$('.preloads').empty();
		for (let i = 0; i < files.length; i++)
			{
				let p_text = $('<div/>', { "class": 'p_text' });
				let p_close = $('<div/>', { "class": 'p_close', "ind": i }); //ind передается для удаления - p_close.click
				let p_preview = $('<div/>', { "class": 'p_preview' });
				let p_item = $('<div/>', { "class": 'p_item' });
				
				p_text.append(files[i].name);

				let reader = new FileReader();
				reader.onload = function(e) {
				  $(p_preview).css('background-image', "url(" + e.target.result + ")");
				}
				reader.readAsDataURL(files[i]);
				
				p_close.append('×');
				p_close.click( function(e){
					files.splice(e.target.getAttribute("ind"), 1);
					refresh_all_preloads_html();
				});
				
				p_item.append(p_text);
				p_item.append(p_preview);
				p_item.append(p_close);
				$('.preloads').append(p_item);
			}
	}
	
	refresh_all_preloads_html();
	
//-------------AJAX-отправка форм
	//-----------------------------------------------------------------------
	//             Валидация форм
	//-----------------------------------------------------------------------
	
	//Добавит/снимет визуальное оформление ошибки с текстом о том, что поле обязательное. return true/false - прошло ли валидацию. ChangeVisual - true/false =false не меняет внешний вид поля
	function ValidateRequiredField(fieldQuerySelector, ChangeVisual)
	{
		let result = true;
		
		let field = $(fieldQuerySelector)[0];
		
		if (ChangeVisual == true)
		{
			$(field).removeClass('error');						//очищаем старое оформление ошибок
			$(field).parent().find( '.myTooltip' ).remove();	//очищаем старые сообщения ошибок
		}

		if (!$(field).val() || $(field).val().trim().length == 0)
		if (!$(field).select3Val() || $(field).select3Val().trim().length == 0) //для кастомного select3
		{
			result = false;
			
			if (ChangeVisual == true)
			{
				$(field).addClass( 'error' );
				
				let errText = 'обязательное поле';		//12.09.19
				let tooltip = $( '<div/>', { "class": 'myTooltip' });
				tooltip.append(errText);
				$(field).parent().append(tooltip); //добавляем элемент к обертке. Сработает только если есть обертка
			}
		}

		return result;
	}
	
	//var regExp = new RegExp(...), changeVisual - true/false. =false не меняет внешний вид поля, errorText - текст ошибки, выводимой пользователю (если changeVisual == true)
	function ValidateFieldByRegExp(fieldQuerySelector, changeVisual, errorText, regExp)
	{
		let result = true;
		
		let field = $(fieldQuerySelector)[0];
		
		if (changeVisual == true)
		{
			$(field).removeClass('error');						//очищаем старое оформление ошибок
			$(field).parent().find( '.myTooltip' ).remove();	//очищаем старые сообщения ошибок
		}
		
		let value = $(field).val().trim();
	
		if (!regExp.test(value))
		{
			result = false;
			
			if (changeVisual == true)
			{
				$(field).addClass( 'error' );
				
				let errText = errorText;
				let tooltip = $( '<div/>', { "class": 'myTooltip' });
				tooltip.append(errText);
				$(field).parent().append(tooltip); //добавляем элемент к обертке. Сработает только если есть обертка
			}
		}
		
		return result;
	}
	
	//Добавит/снимет визуальное оформление ошибки с текстом о том, что email заполнен неверно. return true/false - прошло ли валидацию. ChangeVisual - true/false. =false не меняет внешний вид поля
	function ValidateEmail(fieldQuerySelector, changeVisual)
	{
		var mailRegExp = /^[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/i;
		let errText = 'некорректный e-mail';
		return ValidateFieldByRegExp(fieldQuerySelector, changeVisual, errText, mailRegExp);
	}
	
	//ChangeVisual - true/false. =false не меняет внешний вид поля
	function ValidatePhone(fieldQuerySelector, changeVisual)
	{
		var phoneRegExp = /^(\+7|7|8)+(([0-9,\s,\-,\(,\)]){10,16})$/; //писал сам
		let errText = 'телефон заполнен неверно';
		return ValidateFieldByRegExp(fieldQuerySelector, changeVisual, errText, phoneRegExp);
	}
	
	//ChangeVisual - true/false. =false не меняет внешний вид поля
	function ValidateSite(fieldQuerySelector, changeVisual)
	{
		var siteRegExp = /^(http(s)?:\/\/)?([a-zA-Z0-9\u0410-\u044f\u0401\u0451]{1}[-a-zA-Z0-9\u0410-\u044f\u0401\u0451]{0,254}[a-zA-Z0-9\u0410-\u044f\u0401\u0451]{1}[.]{0,1}){1,}[.]{1}([a-zA-Z0-9\u0420\u0424\u0440\u0444]{1}[-a-zA-Z0-9\u0420\u0424\u0440\u0444]{0,6}[a-zA-Z0-9\u0420\u0424\u0440\u0444]{1}){1}([:/?#]{1}([-a-zA-Z0-9\u0410-\u044f\u0401\u0451@:%_+.~#?&/=$!*'()\[\],]{0,})){0,}$/gi;//писал сам, https://regexr.com/4kco1
		let errText = 'сайт заполнен неверно';
		return ValidateFieldByRegExp(fieldQuerySelector, changeVisual, errText, siteRegExp);
	}
	
	//валидация всех форм
	function Validate(formId)
	{
		//!!!!!!!!!!---------------------ОТЛАДКА
		//return true;//!!!!!!!!!!---------------------ОТЛАДКА
		//!!!!!!!!!!---------------------ОТЛАДКА
		
		if (formId == 'calculation_form')
		{
			let result = true;
			
			//если нет - result = false;
			
			let qs5 = "#" + formId + " " + "[name='site-name']";
			let res5 = ValidateRequiredField(qs5, true) && ValidateSite(qs5, true);				
			if (result && !res5) //если это - первый неправильный, 
				scrollTo(qs5, 500); //то скроллим к нему
			result = result && res5;
			
			let qs3 = "#" + formId + " " + "[name='bitrix']";
			let res3 = ValidateRequiredField(qs3, true);
			if (result && !res3) //если это - первый неправильный, 
				scrollTo(qs3, 500); //то скроллим к нему
			result = result && res3;

			let qs2 = "#" + formId + " " + "[name='user-name']";
			let res2 = ValidateRequiredField(qs2, true);
			if (result && !res2) //если это - первый неправильный, 
				scrollTo(qs2, 500); //то скроллим к нему
			result = result && res2;
			
			let qs4 = "#" + formId + " " + "[name='user-mail']";
			let res4 = ValidateRequiredField(qs4, true) && ValidateEmail(qs4, true);				
			if (result && !res4) //если это - первый неправильный, 
				scrollTo(qs4, 500); //то скроллим к нему
			result = result && res4;
			
			let qs6 = "#" + formId + " " + "[name='user-phone']";
			let res6req = ValidateRequiredField(qs6, false); //телефон не обязательный, 
			let res6 = (!res6req) || (res6req && ValidatePhone(qs6, true)); // но если он заполнен, то должен быть заполнен верно
			if (result && !res6) //если это - первый неправильный, 
				scrollTo(qs6, 500); //то скроллим к нему
			result = result && res6;

			let qs1 = "#" + formId + " " + "[name='site-problem']";
			let res1 = ValidateRequiredField(qs1, true);
			if (result && !res1) //если это - первый неправильный, 
				scrollTo(qs1, 500); //то скроллим к нему
			result = result && res1;

			return result;
		}
		else if (formId == 'popup_form')
		{
			let result = true;
			
			//если нет - result = false;
			
			result = ValidateRequiredField("#" + formId + " " + "[name='user-name_modal']", true) && result;
			result = ValidateRequiredField("#" + formId + " " + "[name='package']", true) && result;			//12.09.19
			result = ValidateRequiredField("#" + formId + " " + "[name='tariff']", true) && result;				//12.09.19
			result = (ValidateRequiredField("#" + formId + " " + "[name='user-mail_modal']", true)) ? 
						ValidateEmail("#" + formId + " " + "[name='user-mail_modal']", true) && result : 
						false;
			result = (ValidateRequiredField("#" + formId + " " + "[name='user-linksite_modal']", true)) ?
						ValidateSite("#" + formId + " " + "[name='user-linksite_modal']", true) && result : 
						false;
						
			result = (ValidateRequiredField("#" + formId + " " + "[name='user-phone_modal']", false)) ?
						ValidatePhone("#" + formId + " " + "[name='user-phone_modal']", true) && result :
						result; //телефон не обязательный, но если заполнен, то должен быть заполнен верно
			
			return result;
		}
		
		return false;
	}

//-------------AJAX-отправка форм
	//-----------------------------------------------------------------------
	//             Форма снизу, событие SUBMIT
	//-----------------------------------------------------------------------	

	$('.calculation-form__form').submit(function(event) {
		event.stopPropagation(); // Прекращаем дальнейшую передачу текущего события.
		event.preventDefault(); // Запрещаем стандартное поведение для кнопки submit
		
		//Валидация
		if (!Validate('calculation_form'))
			return;
		
		var button = $(this).find('.calculation-form__btn');
		let formTargetId = $(this).attr("id");

		var formserialize = new FormData(this);
		
		var data = new FormData();
		
		$.each(files, function(key, value){
			data.append('files'+key, value);
		});
		
		data.append('formId', formTargetId);
		
		data.append('my_file_upload', formserialize.get("my_file_upload").trim());

		data.append('name', formserialize.get("user-name").trim());
		data.append('phone', formserialize.get("user-phone").trim());
		data.append('site', formserialize.get("site-name").trim());
		data.append('bitrix', mySelect3bitrix.Value());
		data.append('problem', formserialize.get("site-problem"));
		data.append('links', formserialize.get("site-problem-links"));
		data.append('device', formserialize.get("user-device"));
		data.append('mail', formserialize.get("user-mail").trim());
		data.append('c', calculation_form_clicks);
		data.append('k', calculation_form_keystrokes);
		
		if (formserialize.get("user-device"))
		{
			var info = "";
			
			//Информация об устройстве пользователя
			var user = detect.parse(navigator.userAgent);
			var main_info = '<b>Браузер пользователя:</b> ' + user.browser.family + ' ' + user.browser.version + '; <b>ОС пользователя:</b> ' + user.os.name + '. <br>';
			
			info += main_info;
			
			if (yaCounter54779350)
			{
				var ymClientID = yaCounter54779350.getClientID();
				if (ymClientID)
				{
					info += '<b>Яндекс метрика ClientID:</b> ' + ymClientID + '. <br>';
				}
				else
				{
					console.log("Нет найден ClientID яндекс метрики. См. main.js");
				}
			}
			else
			{
				console.log("Нет найден указанный yaCounterXXXXXX. См. main.js");
			}
			var notInclude = ['vendorSub','productSub','vendor','appCodeName','appName','appVersion','platform','product','userAgent','plugins','mimeTypes']; //поля navigator, которые НЕ включать в отчет
			
			var _navigator = {};
			for (var i in navigator) _navigator[i] = navigator[i]; //JSON.stringify напрямую к navigator не работает
			var navData = JSON.parse(JSON.stringify(_navigator));//чтобы преобразовать все в строку и отбросить функции и процую шелупонь
			
			for (var key in navData) {
				if (notInclude.indexOf(key) === -1)
				{
					var value = navData[key];
					if ((value !== '') && (value !== null) && (typeof value !== 'undefined') && (JSON.stringify(value) != JSON.stringify({})))
						info += '<b>' + key + ':</b> ' + JSON.stringify(value) + '; ';
				}
			}

			info = '<div style="font-size: 0.8em;">' + info + '</div>';
			
			data.append('device_details', info);
		}
		
		if (formserialize.get("user-phone"))
			data.append('way_to_contact', mySelect3calcform_contactWay.Value());

		$(button).html('Форма отправлена');
		$(button).prop('disabled',true);
		
		$.ajax({
			type: "POST",
			url: "/ajax/rest.php",
			data: data,
			cache: false,
			processData: false, // NEEDED, DON'T OMIT THIS
			contentType: false, // NEEDED, DON'T OMIT THIS (requires jQuery 1.6+)
			dataType: 'json',
			success: function(respond){
				//Два случая: успех и ошибка валидации на сервере				
				//Успех
				if (respond.success == 'true') //В respond.success ключ success называется так, потому что так его отправил php-обработчик. С respond.error_type и respond.error_message аналогично
				{
					console.log(JSON.stringify(respond));
					let leadidtext = (respond.leadid) ? 'Номер Вашей заявки ' + respond.leadid + ". " : "";
					if (!respond.leadid)
						console.log('Не удалось получить id лида');
					ShowMyMessage("Спасибо за заявку! " + leadidtext + "В ближайшее время наш менеджер свяжется с Вами для уточнения деталей.", '');
					if (respond.leadid)
						$(button).html(leadidtext);
				}
				//Ошибка
				else if (respond.success == 'false')
				{
					console.log(JSON.stringify(respond));
					if (respond.error_type == 'external_error')
						ShowMyMessage(respond.error_message, 'danger');
					$(button).html('Отправить заявку');
					$(button).prop('disabled',false);
				}
				else
					console.log('Не удалось распознать ответ сервера: \n' + JSON.stringify(respond));
			}
			
			,error: function(xhr, status, error)
			{
				$(button).html('Отправить заявку');
				$(button).prop('disabled',false);
				ShowMyMessage('Не удалось отправить заявку. Попробуйте еще раз через некоторое время или свяжитесь с нами по контактному номеру', 'danger');
				
				console.log('ajaxError xhr:', xhr); // выводим значения переменных
				console.log('ajaxError status:', status);
				console.log('ajaxError error:', error);

				// соберем самое интересное в переменную
				var errorInfo = 'Ошибка выполнения запроса: '
						+ '\n[' + xhr.status + ' ' + status   + ']'
						+  ' ' + error + ' \n '
						+ xhr.responseText
						+ '<br>'
						+ xhr.responseJSON;

				console.log('ajaxError:', errorInfo); // в консоль
				//alert(errorInfo); // если требуется, то и на экран
			}
		});
	});

//-------------AJAX-отправка форм
	//-----------------------------------------------------------------------
	//             js-всплывающая форма, событие SUBMIT
	//-----------------------------------------------------------------------

	$('.popup-form__form').submit(function(event) {
		event.stopPropagation();
		event.preventDefault();
		
		//Валидация
		if (!Validate('popup_form'))
			return;
		
		$('#ModalLong').modal('hide');
		
		var button = $(this).find('.popup-form__btn');
		let formTargetId = $(this).attr("id");
	
		var formserialize = new FormData(this);
		
		var data = new FormData();
		
		data.append('formId', formTargetId);
		
		data.append('name', formserialize.get("user-name_modal").trim());
		data.append('site', formserialize.get("user-linksite_modal").trim());
		data.append('package', mySelect3package.Value()); //12.09.19
		data.append('tariff', mySelect3tariff.Value()); //12.09.19
		data.append('phone', formserialize.get("user-phone_modal").trim());
		data.append('mail', formserialize.get("user-mail_modal").trim());
		data.append('c', popup_form_clicks);
		data.append('k', popup_form_keystrokes);
		
		if (formserialize.get("user-phone_modal"))
			data.append('way_to_contact', mySelect3popupform_contactWay.Value());
		
		$(button).html('Форма отправлена');
		$(button).prop('disabled',true);
		
		$.ajax({
			type: "POST",
			url: "/ajax/rest.php",
			data: data,
			cache: false,
			processData: false, // NEEDED, DON'T OMIT THIS
			contentType: false, // NEEDED, DON'T OMIT THIS (requires jQuery 1.6+)
			dataType: 'json',
			success: function(respond){
				//Два случая: успех и ошибка валидации на сервере				
				//Успех
				if (respond.success == 'true') //В respond.success ключ success называется так, потому что так его отправил php-обработчик. С respond.error_type и respond.error_message аналогично
				{
					console.log(JSON.stringify(respond));
					let leadidtext = (respond.leadid) ? 'Номер Вашей заявки ' + respond.leadid + ". " : "";
					if (!respond.leadid)
						console.log('Не удалось получить id лида');
					ShowMyMessage("Спасибо за заявку! " + leadidtext + "В ближайшее время наш менеджер свяжется с Вами для уточнения деталей.", '');
					if (respond.leadid)
					{
						$(button).html(leadidtext);
						$('[data-toggle="modal"]').html(leadidtext); //2 кнопки вызова всплывающей формы
					}
				}
				//Ошибка
				else if (respond.success == 'false')
				{
					console.log(JSON.stringify(respond));
					if (respond.error_type == 'external_error')
						ShowMyMessage(respond.error_message, 'danger');
					$(button).html('Отправить заявку');
					$(button).prop('disabled',false);
				}
				else
					console.log('Не удалось распознать ответ сервера: \n' + JSON.stringify(respond));
			}
			
			,error: function(xhr, status, error)
			{
				$(button).html('Отправить заявку');
				$(button).prop('disabled',false);
				ShowMyMessage('Не удалось отправить заявку. Попробуйте еще раз через некоторое время или свяжитесь с нами по контактному номеру', 'danger');
				
				console.log('ajaxError xhr:', xhr); // выводим значения переменных
				console.log('ajaxError status:', status);
				console.log('ajaxError error:', error);

				// соберем самое интересное в переменную
				var errorInfo = 'Ошибка выполнения запроса: '
						+ '\n[' + xhr.status + ' ' + status   + ']'
						+  ' ' + error + ' \n '
						+ xhr.responseText
						+ '<br>'
						+ xhr.responseJSON;

				console.log('ajaxError:', errorInfo); // в консоль
				//alert(errorInfo); // если требуется и то на экран
			}
		});
	});


//-----------------------------------------------------------------------
//             Защита от ботов
//-----------------------------------------------------------------------

//Нижняя форма
var calculation_form_clicks = 0;
document.querySelector('#calculation_form').addEventListener(
	"click", 
	function (event) {
		calculation_form_clicks = calculation_form_clicks + 1;
	},
	true //3й аргумент - погружение события
	);
var calculation_form_keystrokes = 0;
document.querySelector('#calculation_form').addEventListener(
	"keydown", 
	function (event) {
		calculation_form_keystrokes = calculation_form_keystrokes + 1;
	},
	true //3й аргумент - погружение события
	);

//Верхняя форма
var popup_form_clicks = 0;
document.querySelector('#popup_form').addEventListener(
	"click", 
	function (event) {
		popup_form_clicks = popup_form_clicks + 1;
	},
	true //3й аргумент - погружение события
	);
var popup_form_keystrokes = 0;
document.querySelector('#popup_form').addEventListener(
	"keydown", 
	function (event) {
		popup_form_keystrokes = popup_form_keystrokes + 1;
	},
	true //3й аргумент - погружение события
	);

//-----------------------------------------------------------------------
//             Летающие подсказки-placeholder'ы
//-----------------------------------------------------------------------

//летающая подсказка-placeholder
//Flying_Placeholder - класс обертки для label, в котором текст placeholder'а и input'а или textarea

	let wraps = document.querySelectorAll('.Flying_Placeholder');
	for (let i = 0; i < wraps.length; i++)
	{
		let flying_label = wraps[i].querySelector('label');
		let inp = wraps[i].querySelector("input, textarea, select");
		$(flying_label).click(function(event) {
			inp.focus();
		});

		$(inp).on ( "focus" , function() {
			//input/textarea событие focus - фокус элемента
			$(flying_label).addClass("focus");
		});
		$(inp).on( "blur" , function() {
			//input/textarea событие blur - фокус снят
			if (!$(this).val() || $(this).val().trim().length == 0) {
					$(flying_label).removeClass("focus");
			}	
		});

		//при загрузке
		if ($(inp).val() && $(inp).val().trim().length != 0) //если поле заполнено
			$(flying_label).addClass("focus");
	}
});

//-----------------------------------------------------------------------
//             Виджет bitrix24
//-----------------------------------------------------------------------


$( document ).ready(function (){
	function toggleWidjet(){
		if(!$('.bx-livechat-wrapper').hasClass('bx-livechat-show') && !$('.b24-widget-button-social').hasClass('b24_hover')){
			$('.b24-widget-button-social').toggleClass('b24_adm');
		}	
	}
	function toggleChat(){
		if($('.bx-livechat-wrapper').hasClass('bx-livechat-show')){
			$('.b24-widget-button-social-item.b24-widget-button-openline_livechat').addClass('b24-adm-unbind');
		}
		$('.bx-livechat-control-box').click(function() {
			$('.b24-widget-button-social-item.b24-widget-button-openline_livechat').removeClass('b24-adm-unbind');
		});
	}
	/*setInterval(function() {
		 toggleWidjet()
	}, 30000);*/
	setTimeout( function (){
		toggleWidjet(); //первый запуск спустя 3 секунды
	}, 3000);
	$(".b24-widget-button-social").mouseover(function() {
	  $(this).addClass('b24_hover');
	});
	$(".b24-widget-button-social").mouseout(function() {
	  $(this).removeClass('b24_hover');
	});
	$(document).mouseup(function (e){
		var div = $(".bx-livechat-wrapper");
		if (!div.is(e.target) && div.has(e.target).length === 0 && $('.bx-livechat-wrapper').hasClass('bx-livechat-show')) {
			$('.b24-widget-button-inner-mask').trigger('click');
			$('.b24-widget-button-social-item.b24-widget-button-openline_livechat').removeClass('b24-adm-unbind');
		}
	})
	$('.b24-widget-button-social-item.b24-widget-button-openline_livechat').click(function() {
		toggleChat();
	});
	/*let qs = '.b24-widget-button-inner-item';
	$( qs ).hover(function (){
		$( '.b24-widget-button-pulse-animate' ).removeClass( 'b24-widget-button-pulse-animate_1anim' );
		$( '.b24-widget-button-pulse-animate' ).addClass( 'b24-widget-button-pulse-animate_noAnim' );
		setTimeout( function (){$( '.b24-widget-button-pulse-animate' ).addClass( 'b24-widget-button-pulse-animate_1anim' );}, 200);
		setTimeout( function (){$( '.b24-widget-button-pulse-animate' ).removeClass( 'b24-widget-button-pulse-animate_noAnim' );}, 200);
	});*/
});

		/*Anchor active when clicked*/
		$(function() {
			$('.btn-scroll').click(function() { 
			  $('.btn-scroll').not(this).removeClass('active-anchor');
			  $(this).toggleClass('active-anchor');
			});
		  });
	
		/*Anchor active when scrolled*/
		// $(window).scroll(function () {
		// 	var scrollDistance = $(window).scrollTop();
		
		// 	$('section').each(function (i) {
		// 		if ($(this).position().top <= scrollDistance ) {
		// 			$('.btn-scroll').not(this).removeClass('active-anchor');
		// 			$('.btn-scroll').eq(i).addClass('active-anchor');
		// 		}
		// 	});
		
		// }).scroll();