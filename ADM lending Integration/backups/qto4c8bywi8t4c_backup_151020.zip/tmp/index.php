﻿<?php

require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/data.php';

?>
<!DOCTYPE html>
<html lang="ru">

<head>

	<meta charset="UTF-8">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<meta name="description" content="Техническая поддержка и доработка сайтов на 1С-Битрикс. Разовая и постоянная техподдержка. Пакетные депозиты. Гибкое ценообразование. Поминутный учет времени. Специальные предложения для студий и агентств.">
	<meta name="keywords" content="поддержка сайта 1С-Битрикс, доработка сайта 1С-Битрикс, постоянная техподдержка сайта, сопровождение сайта Битрикс, разработка битрикс, программист битрикс, Битрикс, bitrix">

	<meta property="og:title" content="Техподдержка сайтов на «1С-Битрикс»" />
	<meta property="og:type" content="article" />
	<meta property="og:description" content="Сопровождение интернет-проектов на 1С-Битрикс. Доработка функционала.
	Постоянная техподдержка. Депозитные тарифы." />

	<meta property="og:image" content="https://bitrixsupport.adm-center.ru/img/large_img.png" />
	<meta property="og:image:type" content="image/png" />
	<meta property="og:image:width" content="640" />
	<meta property="og:image:height" content="325" />
	<meta property="og:image" content="https://bitrixsupport.adm-center.ru/img/imagemsngr.png" />
	<meta property="og:image:type" content="image/png" />
	<meta property="og:image:width" content="400" />
	<meta property="og:image:height" content="400" />

	<meta property="og:url" content="https://bitrixsupport.adm-center.ru/?v=8" />

	<meta property="og:locale" content="ru_RU" />
	<meta property="og:site_name" content="Поддержка сайтов на 1С-Битрикс" />

	<title>Поддержка сайтов на 1С-Битрикс - от 1200 руб</title>
	<link rel="icon" href="favicon.ico" type="image/x-icon">
	<script type="application/ld+json">
	{
		"@context": "http://schema.org",
		"@type": "Service",
		"name": "Digital-агентство «ADM»",
		"description": "Сопровождение интернет-проектов на 1С-Битрикс. Доработка функционала. Постоянная техподдержка. Депозитные тарифы.",
		"logo": "https://bitrixsupport.adm-center.ru/img/small_img.jpg",
		"areaServed": {
		"@type": "Place",
		"address": {
			"@type": "PostalAddress",
			"addressLocality": "г. Новочеркасск",
			"addressRegion": "Ростовская область",
			"streetAddress": "Ермака 5",
			"telephone" : "+7 (863) 226-90-95",
			"email": "mailto:mail@adm-center.ru"
		},
		"url": "https://bitrixsupport.adm-center.ru/"
		},
		"offers": [
		{
		"@type": "Offer",
		"name": "Настройка и доработка интернет-магазина",
		"description": "Настройка и доработка корзины, каталогов, фильтра товаров, карточек товаров, скидок, купонов. Кастомизация оформления заказов и многоскладовости на «1С-Битрикс».",
		"priceCurrency": "RUB"
		},
		{
		"@type": "Offer",
		"name": "Настройка штатного функционала",
		"description": "Настройка компонентов сайта на «1С-Битрикс». Настройка уведомлений, рассылки, аналитики, проактивной защиты, резервного копирования и пр.",
		"priceCurrency": "RUB"
		},
		{
		"@type": "Offer",
		"name": "Подключение платежных систем",
		"description": "Подключение и настройка платежных систем: Сбербанк, Яндекс-касса, PayMaster и пр. Подключение онлайн-касс.",
		"priceCurrency": "RUB"
		},
		{
		"@type": "Offer",
		"name": "Подключение служб доставки",
		"description": "Подключение и настройка служб доставки: СДЭК, PickPoint и пр. Подключение интерактивной карты и системы геолокации.",
		"priceCurrency": "RUB"
		},
		{
		"@type": "Offer",
		"name": "Разработка модулей и компонентов",
		"description": "Разработка индивидуального функционала в виде модулей, отдельных блоков и компонентов сайта для «1С-Битрикс».",
		"priceCurrency": "RUB"
		},
		{
		"@type": "Offer",
		"name": "Разработка форм",
		"description": "Разработка форм захвата с защитой от спама. Сбор заявок на почту, в админку или в CRM-систему.",
		"priceCurrency": "RUB"
		},
		{
		"@type": "Offer",
		"name": "Разработка почтовых шаблонов",
		"description": "Разработка индивидуальных почтовых шаблонов для рассылки через систему «1С-Битрикс».",
		"priceCurrency": "RUB"
		},
		{
		"@type": "Offer",
		"name": "Разработка новых блоков",
		"description": "Разработка индивидуальных блоков на готовом сайте.",
		"priceCurrency": "RUB"
		},
		{
		"@type": "Offer",
		"name": "Перенос сайта на «1С-Битрикс»",
		"description": "Перенос каталогов, верстки, функционала с любой системы на платформу «1С-Битрикс: Управление сайтом».",
		"priceCurrency": "RUB"
		},
		{
		"@type": "Offer",
		"name": "Восстановление системы после сбоя",
		"description": "Восстановление сайта на «1С-Битрикс» после неудачного обновления или вирусного заражения",
		"priceCurrency": "RUB"
		},
		{
		"@type": "Offer",
		"name": "Настройка композитного режима",
		"description": "Композитный сайт – запатентованная технология «1С-Битрикс», которая позволяет ускорить работу сайта до 100х раз.",
		"priceCurrency": "RUB"
		},
		{
		"@type": "Offer",
		"name": "Аудит производительности",
		"description": "Диагностика скорости работы сайта. Анализ производительности сервера или хостинга, корректности работы скриптов и БД.з.",
		"priceCurrency": "RUB"
		},
		{
		"@type": "Offer",
		"name": "Аудит кода",
		"description": "Анализ валидности html и css. Анализ корректности адаптивной верстки.",
		"priceCurrency": "RUB"
		},
		{
		"@type": "Offer",
		"name": "Аудит компонентной базы",
		"description": "Анализ корректности работы компонентов сайта и отдельных его подсистем.",
		"priceCurrency": "RUB"
		},
		{
		"@type": "Offer",
		"name": "Интеграция с Мой.Склад",
		"description": "Настройка синхронизации интернет-магазина с «Мой склад». Интеграция как через штатные средства «1С-Битрикс», так и через API «Мой склад».",
		"priceCurrency": "RUB"
		},
		{
		"@type": "Offer",
		"name": "Интеграция с Битрикс24",
		"description": "Настройка сбора лидов и заказов в CRM-систему. Подключение чатов и виджетов Битрикс24.",
		"priceCurrency": "RUB"
		},
		{
		"@type": "Offer",
		"name": "Нетиповая интеграция",
		"description": "Разработка интеграции с использование нештатных средств. Разработка индивидуальных планов интеграций.",
		"priceCurrency": "RUB"
		},
		{
		"@type": "Offer",
		"name": "Редизайн сайта",
		"description": "Разработка нового оформления сайта и отдельных его элементов. Доработка текущего интерфейса.",
		"priceCurrency": "RUB"
		},
		{
		"@type": "Offer",
		"name": "Разработка мобильной версии сайта",
		"description": "Разработка адаптивного дизайна и вёрстка адаптива для готового сайта. Переработка адаптивности отдельных элементов сайта.",
		"priceCurrency": "RUB"
		},
		{
		"@type": "Offer",
		"name": "Разработка промо-страниц",
		"description": "Разработка адаптивных промо-страниц под конкретные акции и предложения.",
		"priceCurrency": "RUB"
		},
		{
		"@type": "Offer",
		"name": "Разработка контента для сайта",
		"description": "Написание и размещение текстов, новостей, статей. Создание графических материалов, видеороликов и инфографики.",
		"priceCurrency": "RUB"
		},
		{
		"@type": "Offer",
		"name": "Виджеты и аналитика",
		"description": "Подключение внешних виджетов, чатов и систем аналитики: Яндекс.Метрика, Google Analytics.",
		"priceCurrency": "RUB"
		},
		{
		"@type": "Offer",
		"name": "Подготовка инструкций",
		"description": "Написание пошаговых инструкций по работе с сайтом на «1С-Битрикс» для менеджеров и администраторов сайта.",
		"priceCurrency": "RUB"
		},
		{
		"@type": "Offer",
		"name": "Обучение",
		"description": "Обучение работе с сайтом на «1С-Битрикс»: заполнение и редактирование каталога, новостей. Работа с заказами. Рассылки. Скидки. Купоны. Аналитика.",
		"priceCurrency": "RUB"
		},
		{
		"@type": "Offer",
		"name": "Разовая задача",
		"description": "Приём заявок WhatsApp, Telegram, Skype, Viber. Отчёт о затраченном времени на задачу по трекеру. Бонус - Диагностика БЕСПЛАТНО!",
		"price": "1800 рублей/час",
		"priceCurrency": "RUB"
		},
		{
		"@type": "AggregateOffer",
		"name": "Постоянная техподдержка",
		"description": "Гарантия стабильности и работоспособности сайта, фиксированный набор ежемесячных услуг. Бонус: Первый месяц БЕСПЛАТНО*",
		"lowPrice": "от 1800 рублей/месяц",
		"priceCurrency": "RUB"
		},
		{
		"@type": "AggregateOffer",
		"name": "Постоянная техподдержка",
		"description": "Гарантия выделенного времени, экономия средств. Бонус: Аудит сайта БЕСПЛАТНО",
		"lowPrice": "от 1200 рублей/месяц",
		"priceCurrency": "RUB"
		},
		{
		"@type": "Offer",
		"name": "Техподдержка для корпоративных сайтов",
		"description": "Постоянная техподдержка корпоративного сайта на «1С-Битрикс» - тариф стандарт",
		"price": "1200 рублей",
		"priceCurrency": "RUB"
		},
		{
		"@type": "Offer",
		"name": "Техподдержка для корпоративных сайтов: тариф эксперт",
		"description": "Постоянная техподдержка корпоративного сайта на «1С-Битрикс» - тариф эксперт",
		"price": "7200 рублей",
		"priceCurrency": "RUB"
		},
		{
		"@type": "Offer",
		"name": "Техподдержка для корпоративных сайтов: тариф бизнес",
		"description": "Постоянная техподдержка корпоративный сайт на «1С-Битрикс» - тариф бизнес",
		"price": "25600 рублей",
		"priceCurrency": "RUB"
		},
		{
		"@type": "Offer",
		"name": "Техподдержка для интернет-магазина: тариф стандарт",
		"description": "Постоянная техподдержка интернет-магазин на «1С-Битрикс» - тариф стандарт",
		"price": "2800 рублей",
		"priceCurrency": "RUB"
		},
		{
		"@type": "Offer",
		"name": "Техподдержка для интернет-магазина: тариф эксперт",
		"description": "Постоянная техподдержка интернет-магазин на «1С-Битрикс» - тариф эксперт",
		"price": "8400 рублей",
		"priceCurrency": "RUB"
		},
		{
		"@type": "Offer",
		"name": "Техподдержка для интернет-магазина: тариф бизнес",
		"description": "Постоянная техподдержка интернет-магазин на «1С-Битрикс» - тариф бизнес",
		"price": "27400 рублей",
		"priceCurrency": "RUB"
		},
		{
		"@type": "Offer",
		"name": "Техподдержка для интернет-магазина: тариф бизнес-pro",
		"description": "Постоянная техподдержка интернет-магазин на «1С-Битрикс» - тариф бизнес-pro",
		"price": "47200 рублей",
		"priceCurrency": "RUB"
		},
		{
		"@type": "Offer",
		"name": "Депозит: пакет 'Свободный'",
		"description": "Депозит: пакет 'Свободный'. Стоимость часа специалиста - 1800 руб. Количество нормо-часов: до 10.",
		"price": "1800 рублей",
		"priceCurrency": "RUB"
		},
		{
		"@type": "Offer",
		"name": "Депозит: пакет 'Базовый'",
		"description": "Депозит: пакет 'Базовый'. Стоимость часа специалиста - 1600 руб. Количество нормо-часов: 10.",
		"price": "16000 рублей",
		"priceCurrency": "RUB"
		},
		{
		"@type": "Offer",
		"name": "Депозит: пакет 'Стандарт'",
		"description": "Депозит: пакет 'Стандарт'. Стоимость часа специалиста - 1400 руб. Количество нормо-часов: 30.",
		"price": "42000 рублей",
		"priceCurrency": "RUB"
		},
		{
		"@type": "Offer",
		"name": "Депозит: пакет 'Бизнес'",
		"description": "Депозит: пакет 'Бизнес'. Стоимость часа специалиста - 1200 руб. Количество нормо-часов: 50.",
		"price": "60000 рублей",
		"priceCurrency": "RUB"
		}
	]
	}
	</script>

	<!-- Bootstrap -->
	<!--link href="css/bootstrap.css" rel="stylesheet"-->
	<!--link href="css/bootstrap_modified_16.07.19.php" rel="stylesheet"-->
	<link href="/css/bootstrap_modified_16.07.19.min.css" rel="stylesheet">
	<!-- Custom -->
	<link href="https://fonts.googleapis.com/css?family=Roboto:300|Roboto+Condensed:400,500|Open+Sans:300,400,600,700,800&amp;subset=cyrillic" rel="stylesheet">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.0/css/all.css" integrity="sha384-Mmxa0mLqhmOeaE8vgOSbKacftZcsNYDjQzuCOm6D02luYSzBG8vpaOykv9lFQ51Y" crossorigin="anonymous">

	<link rel="stylesheet" href="/css/flipper-responsive.css">
	<link rel="stylesheet" href="/css/style.min.css">
	<link rel="stylesheet" href="/css/ion.rangeSlider.css">
	<link rel="stylesheet" href="/css/zebra_datepicker.css">
	<link rel="stylesheet" href="/css/jquery.nice-number.css">
	<link rel="stylesheet" href="/css/calculator.select3.min.css">
	<link rel="stylesheet" href="/css/calculator.min.css">
</head>

<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/data_js.php';
?>

<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/b24_widget.php';
?>

<body>

	<?php
	require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/yandex_metrika.php';
	?>

	<div class="wrap">

		<div class="hamburger"></div>
		<div class="menu">
			<div class="container-fluid pl-0 pr-0 h-100">
				<div class="row no-gutters h-100">
					<div class="col-12">
						<!-- лого и стрелочка -->
						<div class="menu-top">
							<div class="menu-top_arrow"></div>
							<div class="menu-logo">
								<img src="img/header/logo-white.svg" alt="ADM">
							</div>
						</div>
						<!-- ./menu-top -->

						<ul class="menu-list">
							<li class="menu-item">
								<a href="#aboutServices" class="menu-link btn-scroll">
									Что мы предлагаем
								</a>
							</li>
							<!-- li -->
							<li class="menu-item">
								<a href="#subscription" class="menu-link btn-scroll">
									Постоянная техподдержка
								</a>
							</li>
							<!-- li -->
							<li class="menu-item">
								<a href="#support" class="menu-link btn-scroll">
									Депозиты
								</a>
							</li>
							<!-- li -->
							<li class="menu-item">
								<a href="#support-services" class="menu-link btn-scroll">
									Услуги техподдержки
								</a>
							</li>
							<!-- li -->
							<li class="menu-item">
								<a href="#recommend" class="menu-link btn-scroll">
									Как мы работаем
								</a>
							</li>
							<!-- li -->
							<li class="menu-item">
								<a data-toggle="modal" data-target="#calculateTheCostModal" class="menu-link linkForCalcModal">
									Оставить заявку
								</a>
							</li>
							<!-- li -->
							<li class="menu-item">
								<a href="#footer" class="menu-link btn-scroll">
									Контакты
								</a>
							</li>
							<!-- li -->
						</ul>
						<!-- ul -->

						<div class="menu-social">
							<div class="menu-socials-wrap">
								<a href="https://www.facebook.com/admcenter.ru/"><span class="icon-facebook"></span></a>
								<!--a href="#"><span class="icon-vkontakte"></span></a-->
								<!--a href="#"><span class="icon-odnoklassniki"></span></a-->
								<!--a href="#"><span class="icon-twitter"></span></a-->
								<a href="tg://resolve?domain=admasya"><span class="icon-telegram"></span></a>
								<a href="https://www.instagram.com/admcenter/"><span class="icon-instagram"></span></a>
								<a href="whatsapp://send?phone=+79281631100"><span class="icon-whatsapp"></span></a>
								<a href="viber://add?number=79281631100"><span class="icon-viber-brands"></span></a>
								<!--a href="#"><span class="icon-pinterest"></span></a-->
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- ./menu -->

		<div class="scrollcontent">
			<!-- НАЧАЛО БАННЕР -->
			<!-- <div class="banner_wrapper_audit">
				<div class="container banner_in_top">
					<div class="row">
						<div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
							<div class="row justify-content-center">
								<div class="col-12 col-sm-11 col-md-12 col-lg-12 col-xl-12">
									<div class="banner_container d-flex justify-content-between align-items-center">
										<div class="free_audit_banner_wrapper" data-toggle="modal" data-target="#auditModal">
											<div class="free_audit_text_wrapper">
												<span class="free_audit_text">Бесплатный аудит сайта</span>
												<span class="free_audit_price"><s>15000 руб</s> 0руб</span>
												<span class="free_audit_date">до 31 октября 2019г.</span>
												<span class="free_audit_btn">Подробнее...</span>
											</div>
										</div>
										<div class="banner_container_btnclose_wrapper">
											<div class="banner_container_btnclose">
												<div>
													<div class="leftright"></div>
													<div class="rightleft"></div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>

			<div class="banner_wrapper_first_month">
				<div class="container banner_in_top">
					<div class="row">
						<div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
							<div class="row justify-content-center">
								<div class="col-12 col-sm-11 col-md-12 col-lg-12 col-xl-12">
									<div class="banner_container d-flex justify-content-between align-items-center">
										<div class="first_month_banner_wrapper" data-toggle="modal" data-target="#firstMonthModal">
											<div class="first_month_text_wrapper">
												<span class="first_month_text">Первый месяц обслуживания бесплатно</span>
												<span class="first_month_btn">Подробнее...</span>
											</div>
										</div>
										<div class="banner_container_btnclose_wrapper">
											<div class="banner_container_btnclose">
												<div>
													<div class="leftright"></div>
													<div class="rightleft"></div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>

			<div class="banner_wrapper_guarantee">
				<div class="container banner_in_top">
					<div class="row">
						<div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
							<div class="row justify-content-center">
								<div class="col-12 col-sm-11 col-md-12 col-lg-12 col-xl-12">
									<div class="banner_container d-flex justify-content-between align-items-center">
										<div class="guarantee_banner_wrapper" data-toggle="modal" data-target="#guaranteeModal">
											<div class="guarantee_text_wrapper">
												<span class="guarantee_text">Гарантия возврата оплаты</span>
												<span class="guarantee_btn">Подробнее...</span>
											</div>
										</div>
										<div class="banner_container_btnclose_wrapper">
											<div class="banner_container_btnclose">
												<div>
													<div class="leftright"></div>
													<div class="rightleft"></div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div> -->
			<!-- КОНЕЦ БАННЕР -->

			<header class="header">
				<div class="container">
					<div class="row align-items-center">
						<div class="col-6 col-sm-4 col-md-6 col-lg-4">
							<div class="row align-items-end">
								<div class="col-5 col-sm-5 d-md-none d-lg-none">
									<!-- тут был гамбургер -->
								</div>

								<div class="col-7 col-sm-6 col-md-8 col-lg-6">
									<div href="http://adm-center.ru/" class="header-logo">
										<img src="/img/header/logo.svg" alt="ADM">
									</div>
								</div>
							</div>
						</div>

						<div class="col-6 col-sm-8 col-md-6 col-lg-8 d-flex justify-content-end align-items-center">
							<a class="header-phone header-phone__mhidden" href="tel:+7(863)226-90-95">+7 (863) 226-90-95</a>
							<a class="header-btn button forCalcModal" href="" data-toggle="modal" data-target="#calculateTheCostModal">Поставить задачу</a>
							<!-- <button type="button" class="header-btn button" title>
					  Оставить заявку
					</button> -->
						</div>
					</div>
					<!-- /.row -->
				</div>
				<!-- /.container -->
			</header>
			<!-- /.header -->

			<div class="highlights gray_bg">
				<div class="container">
					<div class="row justify-content-between posrel">
						<!-- <div class="col-12 col-sm-6 col-md-7 col-lg-8 col-xl-8">
							<div class="row justify-content-center">
								<div class="col-12 col-sm-11 col-md-12 col-lg-12 col-xl-12">
									<div class="highlights-bg title-bg white_font">Support sites on &#171;1C-Bitrix&#187;</div>
									<h1 class="title highlights__title">Техническая поддержка сайтов на &#171;1С&#8209;Битрикс&#187;</h1>
								</div>
								<div class="col-12 col-sm-11 col-md-12 col-lg-12 col-xl-12">
									<div class="highlights_list_wrapper">
										<ul>
											<li>Три варианта техподдержки</li>
											<li>Гибкая тарификация</li>
											<li>Предварительный расчёт стоимости</li>
											<li>Различные каналы приёма заявок</li>
											<li>Онлайн отчёт</li>
										</ul>
									</div>
								</div>
							</div>
						</div>
						<div class="col-12 col-sm-6 col-md-5 col-lg-4 col-xl-4">
							<div class="row justify-content-center">
								<div class="col-12 col-sm-11 col-md-12 col-lg-12 col-xl-12">
									<div class="request-form">
										
									</div>
								</div>
							</div>
						</div> -->
						<div class="col-10">
						<div itemscope itemtype="http://schema.org/Organization"></div>
							<div class="highlights_techsupport">
								<h1>
									<b>Техподдержка</b> <br>
									<span>сайтов на &laquo;1С-Битрикс&raquo;</span> </h1>
							</div>
							<div class="highlights_list_wrapper">
								<ul class="highlights_list">
									<li class="highlights_list_item">Разовая техподдержка</li>
									<li class="highlights_list_item">Постоянная техподдержка</li>
									<li class="highlights_list_item">Депозитные тарифы</li>
								</ul>
							</div>
							<div class="highlights_btn_wrapper">
								<a class="button btn-scroll highlights_btn" href="#aboutServices">Подробнее</a>
							</div>
						</div>
						<!-- <div class="h-our_awards_wrapper">
							<div class="h-our_awards">
								<ul class="d-flex flex-column justify-content-center">
									<li>
										<a href="https://www.1c-bitrix.ru/partners/293096.php" target="_blank"><img class="move_left" src="img/support/gold-partner.jpg" alt="1C-Bitrix Gold Partner" title="Золотой партнер 1С-Битрикс"></a>
									</li>
									<li>
										<a href="https://www.1c-bitrix.ru/partners/293096.php" target="_blank"><img class="move_left" src="img/support/monitoring.jpg" alt="Monitoring Participant" title="Участник программы качества внедрений 1С-Битрикс"></a>
									</li>
									<li>
										<a href="https://www.1c-bitrix.ru/partners/293096.php" target="_blank"><img class="move_left" src="img/support/kompozit.jpg" alt="Kompozit" title="Композитный сайт"></a>
									</li>
									<li>
										<a href="https://www.1c-bitrix.ru/partners/293096.php" target="_blank"><img class="move_left" src="img/support/1c.jpg" alt="1c-integration" title="Интеграция с 1С"></a>
									</li>
								</ul>
							</div>
						</div> -->
					</div>
				</div>
			</div>

			<section id="support-services" class="support-services">
				<a name="support-services"></a>
				<!--якорь-->
				<div class="container">
					<div class="row align-items-center">
						<div class="col-12">
							<div class="support-services-bg title-bg">Technical support</div>
							<div class="title-before support-title-before">Перечень работ</div>
							<h2 class="title support-services__title">Услуги техподдержки</h2>
						</div>
					</div>
					<!-- /.row -->
					<div class="service-items__scroll">
						<div class="row align-items-start d-inline-flex d-sm-flex flex-nowrap flex-sm-wrap overflow-hidden">
							<?php foreach ($data->all_support_services as $value) { ?>
								<div class="col-sm-4 col-md-4 col-lg-3 col-xl-3 d-flex justify-content-center justify-content-lg-start d-inline-flex">
									<div class="service-item">
										<object data="<?= $value->image ?>" type="image/svg+xml" class="service-item_img">
											<img src="<?= $value->image ?>" alt="<?= $value->title ?>">
										</object>

										<h3 class="service-item_name"><?= $value->title ?></h3>
										<div class="service-item_desc"><?= $value->description ?></div>
									</div>
								</div>
							<?php } ?>
							<div class="col-sm-4 col-md-4 col-lg-3 col-xl-3 d-flex justify-content-center justify-content-lg-start d-inline-flex">
								<div class="service-item no-service">
									<object data="img/support/no_service.svg" type="image/svg+xml" class="service-item_img">
										<img src="img/support/no_service.svg" alt="Нет нужной услуги в списке?">
									</object>
									<h3 class="service-item_name">Нет нужной услуги в списке?</h3>
									<div class="service-item_desc">Отправьте заявку – мы предложим решение:
										<button class="button  question_btn" data-toggle="modal" data-target="#ModalRequest">Отправить заявку</button>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="row d-none d-sm-flex">
						<div class="col-12 col-sm-12 col-md-12 col-lg-12">
							<div class="service-link">Показать все услуги &#187;</div>
						</div>
					</div>
				</div>
				<!-- /.container -->
			</section>

			<section id="aboutServices" class="about-services gray_bg">
				<a name="aboutServices"></a>
				<!--якорь-->
				<div class="container">
					<div class="row align-items-center">
						<div class="col-12">
							<div class="aboutServices-bg title-bg white_font">Support options</div>
							<div class="title-before aboutServices-title-before">Гибкая тарификация</div>
							<h2 class="title aboutServices-title">Варианты техподдержки</h2>
						</div>
					</div>
					<div class="row">
						<div class="col-12 col-sm-12 col-md-4 col-lg-4 col-xl-4">
							<div class="row justify-content-center">
								<div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
									<div class="about-services-desc">
										<div class="about-services-desc-content">
											<h2 class="about-services-title">Разовая задача</h2>

											<!--  <div class="about-services-subtitle">Подходит для:</div> -->
											<div class="about-services-price">
												<div class="about-services-price_name">
													1800
												</div>
												<div class="about-services-price_pricerepmonth_wrapper">
													<div class="about-services_money">
														руб
													</div>
													<div class="about-services_hour">
														ч
													</div>
												</div>
											</div>
											<div class="about-services_title-desc_wrapper">
												<div class="title-desc d-flex align-items-baseline">
													<div class="d-flex align-items-center"><img src="img/done.png" alt="#"></div>
													Приём заявок WhatsApp, Telegramm, Skype, Viber
												</div>
												<div class="title-desc d-flex align-items-baseline">
													<div class="d-flex align-items-center"><img src="img/done.png" alt="#"></div>
													Отчёт о затраченном времени на задачу по трекеру
												</div>
											</div>
											<!-- <h3 class="title-desc-time">Время реакции на заявку до 24 часов</h3> -->
											<div class="support-bonus">
												<div>Бонус:</div>
												Диагностика БЕСПЛАТНО!
											</div>

											<div class="about-services__btn d-flex justify-content-center">
												<a class="button support-detail__btn" href="" data-toggle="modal" data-target="#calculateTheCostModal">Подробнее</a>
											</div>
											<!-- /.about-services__btn -->
										</div>
									</div>
									<!-- /.about-services-desc -->
								</div>
								<!-- /.col-9 -->
							</div>
							<!-- /.row -->
						</div>

						<div class="col-12 col-sm-12 col-md-4 col-lg-4 col-xl-4">
							<div class="row justify-content-center">
								<div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
									<div class="about-services-desc ">
										<div class="poppular">Популярно</div>
										<div class="about-services-desc-content">
											<h2 class="about-services-title">Постоянная техподдержка</h2>

											<!-- <div class="about-services-subtitle">Подходит для:</div> -->
											<div class="about-services-price">
												<div class="about-services-price_name">
													<span>от</span> 1800
												</div>
												<div class="about-services-price_pricerepmonth_wrapper">
													<div class="about-services_money">
														руб
													</div>
													<div class="about-services_hour">
														мес
													</div>
												</div>
											</div>
											<div class="about-services_title-desc_wrapper">
												<div class="title-desc d-flex align-items-baseline">
													<div class="d-flex align-items-center"><img src="img/done.png" alt="#"></div>
													Гарантия стабильности и работоспособности сайта
												</div>
												<div class="title-desc d-flex align-items-baseline">
													<div class="d-flex align-items-center"><img src="img/done.png" alt="#"></div>
													Фиксированный набор ежемесячных услуг
												</div>
											</div>
											<!-- <h3 class="title-desc-time">Время реакции на заявку 15 мин</h3> -->
											<div class="support-bonus">
												<div>Бонус:</div>
												<a href="#" class=" poppular-color" data-toggle="modal" data-target="#firstMonthModal">Первый месяц БЕСПЛАТНО *</a>
											</div>
											<div class="about-services__btn d-flex justify-content-center">
												<a class="button support-detail__btn" href="#subscription" target="_blank" rel="noopener noreferrer">Подробнее</a>
											</div>
											<!-- /.about-services__btn -->
										</div>
									</div>
									<!-- /.about-services-desc -->
								</div>
								<!-- /.col-12 -->
							</div>
							<!-- /.row -->
						</div>
						<div class="col-12 col-sm-12 col-md-4 col-lg-4 col-xl-4">
							<div class="row justify-content-center">
								<div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
									<div class="about-services-desc">
										<div class="profitably">Выгодно</div>
										<div class="about-services-desc-content">
											<h2 class="about-services-title">Депозиты</h2>

											<!--  <div class="about-services-subtitle">Подходит для:</div> -->
											<div class="about-services-price">
												<div class="about-services-price_name">
													<span>от</span> 1200
												</div>
												<div class="about-services-price_pricerepmonth_wrapper">
													<div class="about-services_money">
														руб
													</div>
													<div class="about-services_hour">
														ч
													</div>
												</div>
											</div>
											<div class="about-services_title-desc_wrapper">
												<div class="title-desc d-flex align-items-baseline">
													<div class="d-flex align-items-center"><img src="img/done.png" alt="#"></div>
													Гарантия выделенного времени
												</div>
												<div class="title-desc d-flex align-items-baseline">
													<div class="d-flex align-items-center"><img src="img/done.png" alt="#"></div>
													Экономия средств
												</div>
											</div>
											<div class="support-bonus ">
												<div>Бонус:</div>
												<a href="#" class="profitably-color" data-toggle="modal" data-target="#auditModal">Аудит сайта БЕСПЛАТНО</a>
											</div>

											<div class="about-services__btn d-flex justify-content-center">
												<a class="button support-detail__btn" href="#support" target="_blank" rel="noopener noreferrer">Подробнее</a>
											</div>
											<!-- /.about-services__btn -->
										</div>
									</div>
									<!-- /.about-services-desc -->
								</div>
								<!-- /.col-9 -->
							</div>
							<!-- /.row -->
						</div>

						<!-- 											<div class="col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
							<div class="row justify-content-center">
								<div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
									<div class="about-services-desc">
										<div class="about-services-desc-content">
											<h2 class="about-services-title">Разовая задача</h2>
											<div class="about-services-price">
												<span>от</span> 1800 <span>руб/нормо-час</span>
											</div>
											<div class="title-desc d-flex align-items-center">
												<div class="d-flex align-items-center"><img src="img/done.png" alt="#"></div>
												Для единичных задач
											</div>
											<div class="title-desc d-flex align-items-center">
												<div class="d-flex align-items-center"><img src="img/done.png" alt="#"></div>
												Если нет своего программиста в штате
											</div>
											<div class="support-bonus">
												Диагностика проблемы/кода БЕСПЛАТНО
											</div>
											<div class="about-services__btn d-flex justify-content-center">
												<a class="button btn-scroll support-detail__btn">Подробнее</a>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div> -->

						<!-- 						<div class="col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
							<div class="row justify-content-center">
								<div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
									<div class="about-services-desc">
										<div class="about-services-desc-content">
											<h2 class="about-services-title">Срочная задача</h2>
											<div class="about-services-price">
												<span>от</span> 2700 <span>руб/нормо-час</span>
											</div>
											<div class="title-desc d-flex align-items-center">
												<div class="d-flex align-items-center"><img src="img/done.png" alt="#"></div>
												Для задач со сроком "вчера"
											</div>
											<div class="title-desc d-flex align-items-center">
												<div class="d-flex align-items-center"><img src="img/done.png" alt="#"></div>
												Если надо оперативно, компетентно и надежно
											</div>
											<div class="support-bonus">
												Реагирование на запрос в течении 15 МИНУТ
											</div>
											<div class="about-services__btn d-flex justify-content-center">
												<a class="button btn-scroll support-detail__btn">Подробнее</a>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div> -->

					</div>
					<!-- /.row -->
				</div>
				<!-- /.container -->
			</section>

			<section id="agency" class="agency ">
				<div class="container">
					<div class="row">
						<div class="col-12">
							<div class="agency_inner">
								<div class="agency_title">
									<h2>Предложение для агентств</h2>
								</div>
								<div class="agency_descr">
									<h3>
										Предлагаем выгодное предложение о сотрудничестве для агентств,
										которые ищут программистов на субподряд. За подробной информацией
										обращайтесь к нашим менеджерам.
									</h3>
								</div>
								<div class="agency_btn_wrapper">
									<a class="button  agency_call_btn" data-toggle="modal" data-target="#ModalCollaboration">Отправить заявку</a>
									<?php /* <a class="button  agency_pdf_btn">Скачать pdf</a> */ ?>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>

			<section id="subscription" class="subscription">
				<a name="subscription"></a>
				<!--якорь-->
				<div class="container">
					<div class="row">
						<div class="col-xl-12">
							<div class="subscription-bg title-bg">constant support</div>
							<div class="title-before subscription-title-before">Всегда на связи</div>
							<h2 class="title subscription-title">Постоянная техподдержка</h2>
						</div>
					</div>
					<div class="row align-items-center">
						<div class="col-12 col-lg-7 col-xl-7">
							<div class="subscription-desc">
								<div class="title-desc d-flex align-items-center">
									Размещение на надежных серверах
								</div>
								<div class="title-desc d-flex align-items-center">
									Антивирусная диагностика при переносе сайта
								</div>
								<div class="title-desc d-flex align-items-center">
									Выделенный менеджер
								</div>
							</div>
						</div>
						<div class="col-12 col-lg-5 col-xl-5">
							<div class="subscription-desc">
								<div class="support-price">
									<div class="support-price_name">
										<span>от</span> 1800<span class="ruble_price">&#8381;</span><span>/мес</span>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-12">
							<!-- <div class="subscription-table__scroll">
								<div class="subscription-table">
									<div class="s-table_name">
										<div class="table_name-blue mbdel"> </div>
										<div class="table_name-blue mbdel">Стандарт</div>
										<div class="table_name-blue mbdel">Эксперт</div>
										<div class="table_name-blue mbdel">Бизнес</div>
										<div class="table_name-blue mbdel">Бизнес Pro</div>
									</div>
									<div class="s-table_row">
										<div class="table_name-blue">Количество нормо-часов включенных в тариф</div>
										<div class="table_name-blue">1</div>
										<div class="table_name-blue">4</div>
										<div class="table_name-blue">16</div>
										<div class="table_name-blue">36</div>
									</div>
									<div class="s-table_row">
										<div class="table_row-grey t-middle_grey">Лендинг/Сайт-визитка</div>
										<div class="table_row-grey">1800 &#8381; </div>
										<div class="table_row-grey">7200 &#8381; </div>
										<div class="table_row-grey">– </div>
										<div class="table_row-grey">– </div>
									</div>
									<div class="s-table_row">
										<div class="table_row-grey t-middle_grey">Корпоративный сайт/<br>Сайт-каталог</div>
										<div class="table_row-grey">2400 &#8381; </div>
										<div class="table_row-grey">7800 &#8381; </div>
										<div class="table_row-grey">23200 &#8381; </div>
										<div class="table_row-grey">– </div>
									</div>
									<div class="s-table_row">
										<div class="table_row-grey t-middle_grey">Интернет-магазин</div>
										<div class="table_row-grey">2800 &#8381; </div>
										<div class="table_row-grey">8200 &#8381; </div>
										<div class="table_row-grey">23600 &#8381; </div>
										<div class="table_row-grey">48200 &#8381; </div>
									</div>
								</div>
							</div> -->
							<div class="subscription-table__scroll">
								<div class="subscription-table">
									<div class="s-table_name">
										<div class="table_name-blue">Тарифы</div>
										<?php foreach ($data->tariffs as $value) : //цикл по столбцам 
											?>
											<div class="table_name-blue mbdel">
												<?php echo $value->name; //названия тарифов 
													?>
											</div>
										<?php endforeach; ?>
									</div>
									<div class="s-table_row">
										<?php foreach ($data->tariffs as $value) : //цикл по столбцам 
											?>
										<?php endforeach; ?>
									</div>
									<?php foreach ($data->site_types as $row_key => $site) : //цикл по строкам 
										?>
										<div class="s-table_row">
											<div class="table_row-grey t-middle_grey">
												<?php echo $site; //тип сайта 
													?>
											</div>
											<?php foreach ($data->tariffs as $value) : //цикл по столбцам 
													?>
												<div class="table_row-grey table_price_style">
													<?php
															$price_data = $value->price->$row_key;
															echo $price_data; // цена
															if (is_numeric($price_data))
																echo '&#x20bd;' //знак рубля
																?>
												</div>
											<?php endforeach; ?>
										</div>

									<?php endforeach; ?>

									<!-- добавить таблицу -->
									<div class="table_accordion">
										<div class="table_accordion_header">
											<div class="table_row-blue">Услуги, включенные в тариф</div>
											<div class="table_accordion_btn">
												<i class="fas fa-chevron-down"></i>
												<i class="fas fa-chevron-up"></i>
											</div>
										</div>
										<div class="table_accordion_body">
											<?php foreach ($data->table_services as $row_key => $tbl_serv) :
												?>
												<div class="s-table_row">
													<div class="table_row-grey t-middle_grey table_new_style">
														<?php echo $tbl_serv; //тип услуги 
															?>
													</div>
													<?php foreach ($data->tariffs as $value) : //цикл по столбцам 
															?>
														<div class="table_row-grey  table_new_style">
															<?php
																	$service_data = $value->service[$row_key];
																	echo $service_data; // услугая
																	?>
														</div>
													<?php endforeach; ?>
												</div>
											<?php endforeach; ?>
										</div>
									</div>
									<!-- добавить таблицу -->

									<div class="s-table_row">
										<div class="table_row-grey t-middle_grey">
										</div>
										<?php
										foreach ($data->tariffs as $key => $value) { ?>
											<div class="table_row-grey">
												<button class="button button-table nearTable" tariffId="<?php echo $key; ?>" data-toggle="modal" data-target="#ModalLong">Отправить заявку</button>
											</div>
										<?php } ?>
									</div>
								</div>
							</div>
							<a class="button btn-scroll" href="#" data-toggle="modal" data-target="#ModalCalculator">Оценить потребность</a>
						</div>
					</div>

					<!-- 					<div class="row">
						<div class="col-12">
							<div class="table_wrap">
								<table>
									<thead>
										<tr>
											<th class="t_table_head-blue">Количество нормо-часов включенных в тариф</th>
											<th class="t_table_head-blue">Стандарт 1</th>
											<th class="t_table_head-blue">Эксперт 4</th>
											<th class="t_table_head-blue">Бизнес 16</th>
											<th class="t_table_head-blue">Бизнес Pro 36</th>
										</tr>
									</thead>
									<tbody>
										<tr>
											<td class="t_table_body_gray">Лендинг/Сайт-визитка</td>
											<td class="t_table_body_gray">1800 &#8381;</td>
											<td class="t_table_body_gray">7200 &#8381;</td>
											<td class="t_table_body_gray">-</td>
											<td class="t_table_body_gray">-</td>
										</tr>
										<tr>
											<td class="t_table_body_gray"> Корпоративный сайт/<br>Сайт-каталог</td>
											<td class="t_table_body_gray">2400 &#8381;</td>
											<td class="t_table_body_gray">7800 &#8381;</td>
											<td class="t_table_body_gray">23200 &#8381;</td>
											<td class="t_table_body_gray">-</td>
										</tr>
										<tr>
											<td class="t_table_body_gray">Интернет-магазин</td>
											<td class="t_table_body_gray">2800 &#8381;</td>
											<td class="t_table_body_gray">8200 &#8381;</td>
											<td class="t_table_body_gray">23600 &#8381;</td>
											<td class="t_table_body_gray">48200 &#8381;</td>
										</tr>
									</tbody>
								</table>
							</div>
						</div>
					</div> -->

					<div class=" row">
						<div class="col-12 col-lg-6 col-xl-6">
							<div class="subscription-advant advantWrapperForDestcMonth">
								<div class="subscription-advant__title">
									<h3> Преимущества ежемесячной техподдержки </h3>
								</div>
								<p>Отлаженный процесс взаимодействия Клиент-Менеджер-Специалист.</p>
								<b>Вам не нужно думать о том, а вдруг если… Вашу заботу по работе сайта и с сайтом мы берем на себя.</b>
								<br><br>
								<p>Размещаем сайт на сервере. Контролируем работоспособность сайта. </p>
								Вовремя продлеваем домены/лицензии Битрикс (успеваем в скидку 60%).<br><br>
								<p>Обновляем установленные модули и решения.Подсказываем, что и где можно улучшить.</p>
								<p>Остались вопросы? Звоните по телефону +7 (863) 226-90-95</p>
							</div>
							<div class="subscription-advant advantWrapperForMobMonth">
								<div class="subscription-advant__title advantTitleForMobMonth">
									<h3>Преимущество ежемесячной поддержки</h3>
									<div class="advantBtnForMobMonth">
										<i class="fas fa-chevron-down"></i>
										<i class="fas fa-chevron-up"></i>
									</div>
								</div>
								<div class="advantDescrForMobMonth">
									<p>Отлаженный процесс взаимодействия Клиент-Менеджер-Специалист.</p>
									<b>Вам не нужно думать о том, а вдруг если… Вашу заботу по работе сайта и с сайтом мы берем на себя.</b>
									<br><br>
									<p>Размещаем сайт на сервере. Контролируем работоспособность сайта. </p>
									Вовремя продлеваем домены/лицензии Битрикс (успеваем в скидку 60%).<br><br>
									<p>Обновляем установленные модули и решения.Подсказываем, что и где можно улучшить.</p>
									<p>Остались вопросы? Звоните по телефону +7 (863) 226-90-95</p>
								</div>
							</div>
						</div>
						<div class="col-12 col-lg-6 col-xl-6">
							<!-- 							<div class="subscription-advant">
								<div class="subscription-advant__title">
									<h3>FAQ</h3>
								</div>
							</div> -->
						</div>
					</div>
				</div>
			</section>

			<section id="support" class="support ">
				<a name="support"></a>
				<!--якорь-->
				<div class="container">
					<div class="row">
						<div class="col-xl-12">
							<div class="support-bg title-bg">Hourly Pay</div>
							<div class="title-before support-title-before">Экономное бронирование</div>
							<h2 class="title support-title">Депозиты</h2>
						</div>
					</div>
					<div class="row align-items-center">
						<div class="col-12 col-lg-7 col-xl-7">
							<div class="support-desc">
								<div class="title-desc d-flex align-items-center">
									Реализовываем нестандартные решения через типовые возможности 1С-Битрикс
								</div>
								<div class="title-desc d-flex align-items-center">
									Разрабатываем и внедряем новый функционал
								</div>
								<div class="title-desc d-flex align-items-center">
									Консультируем и поддерживаем в процессе ведения проекта
								</div>
								<!-- <a href="" class="button btn-scroll forCalculateModal" data-toggle="modal" data-target="#calculateTheCostModal">Рассчитать стоимость</a> -->
							</div>
						</div>
						<div class="col-12 col-lg-5 col-xl-5">
							<div class="support-desc">
								<div class="support-price">
									<div class="support-price_name">
										<span>от</span> 1200<span class="ruble_price">&#8381;</span><span>/час</span>
									</div>
								</div>
								<!-- 								<div class="support-bonus_forMob">
									Выгодное предложение для большого потока задач
								</div> -->
								<!-- <a href="" class="button btn-scroll forCalculateModal" data-toggle="modal" data-target="#calculateTheCostModal">Рассчитать стоимость</a> -->
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-12">
							<!-- <div class="subscription-table__scroll">
								<div class="subscription-table">
									<div class="s-table_name">
										<div class="table_name-blue">Пакеты</div>
										<div class="table_name-blue">Бизнес</div>
										<div class="table_name-blue">Стандарт</div>
										<div class="table_name-blue">Базовый</div>
										<div class="table_name-blue">Свободный</div>
									</div>
									<div class="s-table_row">
										<div class="table_row-grey t-middle_grey">Стоимость пакета</div>
										<div class="table_row-grey forAuditModal">
											<div class="price">60 000 &#8381;</div>
											<div class="link">
												<a href="#" data-toggle="modal" data-target="#auditModal" class="auditInTable">Бесплатный<br>аудит сайтa</a>
											</div>
										</div>
										<div class="table_row-grey">42 000 &#8381; </div>
										<div class="table_row-grey">16 000 &#8381; </div>
										<div class="table_row-grey">-</div>
									</div>
									<div class="s-table_row">
										<div class="table_row-grey t-dark_grey">Количество нормо-часов</div>
										<div class="table_row-grey t-middle_grey">50</div>
										<div class="table_row-grey t-middle_grey">30</div>
										<div class="table_row-grey t-middle_grey">10</div>
										<div class="table_row-grey t-middle_grey">до 10</div>
									</div>

									<div class="s-table_row">
										<div class="table_row-grey t-dark_grey">Стоимость часа специалиста</div>
										<div class="table_row-grey t-middle_grey">1200 &#8381; </div>
										<div class="table_row-grey t-middle_grey">1400 &#8381; </div>
										<div class="table_row-grey t-middle_grey">1600 &#8381; </div>
										<div class="table_row-grey t-middle_grey">1800 &#8381; </div>
									</div>
									<div class="s-table_row">
										<div class="table_row-grey t-dark_grey">Срок действия пакета</div>
										<div class="table_row-grey t-middle_grey">6 мес</div>
										<div class="table_row-grey t-middle_grey">3 мес</div>
										<div class="table_row-grey t-middle_grey">1 мес</div>
										<div class="table_row-grey t-middle_grey">-</div>
									</div>
								</div>
							</div> -->
							<div class="subscription-table__scroll">
								<div class="subscription-table">
									<div class="s-table_name">
										<div class="table_name-blue">Пакеты</div>
										<?php foreach ($data->packages as $value) : //цикл по столбцам 
											?>
											<div class="table_name-blue">
												<?php echo $value->name; //названия пакетов 
													?>
											</div>
										<?php endforeach; ?>
									</div>
									<div class="s-table_row">
										<div class="table_row-grey t-dark_grey ">Стоимость часа специалиста</div>
										<?php foreach ($data->packages as $value) : //цикл по столбцам 
											?>
											<div class="table_row-grey t-middle_grey table_price_style">
												<?php
													echo $value->hour_price; //цена за час
													echo " &#8381;"; //знак рубля
													?>
											</div>
										<?php endforeach; ?>
									</div>
									<div class="s-table_row">
										<div class="table_row-grey t-middle_grey">Стоимость пакета</div>
										<?php foreach ($data->packages as $value) : //цикл по столбцам 
											?>
											<div class="table_row-grey <?= ($value->free_audit) ? "forAuditModal" : "" ?> table_price_style">
												<?php
													if ($value->is_free) { //если пакет "Свободный"
														echo "-";
													} else { //любой другой пакет
														$total_price = $value->hour_price * $value->hours; // вычисляем общую стоимость пакета
														echo number_format($total_price, 0, '.', ' '); // выводим с разделителем тысяч пробелом
														echo " &#8381;"; //знак рубля
													}
													?>
												<?php if ($value->free_audit) : //если действует акция "Бесплатный аудит сайта" 
														?>
													
												<?php endif; ?>
											</div>
										<?php endforeach; ?>
									</div>
									<div class="s-table_row">
										<div class="table_row-grey t-dark_grey">Количество нормо-часов</div>
										<?php foreach ($data->packages as $value) : //цикл по столбцам 
											?>
											<div class="table_row-grey t-middle_grey table_price_style">
												<?php echo $value->hours; //кол-во часов 
													?>
											</div>
										<?php endforeach; ?>
									</div>
									<!-- <div class="s-table_row">
										<div class="table_row-grey t-dark_grey">Срок действия пакета</div>
										<?/*php foreach ($data->packages as $value) : //цикл по столбцам 
											*/ ?>
											<div class="table_row-grey t-middle_grey table_price_style">
												<?/*php
													$num = $value->validity_period; //срок действия
													echo $num;
													if (is_numeric($num)) {
														echo " мес";
													}
													*/ ?>
											</div>
										<?/*php endforeach; */ ?>
									</div> -->
									<div class="s-table_row ">
										<div class="table_row-grey t-middle_grey table_price_style"></div>
										<?php foreach ($data->packages as $key => $value) { //цикл по столбцам 
											?>
											<div class="table_row-grey">
												<a href="" class="button btn-scroll button-table" packageId="<?php echo $key; ?>" data-toggle="modal" data-target="#ModalPackage">Отправить заявку</a>
											</div>
										<?php } ?>
									</div>
								</div>
							</div>
							<!--  <a href="" class="button btn-scroll" data-toggle="modal" data-target="#ModalPackage">Отправить заявку</a> -->
						</div>
					</div>
					<div class="row">
						<div class="col-12 col-lg-6 col-xl-6">
							<div class="subscription-advant advantWrapperForDestcTariff">
								<div class="subscription-advant__title">
									<h3>Когда нужны не просто «руки программистов»</h3>
								</div>
								<p>Помогаем правильно оценить конечную цель. Прорабатываем оптимальное решение задачи.</p>
								<p>Решаем объемные и сложные задачи. Знаем, как справиться с потоком задач и не утонуть в нем. </p>
								<p>Подсказываем, что и как можно улучшить в процессе выполнения работы.</p>
								<p>Берём сайты на проведение аудита с визуальной и технической части.</p>
								<p>Остались вопросы? Звоните по телефону +7 (863) 226-90-95</p>
								</p>
							</div>
							<div class="subscription-advant advantWrapperForMobTariff">
								<div class="subscription-advant__title advantTitleForMobTariff">
									<h3>Когда нужны не просто «руки программистов»</h3>
									<div class="advantBtnForMobTariff">
										<i class="fas fa-chevron-down"></i>
										<i class="fas fa-chevron-up"></i>
									</div>
								</div>
								<div class="advantDescrForMobTariff">
									<p>Помогаем правильно оценить конечную цель. Прорабатываем оптимальное решение задачи.</p>
									<p>Решаем объемные и сложные задачи. Знаем, как справиться с потоком задач и не утонуть в нем. </p>
									<p>Подсказываем, что и как можно улучшить в процессе выполнения работы.</p>
									<p>Берём сайты на проведение аудита с визуальной и технической части.</p>
									<p>Остались вопросы? Звоните по телефону +7 (863) 226-90-95</p>
								</div>
							</div>
						</div>
						<div class="col-12 col-lg-6 col-xl-6">
							<div class="faqAccordion">
								<div class="FAQ__title">
									<h3>FAQ</h3>
								</div>
								<div class="accordion">
									<div class="faqAccordion_wrapper">
										<div class="faqAccordion_item">
											<div class="faqAccordion_item_head">
												<div class="faqAccordion_item_head_tite">
													Что такое срок действия пакета?
												</div>
												<div class="faqAccordion_item_head_button">
													<i class="fas fa-chevron-down"></i>
													<i class="fas fa-chevron-up"></i>
												</div>
											</div>
											<div class="faqAccordion_item_body">
												<div class="faqAccordion_item_body_text">
													Период времени, в течение которого Вы имеете право воспользоваться услугами вашего депозита в полном объёме.
												</div>
											</div>
										</div>
										<div class="faqAccordion_item">
											<div class="faqAccordion_item_head">
												<div class="faqAccordion_item_head_tite">
													Зачем устанавливается срок действия пакета?
												</div>
												<div class="faqAccordion_item_head_button">
													<i class="fas fa-chevron-down"></i>
													<i class="fas fa-chevron-up"></i>
												</div>
											</div>
											<div class="faqAccordion_item_body">
												<div class="faqAccordion_item_body_text">
													Мы планируем загрузку наших специалистов и резервируем объём работы по депозиту на установленный срок. По истечении срока действия вашего депозита мы не гарантируем выполнение заявленного объёма работы в связи с тем, что время специалистов может быть распланировано под другие задачи. </div>
											</div>
										</div>
										<div class="faqAccordion_item">
											<div class="faqAccordion_item_head">
												<div class="faqAccordion_item_head_tite">
													Что делать, если часы депозита не израсходованы, а срок действия истекает?
												</div>
												<div class="faqAccordion_item_head_button">
													<i class="fas fa-chevron-down"></i>
													<i class="fas fa-chevron-up"></i>
												</div>
											</div>
											<div class="faqAccordion_item_body">
												<div class="faqAccordion_item_body_text">
													Можно продлить депозит на один месяц, купив любое количество нормо-часов. </div>
											</div>
										</div>
										<div class="faqAccordion_item">
											<div class="faqAccordion_item_head">
												<div class="faqAccordion_item_head_tite">
													Когда вступает в силу действие пакета?
												</div>
												<div class="faqAccordion_item_head_button">
													<i class="fas fa-chevron-down"></i>
													<i class="fas fa-chevron-up"></i>
												</div>
											</div>
											<div class="faqAccordion_item_body">
												<div class="faqAccordion_item_body_text">
													У Вас есть возможность указать дату начала действия пакета. По умолчанию пакет начинает действовать через 7 дней со дня поступления оплаты на расчетный счет компании. </div>
											</div>
										</div>
										<div class="faqAccordion_item">
											<div class="faqAccordion_item_head">
												<div class="faqAccordion_item_head_tite">
													Что такое нормо-час?
												</div>
												<div class="faqAccordion_item_head_button">
													<i class="fas fa-chevron-down"></i>
													<i class="fas fa-chevron-up"></i>
												</div>
											</div>
											<div class="faqAccordion_item_body">
												<div class="faqAccordion_item_body_text">
													Нормо-час - это нормативная трудоемкость выполнения.
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>

			<section id="recommend" class="recommend gray_bg">
				<a name="recommend"></a>
				<!--якорь-->
				<div class="container">
					<div class="row">
						<div class="col-12">
							<div class="recommend-bg title-bg white_font">Recommend</div>
							<h2 class="title recommend-title">Как мы обрабатываем заявки</h2>
						</div>
						<!-- /.col-12 -->

						<div class="col-12 col-sm-12 offset-sm-2 col-md-6 offset-md-6 m-t">
							<div class="work-process">
								<div class="wp-text-bg__top text-bg white_font">Заявка</div>
								<div class="wp-tree">

									<div class="wp-cell">
										<div class="wp-cell-bg text-bg white_font">15 мин</div>
										<div class="wprocess-number">1</div>
										<div class="wp-line"></div>
										<!-- <div class="wp-img"><img src="img/recommend/2.svg" alt="#"></div> -->
										<div class="wprocess-step">Приём заявок</div>
										<div class="wprocess-desc">Принимаем заявки через удобный для вас мессенджер</div>
									</div>

									<div class="wp-cell">
										<div class="wp-cell-bg text-bg white_font">1 день</div>
										<div class="wprocess-number">2</div>
										<div class="wp-line"></div>
										<div class="wprocess-step">Реагирование</div>
										<div class="wprocess-desc">Время реагирования на заявку задач по техподдержке – не более 30 мин.</div>
									</div>

									<div class="wp-cell">
										<div class="wprocess-number">3</div>
										<div class="wp-line"></div>
										<div class="wprocess-step">Обсуждение</div>
										<div class="wprocess-desc">Если задача типовая, то ставим сразу в очередь. Для нетиповой готовим ТЗ и осмечиваем</div>
									</div>

									<div class="wp-cell">
										<div class="wprocess-number">4</div>
										<div class="wp-line"></div>
										<div class="wprocess-step">Согласование</div>
										<div class="wprocess-desc">Утверждаем время выполнения и сроки задачи</div>
									</div>

									<div class="wp-cell">
										<div class="wp-cell-bg text-bg white_font">очередь</div>
										<div class="wprocess-number">5</div>
										<div class="wp-line"></div>
										<div class="wprocess-step">Планирование</div>
										<div class="wprocess-desc">Ставим задачу в план на выполнение в течение недели</div>
									</div>

									<div class="wp-cell">
										<div class="wp-cell-bg text-bg white_font">проверка</div>
										<div class="wprocess-number">6</div>
										<div class="wp-line"></div>
										<div class="wprocess-step">Процесс реализации</div>
										<div class="wprocess-desc">Выполняем задачу на тестовом сервере
										</div>
									</div>

									<div class="wp-cell">
										<div class="wprocess-number">7</div>
										<div class="wp-line"></div>
										<div class="wprocess-step">Демонстрация</div>
										<div class="wprocess-desc">Показываем результат, вносим правки, если есть, согласовываем результат</div>
									</div>

									<div class="wp-cell">
										<div class="wprocess-number">8</div>
										<div class="wp-line"></div>
										<div class="wprocess-step">Перенос</div>
										<div class="wprocess-desc">Выкладываем готовый вариант на рабочий сайт.
										</div>
									</div>
									<div class="wp-cell">
										<div class="wprocess-number">9</div>
										<div class="wp-line"></div>
										<div class="wprocess-step">Онлайн-отчёт</div>
										<div class="wprocess-desc">Заносим отчёт о выполнении в задачник
										</div>
									</div>
								</div>
								<div class="wp-text-bg__bottom text-bg white_font">выполнено</div>
							</div>
						</div>
						<!-- /.col-12 -->
					</div>
					<!-- /.row -->
				</div>
				<!-- /.container -->
			</section>

			<section id="about-us" class="about-us">

				<div class="container">
					<div class="row align-items-center">
						<div class="col-12">
							<div class="about-us-bg title-bg">About Company</div>
							<div class="title-before about-us-before">ADM-Center</div>
							<h2 class="title about-us-title">Мы в цифрах</h2>
						</div>
					</div>
					<!-- 					<div class="row align-items-center m-t">
						<div class="col-12 col-sm-12 col-md-5 col-lg-4 col-xl-4 order-2 order-md-0">
							<div class="highlights-items d-flex justify-content-center justify-content-md-start">
								<ul>
									<li class="d-flex align-items-center justify-content-start">
										<div class="highlights_blue">11</div>
										<div class="highlights-items__descr">11 лет опыта разработки сайтов</div>
									</li>
									<li class="d-flex align-items-center justify-content-start">
										<div class="highlights_blue">15</div>
										<div class="highlights-items__descr">15 специалистов, готовых вам помочь</div>
									</li>
									<li class="d-flex align-items-center justify-content-start">
										<div class="highlights_blue">50</div>
										<div class="highlights-items__descr">Более 50 проектов на техподдержке</div>
									</li>
								</ul>
							</div>
						</div>
						<div class="col-12 col-sm-12 col-md-7 col-lg-8 col-xl-8 pl-lg-0 pb-4 pb-sm-5 pb-md-0">
							<div class="row align-items-center">
								<div class="col-9 col-sm-8 col-md-9 col-lg-9 col-xl-9 pr-xl-5 pl-md-0 d-flex justify-content-start justify-content-lg-center justify-content-xl-end align-items-center">
									<div class="highlights-img">
										<img src="img/support/support-adm.png" alt="Техподдержка ADM">
									</div>
								</div>
								<div class="col-3 col-sm-4 col-md-3 col-lg-3 col-xl-3 pl-0 d-flex justify-content-center">
									<div class="h-our_awards">
										<ul class="d-flex flex-column justify-content-center">
											<li>
												<a href="https://www.1c-bitrix.ru/partners/293096.php" target="_blank"><img src="img/support/gold-partner.jpg" alt="1C-Bitrix Gold Partner" title="Золотой партнер 1С-Битрикс"></a>
											</li>
											<li>
												<a href="https://www.1c-bitrix.ru/partners/293096.php" target="_blank"><img src="img/support/monitoring.jpg" alt="Monitoring Participant" title="Участник программы качества внедрений 1С-Битрикс"></a>
											</li>
											<li>
												<a href="https://www.1c-bitrix.ru/partners/293096.php" target="_blank"><img src="img/support/kompozit.jpg" alt="Kompozit" title="Композитный сайт"></a>
											</li>
											<li>
												<a href="https://www.1c-bitrix.ru/partners/293096.php" target="_blank"><img src="img/support/1c.jpg" alt="1c-integration" title="Интеграция с 1С"></a>
											</li>
										</ul>
									</div>
								</div>
							</div>
						</div>
					</div> -->

					<div class="row justify-content-between rowrow">
						<div class="col-12 col-sm-9">
							<div class="row">
								<div class="col-6 col-sm-5 col-md-4 col-lg-4">
									<div class="numbers-box">
										<div class="numbers-box__title">
											<div>Опыт</div>
										</div>
										<ul class="numbers-box__list">
											<li><span class="count_exp">0</span></li>
											<li>лет разработки<br>веб-проектов</li>
										</ul>
									</div>
									<!-- /.numbers-box -->
								</div>
								<!-- /.col-4 -->

								<div class="col-6 col-sm-5 col-md-4 col-lg-4">
									<div class="numbers-box">
										<div class="numbers-box__title">
											<div>Клиенты</div>
										</div>
										<ul class="numbers-box__list">
											<li><span class="count_clients1">0</span><span class="numbers-box__list-percent">%</span></li>
											<li>приходят<br>по рекомендации</li>
										</ul>
									</div>
									<!-- /.numbers-box -->
								</div>
								<!-- /.col-4 -->

								<div class="col-6 col-sm-5 col-md-4 col-lg-4">
									<div class="numbers-box">
										<div class="numbers-box__title">
											<div>Клиенты</div>
										</div>
										<ul class="numbers-box__list">
											<li><span class="count_clients2">0</span><span class="numbers-box__list-percent">%</span></li>
											<li>остаются с нами<br>на техподдержку</li>
										</ul>
									</div>
									<!-- /.numbers-box -->
								</div>
								<!-- /.col-4 -->

								<div class="col-6 col-sm-5 col-md-4 col-lg-4">
									<div class="numbers-box">
										<div class="numbers-box__title">
											<div>Команда</div>
										</div>
										<ul class="numbers-box__list">
											<li><span class="count_team">0</span></li>
											<li>сертифицированных<br>специалистов</li>
										</ul>
									</div>
									<!-- /.numbers-box -->
								</div>
								<!-- /.col-4 -->

								<div class="col-6 col-sm-5 col-md-4 col-lg-4">
									<div class="numbers-box">
										<div class="numbers-box__title">
											<div>Битрикс</div>
										</div>
										<ul class="numbers-box__list">
											<li><span class="count_bitrix1">0</span></li>
											<li>место по<br>продажам в РО</li>
										</ul>
									</div>
									<!-- /.numbers-box -->
								</div>
								<!-- /.col-4 -->

								<div class="col-6 col-sm-5 col-md-4 col-lg-4">
									<div class="numbers-box">
										<div class="numbers-box__title">
											<div>Битрикс</div>
										</div>
										<ul class="numbers-box__list">
											<li><span class="count_bitrix2">0</span></li>
											<li>лет сертифицированный<br>золотой партнер</li>
										</ul>
									</div>
									<!-- /.numbers-box -->
								</div>
							</div>
						</div>

						<div class="col-12 col-sm-3 col-md-2 col-lg-2 col-xl-2">
							<div class=" row">
								<div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 d-flex justify-content-center">
									<div class="h-our_awards">
										<ul class="d-flex  justify-content-center award-list">
											<li>
												<a href="https://www.1c-bitrix.ru/partners/293096.php" target="_blank"><img src="img/support/gold-partner.jpg" alt="1C-Bitrix Gold Partner" title="Золотой партнер 1С-Битрикс"></a>
											</li>
											<li>
												<a href="https://www.1c-bitrix.ru/partners/293096.php" target="_blank"><img src="img/support/monitoring.jpg" alt="Monitoring Participant" title="Участник программы качества внедрений 1С-Битрикс"></a>
											</li>
											<li>
												<a href="https://www.1c-bitrix.ru/partners/293096.php" target="_blank"><img src="img/support/kompozit.jpg" alt="Kompozit" title="Композитный сайт"></a>
											</li>
											<li>
												<a href="https://www.1c-bitrix.ru/partners/293096.php" target="_blank"><img src="img/support/1c.jpg" alt="1c-integration" title="Интеграция с 1С"></a>
											</li>
										</ul>
									</div>
									<!-- /.header-middle-sale -->
								</div>
							</div>
						</div>
					</div>


				</div>
			</section>

			<?php
			require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/footer.php';
			?>

		</div>
		<!-- /.scrollcontent -->

		<!-- НАЧАЛО ВСПЛЫВАЮЩЕЙ ФОРМЫ -->
		<div class="send-request modal fade" id="ModalLong" tabindex="-1" role="dialog" aria-labelledby="ModalLongTitle" aria-hidden="true">
			<div class="popup modal-dialog m-0" role="document">
				<button type="button" class="popup-close close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
				<!-- <div class="popup-close close" data-dismiss="modal" aria-label="Close">&times;</div>-->
				<!-- /.popup-close -->

				<div class="popup-form">
					<div class="popup-form-header" id="ModalLongTitle">
						<div class="popup-form-header__title">Оставьте заявку на постоянное обслуживание</div>
						<div class="popup-form-header__descr">Заполните анкету и наши специалисты свяжутся с вами для обсуждения возможностей сотрудничества</div>
					</div>
					<form action="" id="popup_form" class="popup-form__form" method="POST">
						<div class="popup-form-box">
							<div class="Flying_Placeholder">
								<label>Имя *</label>
								<input class="popup-form-box__input" type="text" name="user-name_modal" id="user-name_modal">
							</div>
							<div class="Flying_Placeholder">
								<label>Адрес сайта *</label>
								<input class="popup-form-box__input" name="user-linksite_modal" id="user-linksite_modal"></input>
							</div>
							<div class="Flying_Placeholder">
								<label>E-mail *</label>
								<input class="popup-form-box__input" type="mail" name="user-mail_modal" id="user-mail_modal">
							</div>
							<div class="Flying_Placeholder">
								<label>Телефон</label>
								<input class="popup-form-box__input" type="tel" name="user-phone_modal" id="user-phone_modal">

								<select id="popup-form-contact_way" name="popup-form-contact_way" class="contact_way">
									<option class="Manager" value="manager">Звонок менеджера</option>
									<option class="WhatsApp" value="WhatsApp">WhatsApp</option>
									<option class="Viber" value="Viber">Viber</option>
									<option class="Telegram" value="Telegram">Telegram</option>
								</select>
							</div>
							<!--div class="Flying_Placeholder">
							<label>Телефон</label>
							<input class="popup-form-box__input" type="tel" name="user-phone_modal" id="user-phone_modal" >
						</div-->
							<div class="Flying_Placeholder">
								<select name="project" id="project" class="S3_type_1">
									<?php foreach ($data->site_types as $key => $value) : //цикл по столбцам 
										?>
										<?php $v = ($value == "Корпоративный сайт/<br>Сайт-каталог") ? "Корпоративный/сайт-каталог" : $value; ?>
										<option value="<?= $key ?>"><?= $v ?></option>
									<?php endforeach; ?>
								</select>
							</div>
							<!--div class="Flying_Placeholder">
								<div class="row no-gutters" style="width: 100%;">
									
									
									<select name="tariff" id="tariff" class="S3_type_1 bitrix_edition">
										<option value="Стандарт">Стандарт</option>
										<option value="Эксперт">Эксперт</option>
										<option value="Бизнес">Бизнес</option>
										<option value="Бизнес Pro">Бизнес Pro</option>
									</select>
									<div id="price">
									</div>
								</div>
							</div-->
							<div class="Flying_Placeholder">
								<input type="text" class="js-range-slider" name="tariff" id="tariff" value="" />
							</div>
							<div id="price">
							</div>
						</div>
						<!-- /.popup-form-box -->

						<div class="popup-form__button d-flex justify-content-center">
							<button class="button popup-form__btn">
								Отправить заявку
							</button>
						</div>
						<div class="popup-form-desc">
							Нажимая на кнопку я соглашаюсь на передачу личных данных ФЗ РФ № 152 «О защите персональных данных»
						</div>
						<!-- /.popup-form__btn -->
					</form>
				</div>
				<!-- /.popup-form -->
			</div>
			<!-- /.popup -->
		</div>
		<!-- КОНЕЦ ВСПЛЫВАЮЩЕЙ ФОРМЫ -->
		<!-- НАЧАЛО ФОРМЫ НА ПАКЕТ -->
		<div class="send-request modal fade" id="ModalPackage" tabindex="-1" role="dialog" aria-labelledby="ModalPackageTitle" aria-hidden="true">
			<div class="popup modal-dialog m-0" role="document">
				<button type="button" class="popup-close close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
				<!-- <div class="popup-close close" data-dismiss="modal" aria-label="Close">&times;</div>-->
				<!-- /.popup-close -->

				<div class="popup-form">
					<div class="popup-form-header" id="ModalPackageTitle">
						<div class="popup-form-header__title">Заявка на пакет</div>
						<div class="popup-form-header__descr">Заполните анкету и наши специалисты свяжутся с вами</div>
					</div>
					<form action="" id="package_form" class="popup-form__form" method="POST">
						<div class="popup-form-box">
							<div class="Flying_Placeholder">
								<label>Имя *</label>
								<input class="popup-form-box__input" type="text" name="user-name_packForm" id="user-name_packForm">
							</div>
							<div class="Flying_Placeholder">
								<label>Адрес сайта *</label>
								<input class="popup-form-box__input" name="user-linksite_packForm" id="user-linksite_packForm"></input>
							</div>
							<div class="Flying_Placeholder">
								<label>E-mail *</label>
								<input class="popup-form-box__input" type="mail" name="user-mail_packForm" id="user-mail_packForm">
							</div>
							<div class="Flying_Placeholder">
								<label>Телефон</label>
								<input class="popup-form-box__input" type="tel" name="user-phone_packForm" id="user-phone_packForm">

								<select id="contact-way_packForm" name="contact-way_packForm" class="contact_way">
									<option class="Manager" value="manager">Звонок менеджера</option>
									<option class="WhatsApp" value="WhatsApp">WhatsApp</option>
									<option class="Viber" value="Viber">Viber</option>
									<option class="Telegram" value="Telegram">Telegram</option>
								</select>
							</div>
							<div class="Flying_Placeholder">
								<input type="text" class="js-range-slider" name="package" id="package" value="" />
							</div>
							<div id="price_packForm">
							</div>
							<div class="Flying_Placeholder" id="startPackWrap">
								<label>Дата начала пакета *</label>
								<input type="text" id="startPack" name="startPack" class="popup-form-box__input" value="" />
							</div>
						</div>
						<!-- /.popup-form-box -->

						<div class="popup-form__button d-flex justify-content-center">
							<button class="button popup-form__btn">
								Отправить заявку
							</button>
						</div>
						<div class="popup-form-desc">
							Нажимая на кнопку я соглашаюсь на передачу личных данных ФЗ РФ № 152 «О защите персональных данных»
						</div>
						<!-- /.popup-form__btn -->
					</form>
				</div>
				<!-- /.popup-form -->
			</div>
			<!-- /.popup -->
		</div>
		<!-- КОНЕЦ ФОРМЫ НА ПАКЕТ -->
		<!-- НАЧАЛО ВСПЛЫВАЮЩЕЙ ФОРМЫ Рассчитать стоимость-->
		<div class="send-request modal fade" id="calculateTheCostModal" tabindex="-1" role="dialog" aria-labelledby="ModalLongTitle" aria-hidden="true">
			<div class="popup modal-dialog m-0" role="document">
				<div class="popup-form">
					<div class="popup-form-header" id="ModalLongTitle">
						<div class="popup-form-header__title">Нужно рассчитать стоимость задачи?</div>
						<div class="popup-form-header__descr">Заполните, пожалуйста, форму. Чем больше будет информации о задаче, тем точнее мы сможем её оценить.
							Возможно, мы свяжемся с Вами для уточнения деталей. Ориентировочную стоимость запроса мы пришлём Вам на указанную почту в течение 1-2 дней.</div>
						<button type="button" class="popup-close close" data-dismiss="modal" aria-label="Close">
							<span aria-hidden="true">&times;</span>
						</button>
					</div>
					<div class="forOverflov">
						<div class="calculation-form">

							<form action="" id="calculation_form" class="calculation-form__form" method="post" enctype="multipart/form-data">
								<input type="hidden" name="my_file_upload" id="my_file_upload">
								<div class="row">
									<!-- левая колонка формы -->
									<div class="col-12 col-sm-12 col-md-6 col-lg-6">
										<div class="Flying_Placeholder">
											<label>Адрес Вашего сайта *</label>
											<input class="calculation-form__input" type="text" name="site-name" id="site-name">
										</div>
										<div class="Flying_Placeholder">
											<select name="bitrix" id="bitrix" class="S3_type_1 bitrix_edition">
												<option value="Старт">Старт</option>
												<option value="Стандарт">Стандарт</option>
												<option value="Малый бизнес">Малый бизнес</option>
												<option value="Бизнес">Бизнес</option>
												<option value="Энтерпрайз">Энтерпрайз</option>
											</select>
										</div>
										<div class="Flying_Placeholder">
											<label>Ваше имя*</label>
											<input class="calculation-form__input" type="text" name="user-name" id="user-name">
										</div>
										<div class="Flying_Placeholder">
											<label>Почта *</label>
											<input class="calculation-form__input" type="mail" name="user-mail" id="user-mail">
										</div>
										<div class="Flying_Placeholder">
											<label>Телефон</label>
											<input class="calculation-form__input" type="tel" name="user-phone" id="user-phone">
											<select id="calculation-form-contact_way" name="calculation-form-contact_way" class="contact_way">
												<option class="Manager" value="manager">Звонок менеджера</option>
												<option class="WhatsApp" value="WhatsApp">WhatsApp</option>
												<option class="Viber" value="Viber">Viber</option>
												<option class="Telegram" value="Telegram">Telegram</option>
											</select>
										</div>
										<!--div class="way_to_contact row no-gutters" >
											<div class="col-6">
												Как с Вами связаться?
											</div>
											<div class="col-6">
												<input type="radio" name="contact_way" class="contact_way_radio" id="wtc_manager" value="manager" checked>
												<label for="wtc_manager">Звонок менеджера</label>
												<br>
												<input type="radio" name="contact_way" class="contact_way_radio" value="WhatsApp" id="wtc_WhatsApp">
												<label for="wtc_WhatsApp">WhatsApp</label>
												<br>
												<input type="radio" name="contact_way" class="contact_way_radio" value="Viber" id="wtc_Viber">
												<label for="wtc_Viber">Viber</label>
												<br>
												<input type="radio" name="contact_way" class="contact_way_radio" value="Telegram" id="wtc_Telegram">
												<label for="wtc_Telegram">Telegram</label>
												<br>
											</div>
										</div-->
										<div class="calculation-form__checkbox d-inline-flex align-items-start">
											<div>
												<input type="checkbox" name="urgent-task" class="options" id="urgent-task">
											</div>
											<label for="urgent-task">У меня срочная задача</label>
											<div class="urgent-task-description non-urgent" for="urgent-task">Несрочная задача - 1800 руб/час. Реагируем на запрос в течение 2ч. Выполняем в плановом порядке.</div>
											<div class="urgent-task-description is-urgent" for="urgent-task">Срочная задача - 2700 руб/час. Реагируем за 15 мин. Выполняем немедленно</div>
										</div>
									</div>
									<!-- конец левая колонка формы -->

									<!-- правая колонка формы -->
									<div class="col-12 col-sm-12 col-md-6 col-lg-6">
										<div class="Flying_Placeholder">
											<label>Опишите Ваш вопрос/задачу/проблему *</label>
											<textarea class="calculation-form__input calculation-form__ta" name="site-problem"></textarea>
										</div>
										<div class="Flying_Placeholder">
											<label>Ссылки на проблемные страницы</label>
											<textarea class="calculation-form__input calculation-form__ta" name="site-problem-links"></textarea>
										</div>
										<div class="calculation-form__checkbox d-inline-flex align-items-center">
											<div>
												<input type="checkbox" name="user-device" class="options" id="user-device">
											</div>
											<label for="user-device">Я пишу с устройства, на котором обнаружилась проблема</label>
										</div>
										<label class="upload-descr">Добавьте файлы, в которых указана проблема</label>
										<div class="preloads">
											<!-- добавляется js при загрузке файлов -->
											<!--div class="p_item">
												<div class="p_text">
												</div>
												<div class="p_preview">
												<div class="p_close">×</div>
												</div>
											</div-->
										</div>
										<label class="upload-label d-inline-flex align-items-center" for="file-upload">
											<img src="img/calculation/paperclip.png" alt="">
											<span class="upload-button">Загрузить файл</span>
											<small class="upload-small">в формате: png/jpg/bmp; размер: до 5Мб.</small>
											<input class="calculation-form__input d-none" type="file" name="file-upload" id="file-upload" multiple accept="image/jpeg,image/png,image/bmp">
										</label>
										<div class="d-flex align-items-center justify-content-start">
											<button type="submit" class="button calculation-form__btn">
												Отправить заявку
											</button>
										</div>
										<div class="calculation-form__consent d-flex align-items-center justify-content-start">
											Нажимая на кнопку, я даю согласие на обработку персональных данных в соответствии с ФЗ №152 «О персональных данных»
										</div>
									</div>
									<!-- конец правая колонка формы -->
									<!-- низ формы -->
									<div class="col-12">
									</div>
									<!-- конец низ формы -->
								</div>
							</form>

						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- КОНЕЦ ВСПЛЫВАЮЩЕЙ ФОРМЫ Рассчитать стоимость-->

		<!-- НАЧАЛО ВСПЛЫВАЮЩЕЙ ФОРМЫ АУДИТ-->
		<div class="send-request modal fade" id="auditModal" tabindex="-1" role="dialog" aria-labelledby="ModalLongTitle" aria-hidden="true">
			<div class="popup modal-dialog m-0" role="document">
				<button type="button" class="popup-close close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
				<div class="popup-form">
					<div class="popup-form-header" id="ModalLongTitle">
						<div class="popup-form-header__title">Купи депозит и получи аудит сайта бесплатно*</div>
						<div class="audit_title">В рамках услуги выполняется анализ:</div>
						<div class="audit_list">
							<div>
								<ul>
									<li>целостности ядра;</li>
									<li>производительности;</li>
									<li>конфигурации сервера и ПО;</li>
									<li>файловой структуры;</li>
								</ul>
							</div>
							<div>
								<ul>
									<li>системы безопасности;</li>
									<li>верстки и HTML разметки страниц;</li>
									<li>скорости работы сайта;</li>
									<li>структур данных, шаблонов, компонентов;</li>
								</ul>
							</div>
						</div>
						<!-- <div class="popup-form-header__descr">
							*услуга "Аудит Сайта" оказывается бесплатно при покупке пакетного <b>тарифа "Бизнес"</b> до 31 октября 2019 года
						</div> -->
						<div class="popup-form-header__descr">
							<?php
							$audit_tariffs = array();
							foreach ($data->packages as $value)
								if ($value->free_audit === true)
									$audit_tariffs[] = $value->name;
							$str_audits = "";
							$aud_count = count($audit_tariffs);
							for ($i = 0; $i < $aud_count; ++$i) {
								$str_audits .= ($str_audits == "") ? "" : (($i == $aud_count - 1) ? " или " : ", ");
								$str_audits .= '"' . $audit_tariffs[$i] . '"';
							}
							?>
							*услуга "Аудит Сайта" оказывается бесплатно при покупке
							пакетного <b>тарифа <?= $str_audits ?></b> до 31 октября 2019 года
						</div>

					</div>
					<div class="clock-audit-wrapper">
						<div class="flipper" data-datetime="2019-11-01 23:59:59" data-template="dd|HH|ii|ss" data-labels="Дни|Часы|Минуты|Секунды" data-reverse="true" id="myFlipper_audit"></div>
					</div>
					<form action="" id="popup_form-audit" class="popup-form__form" method="POST">
						<div class="popup-form-box">
							<div class="Flying_Placeholder">
								<label>Имя *</label>
								<input class="popup-form-box__input" type="text" name="user-name_modal-audit" id="user-name_modal-audit">
							</div>
							<div class="Flying_Placeholder">
								<label>Телефон</label>
								<input class="popup-form-box__input" type="tel" name="user-phone_modal-audit" id="user-phone_modal-audit">
								<select id="popup-form-contact_way-audit" name="popup-form-contact_way-audit" class="contact_way">
									<option class="Manager" value="manager">Звонок менеджера</option>
									<option class="WhatsApp" value="WhatsApp">WhatsApp</option>
									<option class="Viber" value="Viber">Viber</option>
									<option class="Telegram" value="Telegram">Telegram</option>
								</select>
							</div>
							<div class="Flying_Placeholder">
								<select name="bitrix_audit" id="bitrix_audit" class="S3_type_1 bitrix_edition">
									<option value="Старт">Старт</option>
									<option value="Стандарт">Стандарт</option>
									<option value="Малый бизнес">Малый бизнес</option>
									<option value="Бизнес">Бизнес</option>
									<option value="Энтерпрайз">Энтерпрайз</option>
								</select>
							</div>
							<div class="Flying_Placeholder">
								<label>Адрес сайта *</label>
								<input class="popup-form-box__input" name="user-linksite_modal-audit" id="user-linksite_modal-audit"></input>
							</div>

						</div>
						<div class="popup-form__button d-flex justify-content-center">
							<button class="button popup-form__btn_audit">
								Отправить заявку
							</button>
						</div>
						<div class="popup-form-desc">
							Нажимая на кнопку я соглашаюсь на передачу личных данных ФЗ РФ № 152 «О защите персональных данных»
						</div>
					</form>
				</div>
			</div>
		</div>
		<!-- КОНЕЦ ВСПЛЫВАЮЩЕЙ ФОРМЫ АУДИТ-->

		<!-- НАЧАЛО ФОРМЫ СОТРУДНИЧЕСТВО -->
		<div class="send-request modal fade" id="ModalCollaboration" tabindex="-1" role="dialog" aria-labelledby="ModalCollaborationTitle" aria-hidden="true">
			<div class="popup modal-dialog m-0" role="document">
				<button type="button" class="popup-close close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>

				<div class="popup-form">
					<div class="popup-form-header" id="ModalCollaborationTitle">
						<div class="popup-form-header__title">Заявка на сотрудничество</div>
						<div class="popup-form-header__descr">Заполните анкету и мы отправим вам предложение на почту</div>
					</div>

					<form action="" id="collaboration_form" class="popup-form__form" method="POST">
						<div class="row">
							<!-- левая колонка формы -->
							<div class="col-12 col-sm-12 col-md-6 col-lg-6">
								<div class="Flying_Placeholder">
									<label>Ваше имя *</label>
									<input class="popup-form-box__input" type="text" name="user-name_collabForm" id="user-name_collabForm">
								</div>
								<div class="Flying_Placeholder">
									<label>Ваша должность *</label>
									<input class="popup-form-box__input" type="text" name="user-post_collabForm" id="user-name_collabForm">
								</div>
								<div class="Flying_Placeholder">
									<label>E-mail *</label>
									<input class="popup-form-box__input" type="mail" name="user-mail_collabForm" id="user-mail_collabForm">
								</div>
								<div class="Flying_Placeholder">
									<label>Телефон</label>
									<input class="popup-form-box__input" type="tel" name="user-phone_collabForm" id="user-phone_collabForm">

									<select id="contact-way_collabForm" name="contact-way_collabForm" class="contact_way">
										<option class="Manager" value="manager">Звонок менеджера</option>
										<option class="WhatsApp" value="WhatsApp">WhatsApp</option>
										<option class="Viber" value="Viber">Viber</option>
										<option class="Telegram" value="Telegram">Telegram</option>
									</select>
								</div>
								<div class="Flying_Placeholder">
									<label>Название компании *</label>
									<input class="popup-form-box__input" name="company-name_collabForm" id="company-name_collabForm"></input>
								</div>
								<div class="Flying_Placeholder">
									<label>Сайт *</label>
									<input class="popup-form-box__input" name="user-linksite_collabForm" id="user-linksite_collabForm"></input>
								</div>
								<div class="Flying_Placeholder">
									<label>Лет на рынке *</label>
									<input id="years_on_market" name="years_on_market" type="number" value="" min="0">
								</div>

							</div>
							<!-- конец левая колонка формы -->

							<!-- правая колонка формы -->
							<div class="col-12 col-sm-12 col-md-6 col-lg-6">
								<div class="Flying_Placeholder">
									<label>Штат *</label>
									<input id="staff" name="staff" type="number" value="" min="0">
								</div>
								<div class="Flying_Placeholder">
									<select name="activity" id="activity" class="S3_type_1">
										<option value="Веб-разработка">Веб-разработка</option>
										<option value="Реклама">Реклама</option>
										<option value="Продвижение">Продвижение</option>
										<option value="Интеграция">Интеграция</option>
										<option value="Консалтинг">Консалтинг</option>
									</select>
								</div>

								<div class="Flying_Placeholder">
									<select name="proj_types" id="proj_types" class="S3_type_1">
										<option value="Промо">Промо</option>
										<option value="Лэндинги/визитки">Лэндинги/визитки</option>
										<option value="Корп сайты">Корп сайты</option>
										<option value="Интернет-магазины">Интернет-магазины</option>
										<option value="Агрегаторы/инфопорталы">Агрегаторы/инфопорталы</option>
										<option value="Хайлоады">Хайлоады</option>
									</select>
								</div>
								<div class="modal_range_descr">
									Укажите общее количество выполненных проектов
								</div>
								<div class="Flying_Placeholder">
									<input type="text" class="js-range-slider" name="proj_num" id="proj_num" value="" />
								</div>
								<div class="calculation-form__checkbox d-inline-flex align-items-center">
									<div>
										<input type="checkbox" name="bitrix-only" class="options" id="bitrix-only">
									</div>
									<label for="bitrix-only">Работаем только с CMS 1С-Битрикс</label>
								</div>
								<div class="calculation-form__checkbox d-inline-flex align-items-center">
									<div>
										<input type="checkbox" name="bitrix-partner" class="options" id="bitrix-partner">
									</div>
									<label for="bitrix-partner">Партнеры 1С-Битрикс</label>
								</div>

								<div class="popup-form__button d-flex justify-content-center">
									<button class="button popup-form__btn">
										Отправить заявку
									</button>
								</div>
								<div class="popup-form-desc">
									Нажимая на кнопку я соглашаюсь на передачу личных данных ФЗ РФ № 152 «О защите персональных данных»
								</div>
								<!-- /.popup-form__btn -->
								<!-- конец правая колонка формы -->
							</div>
						</div>
					</form>
				</div>
				<!-- /.popup-form -->
			</div>
			<!-- /.popup -->
		</div>
		<!-- КОНЕЦ ФОРМЫ СОТРУДНИЧЕСТВО -->

		<!-- НАЧАЛО ВСПЛЫВАЮЩЕЙ ФОРМЫ ПЕРВЫЙ МЕСЯЦ ОБСЛУЖИВАНИЯ-->
		<div class="send-request modal fade" id="firstMonthModal" tabindex="-1" role="dialog" aria-labelledby="ModalLongTitle" aria-hidden="true">
			<div class="popup modal-dialog m-0" role="document">
				<button type="button" class="popup-close close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
				<div class="popup-form">
					<div class="popup-form-header" id="ModalLongTitle">
						<div class="popup-form-header__title">Закажи техподдержку на год и получи первый месяц бесплатно*</div>
						<div class="freeMonth_title">
							Предоставляется бесплатный тестовый период на 1 месяц, в течение которого у вас есть возможность потребовать возврат оплаты без объяснения причины.
						</div>
						<div class="popup-form-header__descr">*при оплате тех. поддержки на 12 месяцев, 1-ый месяц бесплатно.</div>

					</div>
					<form action="" id="popup_form-freeMonth" class="popup-form__form" method="POST">
						<div class="popup-form-box">
							<div class="Flying_Placeholder">
								<label>Имя *</label>
								<input class="popup-form-box__input" type="text" name="user-name_modal-freeMonth" id="user-name_modal-freeMonth">
							</div>
							<div class="Flying_Placeholder">
								<label>Телефон</label>
								<input class="popup-form-box__input" type="tel" name="user-phone_modal-freeMonth" id="user-phone_modal-freeMonth">
								<select id="popup-form-contact_way-freeMonth" name="popup-form-contact_way-freeMonth" class="contact_way">
									<option class="Manager" value="manager">Звонок менеджера</option>
									<option class="WhatsApp" value="WhatsApp">WhatsApp</option>
									<option class="Viber" value="Viber">Viber</option>
									<option class="Telegram" value="Telegram">Telegram</option>
								</select>
							</div>
							<div class="Flying_Placeholder">
								<select name="bitrix_freeMonth" id="bitrix_freeMonth" class="S3_type_1 bitrix_edition">
									<option value="Старт">Старт</option>
									<option value="Стандарт">Стандарт</option>
									<option value="Малый бизнес">Малый бизнес</option>
									<option value="Бизнес">Бизнес</option>
									<option value="Энтерпрайз">Энтерпрайз</option>
								</select>
							</div>
							<div class="Flying_Placeholder">
								<label>Адрес сайта *</label>
								<input class="popup-form-box__input" name="user-linksite_modal-freeMonth" id="user-linksite_modal-freeMonth"></input>
							</div>

						</div>
						<div class="popup-form__button d-flex justify-content-center">
							<button class="button popup-form__btn_freeMonth">
								Отправить заявку
							</button>
						</div>
						<div class="popup-form-desc">
							Нажимая на кнопку я соглашаюсь на передачу личных данных ФЗ РФ № 152 «О защите персональных данных»
						</div>
					</form>
				</div>
			</div>
		</div>
		<!-- КОНЕЦ ВСПЛЫВАЮЩЕЙ ФОРМЫ ПЕРВЫЙ МЕСЯЦ ОБСЛУЖИВАНИЯ-->

		<!-- НАЧАЛО ВСПЛЫВАЮЩЕЙ ФОРМЫ  ГАРАНТИЯ ВОЗВРАТА ОПЛАТЫ-->
		<div class="send-request modal fade" id="guaranteeModal" tabindex="-1" role="dialog" aria-labelledby="ModalLongTitle" aria-hidden="true">
			<div class="popup modal-dialog m-0" role="document">
				<button type="button" class="popup-close close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
				<div class="popup-form">
					<div class="popup-form-header" id="ModalLongTitle">
						<div class="popup-form-header__title">Гарантия возврата оплаты*</div>
						<div class="guarantee_title">Предоставляется бесплатный тестовый период на 1 месяц, в течение которого у вас есть возможность потребовать возврат оплаты без объяснения причины.</div>
						<div class="popup-form-header__descr">*гарантия возврата при оплате техподдержки на 12 месяцев.</div>
					</div>
					<form action="" id="popup_form-guarantee" class="popup-form__form" method="POST">
						<div class="popup-form-box">
							<div class="Flying_Placeholder">
								<label>Имя *</label>
								<input class="popup-form-box__input" type="text" name="user-name_modal-guarantee" id="user-name_modal-guarantee">
							</div>
							<div class="Flying_Placeholder">
								<label>Телефон</label>
								<input class="popup-form-box__input" type="tel" name="user-phone_modal-guarantee" id="user-phone_modal-guarantee">
								<select id="popup-form-contact_way-guarantee" name="popup-form-contact_way-guarantee" class="contact_way">
									<option class="Manager" value="manager">Звонок менеджера</option>
									<option class="WhatsApp" value="WhatsApp">WhatsApp</option>
									<option class="Viber" value="Viber">Viber</option>
									<option class="Telegram" value="Telegram">Telegram</option>
								</select>
							</div>
							<div class="Flying_Placeholder">
								<select name="bitrix_guarantee" id="bitrix_guarantee" class="S3_type_1 bitrix_edition">
									<option value="Старт">Старт</option>
									<option value="Стандарт">Стандарт</option>
									<option value="Малый бизнес">Малый бизнес</option>
									<option value="Бизнес">Бизнес</option>
									<option value="Энтерпрайз">Энтерпрайз</option>
								</select>
							</div>
							<div class="Flying_Placeholder">
								<label>Адрес сайта *</label>
								<input class="popup-form-box__input" name="user-linksite_modal-guarantee" id="user-linksite_modal-guarantee"></input>
							</div>

						</div>
						<div class="popup-form__button d-flex justify-content-center">
							<button class="button popup-form__btn_guarantee">
								Отправить заявку
							</button>
						</div>
						<div class="popup-form-desc">
							Нажимая на кнопку я соглашаюсь на передачу личных данных ФЗ РФ № 152 «О защите персональных данных»
						</div>
					</form>
				</div>
			</div>
		</div>
		<!-- КОНЕЦ ВСПЛЫВАЮЩЕЙ ФОРМЫ  ГАРАНТИЯ ВОЗВРАТА ОПЛАТЫ-->

		<!-- НАЧАЛО ФОРМЫ НЕ НАШЛИ УСЛУГУ -->
		<div class="send-request modal fade" id="ModalRequest" tabindex="-1" role="dialog" aria-labelledby="ModalRequestTitle" aria-hidden="true">
			<div class="popup modal-dialog m-0" role="document">
				<button type="button" class="popup-close close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
				<!-- <div class="popup-close close" data-dismiss="modal" aria-label="Close">&times;</div>-->
				<!-- /.popup-close -->

				<div class="popup-form">
					<div class="popup-form-header" id="ModalRequestTitle">
						<div class="popup-form-header__title">Связаться со мной</div>
						<div class="popup-form-header__descr">Заполните анкету и наши специалисты свяжутся с вами</div>
					</div>
					<form action="" id="request_form-form" class="request-form request_form-form" method="POST">
						<div class="request-form-box">
							<div class="Flying_Placeholder">
								<label>Имя *</label>
								<input class="popup-form-box__input" type="text" name="user-name_request-form" id="user-name_request-form">
							</div>
							<div class="Flying_Placeholder">
								<label>Телефон</label>
								<input class="popup-form-box__input" type="tel" name="user-phone_request-form" id="user-phone_request-form">
								<select id="request-form-contact_way" name="request-form-contact_way" class="contact_way">
									<option class="Manager" value="manager">Звонок менеджера</option>
									<option class="WhatsApp" value="WhatsApp">WhatsApp</option>
									<option class="Viber" value="Viber">Viber</option>
									<option class="Telegram" value="Telegram">Telegram</option>
								</select>
							</div>
							<div class="Flying_Placeholder">
								<label>E-mail *</label>
								<input class="popup-form-box__input" type="mail" name="user-mail_request-form" id="user-mail_request-form">
							</div>
							<?php /*
							<div class="Flying_Placeholder">
								<select name="bitrix_request-form" id="bitrix_request-form" class="S3_type_1 bitrix_edition">
									<option value="Старт">Старт</option>
									<option value="Стандарт">Стандарт</option>
									<option value="Малый бизнес">Малый бизнес</option>
									<option value="Бизнес">Бизнес</option>
									<option value="Энтерпрайз">Энтерпрайз</option>
									<option value="Я не знаю">Я не знаю</option>
								</select>
							</div>
							<div class="Flying_Placeholder">
								<label>Адрес сайта *</label>
								<input class="popup-form-box__input" name="user-linksite_request-form" id="user-linksite_request-form"></input>
							</div>
							*/ ?>
						</div>
						<div class="request-form__button d-flex justify-content-center">
							<button class="button request-form__btn">
								Отправить
							</button>
						</div>
						<div class="request-form-desc">
							Нажимая на кнопку вы соглашаетесь на передачу личных данных ФЗ РФ № 152 «О защите персональных данных»
						</div>
					</form>
				</div>
				<!-- /.popup-form -->
			</div>
			<!-- /.popup -->
		</div>
		<!-- КОНЕЦ НЕ НАШЛИ УСЛУГУ -->

		<!-- НАЧАЛО ВСПЛЫВАЮЩЕЕ ОКНО КАЛЬКУЛЯТОРА -->
		<div class="send-request modal fade" id="ModalCalculator" tabindex="-1" role="dialog" aria-labelledby="ModalCalculatorTitle" aria-hidden="true">
			<div class="popup modal-dialog m-0" role="document">
				<button type="button" class="popup-close close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
				<!-- <div class="popup-close close" data-dismiss="modal" aria-label="Close">&times;</div>-->
				<!-- /.popup-close -->
				<!-- Контент модального окна -->
				<div class="modalContent">

					<div class="calculator" id="calculator">
						<div class="CalcTitle">Оцените, сколько вам нужно часов*</div>
						<div class="subtitle"></div>
						<div class="CalcTable">
							<div class="CalcHeader">
								<div class="CalcRow">
									<div class="colService">Выбрать услугу</div>
									<div class="colAmount">Количество</div>
									<div class="colClose"></div>
								</div>
							</div>
							<div class="CalcBody">
								<template id="calculator_row">
									<div class="CalcRow">
										<div class="colService">
											<div class="action"></div>
											<div class="service">
												<select class="serviceList" tabindex="0"></select>
											</div>
										</div>
										<div class="colAmount"><input type="text" name="" id="" min="1" class="amount"></div>
										<div class="colClose">
											<div class="close"></div>
										</div>
									</div>
								</template>
							</div>
							<div class="CalcFooter">
								<div class="CalcRow">
									<div class="colService">
										<div class="action"></div>
										<div class="service">Добавить услугу</div>
									</div>
								</div>
							</div>
						</div>
						<div class="CalcFooter">
							<div class="result"></div>
							<div class="request">
								<div class="requestBtn">Оставить заявку</div>
								<div class="footnote">* оценка является приблизительной</div>
							</div>
						</div>
					</div>
					<!-- Конец контента модального окна -->
				</div>
				<!-- /.popup -->
			</div>
			<!-- КОНЕЦ ВСПЛЫВАЮЩЕЕ ОКНО КАЛЬКУЛЯТОРА -->
		</div>
		<!-- /.wrap -->


		<script src="js/jquery.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<script src="js/jquery.custominputmask.min.js"></script>
		<!--script src="https://cdn.jsdelivr.net/gh/S-a-n-d-r-0/select3@master/select3.min.js"></script-->
		<script src="js/select3.js"></script>

		<!-- костыль для корректного подключения jquery.mobile - его конфигурация перед подключением -->
		<!--script>$(document).on("mobileinit", function() {
		$.mobile.autoInitializePage = false;
		});</script>

		<script src="js/jquery.mobile-1.5.0-rc1.min.js"></script-->
		<script src="js/animateNumber.min.js"></script>
		<script src="js/savy.min.js"></script>
		<script src="js/detect.min.js"></script>
		<script src="js/flipper-responsive.js"></script>
		<script src="js/main.js"></script>
		<!--script src="js/select2.min.js"></script-->
		<script src="js/ion.rangeSlider.min.js"></script>
		<script src="js/zebra_datepicker.min.js"></script>
		<script src="js/jquery.nice-number.js"></script>
		<script src="js/calculator.js"></script>

</body>

</html>