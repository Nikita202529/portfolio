<?php

/**
 * Clean comments of json content and decode it with json_decode().
 * Work like the original php json_decode() function with the same params
 *
 * @param   string  $json    The json string being decoded
 * @param   bool    $assoc   When TRUE, returned objects will be converted into associative arrays.
 * @param   integer $depth   User specified recursion depth. (>=5.3)
 * @param   integer $options Bitmask of JSON decode options. (>=5.4)
 * @return  string
 */
function json_clean_decode($json, $assoc = false, $depth = 512, $options = 0)
{
	// search and remove comments like /* */ and //
	$json = preg_replace("#(/\*([^*]|[\r\n]|(\*+([^*/]|[\r\n])))*\*+/)|([\s\t]//.*)|(^//.*)#", '', $json);

	if (version_compare(phpversion(), '5.4.0', '>=')) {
		$json = json_decode($json, $assoc, $depth, $options);
	} elseif (version_compare(phpversion(), '5.3.0', '>=')) {
		$json = json_decode($json, $assoc, $depth);
	} else {
		$json = json_decode($json, $assoc);
	}

	return $json;
}


$dataurl = 'data.json'; // path to your JSON file
$filedata = file_get_contents($dataurl); // put the contents of the file into a variable
$data = json_clean_decode($filedata); // decode the JSON feed
/*
if (json_last_error() !== JSON_ERROR_NONE)
	die(json_last_error_msg());
*/
//die(strval(json_last_error()));

//var_dump($data);

?>

<!DOCTYPE html>
<html lang="ru">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<meta name="description" content="Техническая поддержка и доработка сайтов на 1С-Битрикс. Разовая и постоянная техподдержка. Пакетные депозиты. Гибкое ценообразование. Поминутный учет времени. Специальные предложения для студий и агентств.">
	<meta name="keywords" content="поддержка сайта 1С-Битрикс, доработка сайта 1С-Битрикс, постоянная техподдержка сайта, сопровождение сайта Битрикс, разработка битрикс, программист битрикс, Битрикс, bitrix">

	<title>Поддержка сайтов на 1С-Битрикс - от 1200 руб</title>
	<link rel="icon" href="favicon.ico" type="image/x-icon">
	<!-- Bootstrap -->
	<!--link href="css/bootstrap.css" rel="stylesheet"-->
	<!--link href="css/bootstrap_modified_16.07.19.php" rel="stylesheet"-->
	<link href="css/bootstrap_modified_16.07.19.min.css" rel="stylesheet">
	<!-- Custom -->
	<link href="https://fonts.googleapis.com/css?family=Roboto:300|Roboto+Condensed:400,500|Open+Sans:300,400,600,700,800&amp;subset=cyrillic" rel="stylesheet">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.0/css/all.css" integrity="sha384-Mmxa0mLqhmOeaE8vgOSbKacftZcsNYDjQzuCOm6D02luYSzBG8vpaOykv9lFQ51Y" crossorigin="anonymous">

	<!--link rel="stylesheet" href="css/style.php"-->
	<link rel="stylesheet" href="css/flipper-responsive.css">
	<link rel="stylesheet" href="css/style.min.css">
	<link rel="stylesheet" href="css/ion.rangeSlider.css">
	<link rel="stylesheet" href="css/zebra_datepicker.css">
	<link rel="stylesheet" href="css/jquery.nice-number.css">
	<link rel="stylesheet" href="css/calculator.select3.min.css">
	<link rel="stylesheet" href="css/calculator.min.css">
</head>
<script>
	const data = JSON.parse('<?= json_encode($data) ?>');
</script>

<!-- виджет -->
<script>
	(function(w, d, u) {
		var s = d.createElement('script');
		s.async = true;
		s.src = u + '?' + (Date.now() / 60000 | 0);
		var h = d.getElementsByTagName('script')[0];
		h.parentNode.insertBefore(s, h);
	})(window, document, 'https://cdn.bitrix24.ru/b97479/crm/site_button/loader_2_by2fyy.js');
</script>
<!-- конец -- виджет -->

<body>

	<!-- Yandex.Metrika counter -->
	<script type="text/javascript">
		(function(m, e, t, r, i, k, a) {
			m[i] = m[i] || function() {
				(m[i].a = m[i].a || []).push(arguments)
			};
			m[i].l = 1 * new Date();
			k = e.createElement(t), a = e.getElementsByTagName(t)[0], k.async = 1, k.src = r, a.parentNode.insertBefore(k, a)
		})
		(window, document, "script", "https://mc.yandex.ru/metrika/tag.js", "ym");

		ym(54779350, "init", {
			clickmap: true,
			trackLinks: true,
			accurateTrackBounce: true,
			webvisor: true
		});
	</script>
	<noscript>
		<div><img src="https://mc.yandex.ru/watch/54779350" style="position:absolute; left:-9999px;" alt="" /></div>
	</noscript>
	<!-- /Yandex.Metrika counter -->

	<div class="wrap">

		<div class="hamburger"></div>
		<div class="menu">
			<div class="container-fluid pl-0 pr-0 h-100">
				<div class="row no-gutters h-100">
					<div class="col-12">
						<!-- лого и стрелочка -->
						<div class="menu-top">
							<div class="menu-top_arrow"></div>
							<div class="menu-logo">
								<img src="img/header/logo-white.svg" alt="ADM">
							</div>
						</div>
						<!-- ./menu-top -->

						<ul class="menu-list">
							<li class="menu-item">
								<a href="https://1c-bitrixsupport.ru/#aboutServices" class="menu-link btn-scroll">
									Что мы предлагаем
								</a>
							</li>
							<!-- li -->
							<li class="menu-item">
								<a href="https://1c-bitrixsupport.ru/#subscription" class="menu-link btn-scroll">
									Постоянная техподдержка
								</a>
							</li>
							<!-- li -->
							<li class="menu-item">
								<a href="https://1c-bitrixsupport.ru/#support" class="menu-link btn-scroll">
									Почасовая оплата
								</a>
							</li>
							<!-- li -->
							<li class="menu-item">
								<a href="https://1c-bitrixsupport.ru/#support-services" class="menu-link btn-scroll">
									Услуги техподдержки
								</a>
							</li>
							<!-- li -->
							<li class="menu-item">
								<a href="https://1c-bitrixsupport.ru/#recommend" class="menu-link btn-scroll">
									Как мы работаем
								</a>
							</li>
							<!-- li -->
							<li class="menu-item">
							<a href="https://1c-bitrixsupport.ru/#calculation" class="menu-link btn-scroll">
									Оставить заявку
								</a>
							</li>
							<!-- li -->
							<li class="menu-item">
								<a href="#footer" class="menu-link btn-scroll">
									Контакты
								</a>
							</li>
							<!-- li -->
						</ul>
						<!-- ul -->

						<div class="menu-social">
							<div class="menu-socials-wrap">
								<a href="https://www.facebook.com/admcenter.ru/"><span class="icon-facebook"></span></a>
								<!--a href="#"><span class="icon-vkontakte"></span></a-->
								<!--a href="#"><span class="icon-odnoklassniki"></span></a-->
								<!--a href="#"><span class="icon-twitter"></span></a-->
								<a href="tg://resolve?domain=admasya"><span class="icon-telegram"></span></a>
								<a href="https://www.instagram.com/admcenter/"><span class="icon-instagram"></span></a>
								<a href="whatsapp://send?phone=+79281631100"><span class="icon-whatsapp"></span></a>
								<a href="viber://add?number=79281631100"><span class="icon-viber-brands"></span></a>
								<!--a href="#"><span class="icon-pinterest"></span></a-->
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- ./menu -->

		<div class="scrollcontent">

			<header class="header">
				<div class="container">
					<div class="row align-items-center">
						<div class="col-6 col-sm-4 col-md-6 col-lg-4">
							<div class="row align-items-end">
								<div class="col-5 col-sm-5 d-md-none d-lg-none">
									<!-- тут был гамбургер -->
								</div>

								<div class="col-7 col-sm-6 col-md-8 col-lg-6">
									<div href="http://adm-center.ru/" class="header-logo">
										<img src="img/header/logo.svg" alt="ADM">
									</div>
								</div>
							</div>
						</div>

						<div class="col-6 col-sm-8 col-md-6 col-lg-8 d-flex justify-content-end align-items-center">
							<a class="header-phone header-phone__mhidden" href="tel:+7(863)226-90-95">+7 (863) 226-90-95</a>
							<a class="header-btn button forCalcModal" href="" data-toggle="modal" data-target="#calculateTheCostModal">Поставить задачу</a>
							<!-- <button type="button" class="header-btn button" title>
					  Оставить заявку
					</button> -->
						</div>
					</div>
					<!-- /.row -->
				</div>
				<!-- /.container -->
			</header>
			<!-- /.header -->

			<div class="terms_workarea">
				<div class="container">
					<div class="row">
						<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
							<h2 style="text-align: center;">Пользовательское соглашение</h2>
							<p style="text-align: center;">
								<b>В целях соблюдения 152-ФЗ "о защите персональных данных"</b>
								<p>
							Присоединяясь к настоящему Соглашению и оставляя свои данные на Сайте bitrixsupport.adm-center.ru (далее – Сайт), путем заполнения полей форм обратной связи Пользователь: подтверждает, что все указанные им данные принадлежат лично ему, подтверждает и признает, что им внимательно в полном объеме прочитано Соглашение и условия обработки его персональных данных, указываемых им в полях форм обратной связи, текст соглашения и условия обработки персональных данных ему понятны; дает согласие на обработку Сайтом предоставляемых в составе информации персональных данных в целях заключения между ним и Сайтом настоящего Соглашения, а также его последующего исполнения; выражает согласие с условиями обработки персональных данных без оговорок и ограничений. 
							</p>
							<p>
							Пользователь дает свое согласие на обработку его персональных данных, а именно совершение действий, предусмотренных п. 3 ч. 1 ст. 3 Федерального закона от 27.07.2006 N 152-ФЗ "О персональных данных", и подтверждает, что, давая такое согласие, он действует свободно, своей волей и в своем интересе. Согласие Пользователя на обработку персональных данных является конкретным, информированным и сознательным. <br>
							</p>
							<p>
							Настоящее согласие Пользователя признается исполненным в простой письменной форме, на обработку следующих персональных данных: фамилии, имени, отчества; года рождения; места пребывания (город, область); номеров телефонов; адресов электронной почты (E-mail). <br>
							</p>
							<p>
							Пользователь, предоставляет bitrixsupport.adm-center.ru право осуществлять следующие действия (операции) с персональными данными: сбор и накопление; хранение в течение установленных нормативными документами сроков хранения отчетности, но не менее трех лет, с момента даты прекращения пользования услуг Пользователем; уточнение (обновление, изменение); использование; уничтожение; обезличивание; передача по требованию суда, в т.ч., третьим лицам, с соблюдением мер, обеспечивающих защиту персональных данных от несанкционированного доступа. <br>
							</p>
							<p>
							Указанное согласие действует бессрочно с момента предоставления данных и может быть отозвано Вами путем подачи заявления администрации сайта с указанием данных, определенных ст. 14 Закона «О персональных данных». Отзыв согласия на обработку персональных данных может быть осуществлен путем направления Пользователем соответствующего распоряжения в простой письменной форме на адрес электронной почты (E-mail) mail@adm-center.ru <br>
							</p>
							<p>
							Сайт не несет ответственности за использование (как правомерное, так и неправомерное) третьими лицами Информации, размещенной Пользователем на Сайте, включая её воспроизведение и распространение, осуществленные всеми возможными способами. Сайт имеет право вносить изменения в настоящее Соглашение. При внесении изменений в актуальной редакции указывается дата последнего обновления. Новая редакция Соглашения вступает в силу с момента ее размещения, если иное не предусмотрено новой редакцией Соглашения. Ссылка на действующую редакцию всегда находится на страницах сайта: bitrixsupport.adm-center.ru <p>
							</p>
							<p>
							К настоящему Соглашению и отношениям между пользователем и Сайтом, возникающим в связи с применением Соглашения подлежит применению право Российской Федерации.<br>
							</p>
						</div>
					</div>
				</div>
			</div>

			<footer class="footer">
				<a id="footer" name="footer"></a>
				<!--якорь-->
				<div class="footer-top">
					<div class="container">
						<div class="row">
							<div class="col-12 col-sm-4 col-md-4 col-lg-4 d-flex justify-content-start justify-content-md-center">
								<ul class="footer-top__list list-1">
									<li><a href="tel:+7(863)226-90-95" class="footer-top-link">+7 (863) 226-90-95</a></li>
								</ul>
							</div>
							<!-- /.col-4 -->
							<div class="col-12 col-sm-4 col-md-4 col-lg-4 d-flex justify-content-start justify-content-md-center">
								<ul class="footer-top__list list-2">
									<li><a href="tel:+7(928)163-11-00" class="footer-top-link">+7 (928) 163-11-00</a></li>
								</ul>
							</div>
							<!-- /.col-4 -->
							<div class="col-12 col-sm-4 col-md-4 col-lg-4 d-flex justify-content-start justify-content-md-center">
								<ul class="footer-top__list list-3">
									<li><a href="mailto:mail@adm-center.ru" class="footer-top-link">mail@adm-center.ru</a></li>
								</ul>
							</div>
							<!-- /.col-4 -->
						</div>
						<!-- /.row -->
					</div>
					<!-- /.container -->
				</div>
				<!-- /.footer-top -->
				<div class="footer-bottom">
					<div class="container">
						<div class="row align-items-center">
							<div class="col-11 col-sm-11 col-md-4 col-lg-4 offset-1 offset-md-0">
								<div class="no-gutters  footer-bottom-social d-inline-flex">
									<a href="https://www.facebook.com/admcenter.ru/" target="_blank"><span class="icon-facebook"></span></a>
									<!--a href="#"><span class="icon-vkontakte"></span></a-->
									<!--a href="#"><span class="icon-odnoklassniki"></span></a-->
									<!--a href="#"><span class="icon-twitter"></span></a-->
									<a href="tg://resolve?domain=admasya" target="_blank"><span class="icon-telegram"></span></a>
									<a href="https://www.instagram.com/admcenter/" target="_blank"><span class="icon-instagram"></span></a>
									<a href="whatsapp://send?phone=+79281631100" target="_blank"><span class="icon-whatsapp"></span></a>
									<a href="viber://add?number=79281631100" target="_blank"><span class="icon-viber-brands"></span></a>
									<!--a href="#"><span class="icon-pinterest"></span></a-->
								</div>
								<!-- /.footer-bottom-social -->
							</div>
							<!-- /.col-6 -->
							<div class="col-11 col-sm-11 col-md-8 col-lg-8 offset-1 offset-md-0">
								<div class="row align-items-center">
									<div class="col-12 col-md-5 col-lg-5 d-flex justify-content-start justify-content-lg-end">
										<a href="" target="_blank" class="footer-bottom-privacy">
											Соглашение об использовании персональных данных
										</a>
									</div>
									<div class="col-12 col-md-4 col-lg-4 d-flex justify-content-start justify-content-lg-end">
										<a href="policy.php" target="_blank" class="footer-bottom-privacy">
											Политика конфиденциальности
										</a>
									</div>
									<div class="col-12 col-md-3 col-lg-3 d-flex justify-content-start justify-content-md-end">
										<div class="footer-bottom-copy">
											&#169; 2008-2019 ЦИТ «ADM»
										</div>
									</div>
								</div>
								<!-- /.row -->

							</div>
							<!-- /.col-6 -->
						</div>
						<!-- /.row -->
					</div>
					<!-- /.container -->
				</div>
				<!-- /.footer-bottom -->
			</footer>
			<!-- /.footer -->
		</div>
		<!-- /.scrollcontent -->

		<!-- НАЧАЛО ВСПЛЫВАЮЩЕЙ ФОРМЫ -->
		<div class="send-request modal fade" id="ModalLong" tabindex="-1" role="dialog" aria-labelledby="ModalLongTitle" aria-hidden="true">
			<div class="popup modal-dialog m-0" role="document">
				<button type="button" class="popup-close close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
				<!-- <div class="popup-close close" data-dismiss="modal" aria-label="Close">&times;</div>-->
				<!-- /.popup-close -->

				<div class="popup-form">
					<div class="popup-form-header" id="ModalLongTitle">
						<div class="popup-form-header__title">Оставьте заявку на постоянное обслуживание</div>
						<div class="popup-form-header__descr">Заполните анкету и наши специалисты свяжутся с вами для обсуждения возможностей сотрудничества</div>
					</div>
					<form action="" id="popup_form" class="popup-form__form" method="POST">
						<div class="popup-form-box">
							<div class="Flying_Placeholder">
								<label>Имя *</label>
								<input class="popup-form-box__input" type="text" name="user-name_modal" id="user-name_modal">
							</div>
							<div class="Flying_Placeholder">
								<label>Адрес сайта *</label>
								<input class="popup-form-box__input" name="user-linksite_modal" id="user-linksite_modal"></input>
							</div>
							<div class="Flying_Placeholder">
								<label>E-mail *</label>
								<input class="popup-form-box__input" type="mail" name="user-mail_modal" id="user-mail_modal">
							</div>
							<div class="Flying_Placeholder">
								<label>Телефон</label>
								<input class="popup-form-box__input" type="tel" name="user-phone_modal" id="user-phone_modal">

								<select id="popup-form-contact_way" name="popup-form-contact_way" class="contact_way">
									<option class="Manager" value="manager">Звонок менеджера</option>
									<option class="WhatsApp" value="WhatsApp">WhatsApp</option>
									<option class="Viber" value="Viber">Viber</option>
									<option class="Telegram" value="Telegram">Telegram</option>
								</select>
							</div>
							<!--div class="Flying_Placeholder">
							<label>Телефон</label>
							<input class="popup-form-box__input" type="tel" name="user-phone_modal" id="user-phone_modal" >
						</div-->
							<div class="Flying_Placeholder">
								<select name="project" id="project" class="S3_type_1">
									<?php foreach ($data->site_types as $value) : //цикл по столбцам 
										?>
										<?php $v = ($value == "Корпоративный сайт/<br>Сайт-каталог") ? "Корпоративный/сайт-каталог" : $value; ?>
										<option value="<?= $v ?>"><?= $v ?></option>
									<?php endforeach; ?>
								</select>
							</div>
							<!--div class="Flying_Placeholder">
								<div class="row no-gutters" style="width: 100%;">
									
									
									<select name="tariff" id="tariff" class="S3_type_1 bitrix_edition">
										<option value="Стандарт">Стандарт</option>
										<option value="Эксперт">Эксперт</option>
										<option value="Бизнес">Бизнес</option>
										<option value="Бизнес Pro">Бизнес Pro</option>
									</select>
									<div id="price">
									</div>
								</div>
							</div-->
							<div class="Flying_Placeholder">
								<input type="text" class="js-range-slider" name="tariff" id="tariff" value="" />
							</div>
							<div id="price">
							</div>
						</div>
						<!-- /.popup-form-box -->

						<div class="popup-form__button d-flex justify-content-center">
							<button class="button popup-form__btn">
								Отправить заявку
							</button>
						</div>
						<div class="popup-form-desc">
							Нажимая на кнопку я соглашаюсь на передачу личных данных ФЗ РФ № 152 «О защите персональных данных»
						</div>
						<!-- /.popup-form__btn -->
					</form>
				</div>
				<!-- /.popup-form -->
			</div>
			<!-- /.popup -->
		</div>
		<!-- КОНЕЦ ВСПЛЫВАЮЩЕЙ ФОРМЫ -->
		<!-- НАЧАЛО ФОРМЫ НА ПАКЕТ -->
		<div class="send-request modal fade" id="ModalPackage" tabindex="-1" role="dialog" aria-labelledby="ModalPackageTitle" aria-hidden="true">
			<div class="popup modal-dialog m-0" role="document">
				<button type="button" class="popup-close close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
				<!-- <div class="popup-close close" data-dismiss="modal" aria-label="Close">&times;</div>-->
				<!-- /.popup-close -->

				<div class="popup-form">
					<div class="popup-form-header" id="ModalPackageTitle">
						<div class="popup-form-header__title">Заявка на пакет</div>
						<div class="popup-form-header__descr">Заполните анкету и наши специалисты свяжутся с вами</div>
					</div>
					<form action="" id="package_form" class="popup-form__form" method="POST">
						<div class="popup-form-box">
							<div class="Flying_Placeholder">
								<label>Имя *</label>
								<input class="popup-form-box__input" type="text" name="user-name_packForm" id="user-name_packForm">
							</div>
							<div class="Flying_Placeholder">
								<label>Адрес сайта *</label>
								<input class="popup-form-box__input" name="user-linksite_packForm" id="user-linksite_packForm"></input>
							</div>
							<div class="Flying_Placeholder">
								<label>E-mail *</label>
								<input class="popup-form-box__input" type="mail" name="user-mail_packForm" id="user-mail_packForm">
							</div>
							<div class="Flying_Placeholder">
								<label>Телефон</label>
								<input class="popup-form-box__input" type="tel" name="user-phone_packForm" id="user-phone_packForm">

								<select id="contact-way_packForm" name="contact-way_packForm" class="contact_way">
									<option class="Manager" value="manager">Звонок менеджера</option>
									<option class="WhatsApp" value="WhatsApp">WhatsApp</option>
									<option class="Viber" value="Viber">Viber</option>
									<option class="Telegram" value="Telegram">Telegram</option>
								</select>
							</div>
							<div class="Flying_Placeholder">
								<input type="text" class="js-range-slider" name="package" id="package" value="" />
							</div>
							<div id="price_packForm">
							</div>
							<div class="Flying_Placeholder" id="startPackWrap">
								<label>Дата начала пакета *</label>
								<input type="text" id="startPack" name="startPack" class="popup-form-box__input" value="" />
							</div>
						</div>
						<!-- /.popup-form-box -->

						<div class="popup-form__button d-flex justify-content-center">
							<button class="button popup-form__btn">
								Отправить заявку
							</button>
						</div>
						<div class="popup-form-desc">
							Нажимая на кнопку я соглашаюсь на передачу личных данных ФЗ РФ № 152 «О защите персональных данных»
						</div>
						<!-- /.popup-form__btn -->
					</form>
				</div>
				<!-- /.popup-form -->
			</div>
			<!-- /.popup -->
		</div>
		<!-- КОНЕЦ ФОРМЫ НА ПАКЕТ -->
		<!-- НАЧАЛО ВСПЛЫВАЮЩЕЙ ФОРМЫ Рассчитать стоимость-->
		<div class="send-request modal fade" id="calculateTheCostModal" tabindex="-1" role="dialog" aria-labelledby="ModalLongTitle" aria-hidden="true">
			<div class="popup modal-dialog m-0" role="document">
				<div class="popup-form">
					<div class="popup-form-header" id="ModalLongTitle">
						<div class="popup-form-header__title">Нужно рассчитать стоимость задачи?</div>
						<div class="popup-form-header__descr">Заполните, пожалуйста, форму. Чем больше будет информации о задаче, тем точнее мы сможем её оценить.
							Возможно, мы свяжемся с Вами для уточнения деталей. Ориентировочную стоимость запроса мы пришлём Вам на указанную почту в течение 1-2 дней.</div>
						<button type="button" class="popup-close close" data-dismiss="modal" aria-label="Close">
							<span aria-hidden="true">&times;</span>
						</button>
					</div>
					<div class="forOverflov">
						<div class="calculation-form">

							<form action="" id="calculation_form" class="calculation-form__form" method="post" enctype="multipart/form-data">
								<input type="hidden" name="my_file_upload" id="my_file_upload">
								<div class="row">
									<!-- левая колонка формы -->
									<div class="col-12 col-sm-12 col-md-6 col-lg-6">
										<div class="Flying_Placeholder">
											<label>Адрес Вашего сайта *</label>
											<input class="calculation-form__input" type="text" name="site-name" id="site-name">
										</div>
										<div class="Flying_Placeholder">
											<select name="bitrix" id="bitrix" class="S3_type_1 bitrix_edition">
												<option value="Старт">Старт</option>
												<option value="Стандарт">Стандарт</option>
												<option value="Малый бизнес">Малый бизнес</option>
												<option value="Бизнес">Бизнес</option>
												<option value="Энтерпрайз">Энтерпрайз</option>
											</select>
										</div>
										<div class="Flying_Placeholder">
											<label>Ваше имя*</label>
											<input class="calculation-form__input" type="text" name="user-name" id="user-name">
										</div>
										<div class="Flying_Placeholder">
											<label>Почта *</label>
											<input class="calculation-form__input" type="mail" name="user-mail" id="user-mail">
										</div>
										<div class="Flying_Placeholder">
											<label>Телефон</label>
											<input class="calculation-form__input" type="tel" name="user-phone" id="user-phone">
											<select id="calculation-form-contact_way" name="calculation-form-contact_way" class="contact_way">
												<option class="Manager" value="manager">Звонок менеджера</option>
												<option class="WhatsApp" value="WhatsApp">WhatsApp</option>
												<option class="Viber" value="Viber">Viber</option>
												<option class="Telegram" value="Telegram">Telegram</option>
											</select>
										</div>
										<!--div class="way_to_contact row no-gutters" >
											<div class="col-6">
												Как с Вами связаться?
											</div>
											<div class="col-6">
												<input type="radio" name="contact_way" class="contact_way_radio" id="wtc_manager" value="manager" checked>
												<label for="wtc_manager">Звонок менеджера</label>
												<br>
												<input type="radio" name="contact_way" class="contact_way_radio" value="WhatsApp" id="wtc_WhatsApp">
												<label for="wtc_WhatsApp">WhatsApp</label>
												<br>
												<input type="radio" name="contact_way" class="contact_way_radio" value="Viber" id="wtc_Viber">
												<label for="wtc_Viber">Viber</label>
												<br>
												<input type="radio" name="contact_way" class="contact_way_radio" value="Telegram" id="wtc_Telegram">
												<label for="wtc_Telegram">Telegram</label>
												<br>
											</div>
										</div-->
										<div class="calculation-form__checkbox d-inline-flex align-items-start">
											<div>
												<input type="checkbox" name="urgent-task" class="options" id="urgent-task">
											</div>
											<label for="urgent-task">У меня срочная задача</label>
											<div class="urgent-task-description non-urgent" for="urgent-task">Несрочная задача - 1800 руб/час. Реагируем на запрос в течение 2ч. Выполняем в плановом порядке.</div>
											<div class="urgent-task-description is-urgent" for="urgent-task">Срочная задача - 2700 руб/час. Реагируем за 15 мин. Выполняем немедленно</div>
										</div>
									</div>
									<!-- конец левая колонка формы -->

									<!-- правая колонка формы -->
									<div class="col-12 col-sm-12 col-md-6 col-lg-6">
										<div class="Flying_Placeholder">
											<label>Опишите Ваш вопрос/задачу/проблему *</label>
											<textarea class="calculation-form__input calculation-form__ta" name="site-problem"></textarea>
										</div>
										<div class="Flying_Placeholder">
											<label>Ссылки на проблемные страницы</label>
											<textarea class="calculation-form__input calculation-form__ta" name="site-problem-links"></textarea>
										</div>
										<div class="calculation-form__checkbox d-inline-flex align-items-center">
											<div>
												<input type="checkbox" name="user-device" class="options" id="user-device">
											</div>
											<label for="user-device">Я пишу с устройства, на котором обнаружилась проблема</label>
										</div>
										<label class="upload-descr">Добавьте файлы, в которых указана проблема</label>
										<div class="preloads">
											<!-- добавляется js при загрузке файлов -->
											<!--div class="p_item">
												<div class="p_text">
												</div>
												<div class="p_preview">
												<div class="p_close">×</div>
												</div>
											</div-->
										</div>
										<label class="upload-label d-inline-flex align-items-center" for="file-upload">
											<img src="img/calculation/paperclip.png" alt="">
											<span class="upload-button">Загрузить файл</span>
											<small class="upload-small">в формате: png/jpg/bmp; размер: до 5Мб.</small>
											<input class="calculation-form__input d-none" type="file" name="file-upload" id="file-upload" multiple accept="image/jpeg,image/png,image/bmp">
										</label>
										<div class="d-flex align-items-center justify-content-start">
											<button type="submit" class="button calculation-form__btn">
												Отправить заявку
											</button>
										</div>
										<div class="calculation-form__consent d-flex align-items-center justify-content-start">
											Нажимая на кнопку, я даю согласие на обработку персональных данных в соответствии с ФЗ №152 «О персональных данных»
										</div>
									</div>
									<!-- конец правая колонка формы -->
									<!-- низ формы -->
									<div class="col-12">
									</div>
									<!-- конец низ формы -->
								</div>
							</form>

						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- КОНЕЦ ВСПЛЫВАЮЩЕЙ ФОРМЫ Рассчитать стоимость-->

		<!-- НАЧАЛО ВСПЛЫВАЮЩЕЙ ФОРМЫ АУДИТ-->
		<div class="send-request modal fade" id="auditModal" tabindex="-1" role="dialog" aria-labelledby="ModalLongTitle" aria-hidden="true">
			<div class="popup modal-dialog m-0" role="document">
				<button type="button" class="popup-close close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
				<div class="popup-form">
					<div class="popup-form-header" id="ModalLongTitle">
						<div class="popup-form-header__title">Купи депозит и получи аудит сайта бесплатно*</div>
						<div class="audit_title">В рамках услуги выполняется анализ:</div>
						<div class="audit_list">
							<div>
								<ul>
									<li>целостности ядра;</li>
									<li>производительности;</li>
									<li>конфигурации сервера и ПО;</li>
									<li>файловой структуры;</li>
								</ul>
							</div>
							<div>
								<ul>
									<li>системы безопасности;</li>
									<li>верстки и HTML разметки страниц;</li>
									<li>скорости работы сайта;</li>
									<li>структур данных, шаблонов, компонентов;</li>
								</ul>
							</div>
						</div>
						<!-- <div class="popup-form-header__descr">
							*услуга "Аудит Сайта" оказывается бесплатно при покупке пакетного <b>тарифа "Бизнес"</b> до 31 октября 2019 года
						</div> -->
						<div class="popup-form-header__descr">
							<?php
							$audit_tariffs = array();
							foreach ($data->packages as $value)
								if ($value->free_audit === true)
									$audit_tariffs[] = $value->name;
							$str_audits = "";
							$aud_count = count($audit_tariffs);
							for ($i = 0; $i < $aud_count; ++$i) {
								$str_audits .= ($str_audits == "") ? "" : (($i == $aud_count - 1) ? " или " : ", ");
								$str_audits .= '"' . $audit_tariffs[$i] . '"';
							}
							?>
							*услуга "Аудит Сайта" оказывается бесплатно при покупке
							пакетного <b>тарифа <?= $str_audits ?></b> до 31 октября 2019 года
						</div>

					</div>
					<div class="clock-audit-wrapper">
						<div class="flipper" data-datetime="2019-11-01 23:59:59" data-template="dd|HH|ii|ss" data-labels="Дни|Часы|Минуты|Секунды" data-reverse="true" id="myFlipper_audit"></div>
					</div>
					<form action="" id="popup_form-audit" class="popup-form__form" method="POST">
						<div class="popup-form-box">
							<div class="Flying_Placeholder">
								<label>Имя *</label>
								<input class="popup-form-box__input" type="text" name="user-name_modal-audit" id="user-name_modal-audit">
							</div>
							<div class="Flying_Placeholder">
								<label>Телефон</label>
								<input class="popup-form-box__input" type="tel" name="user-phone_modal-audit" id="user-phone_modal-audit">
								<select id="popup-form-contact_way-audit" name="popup-form-contact_way-audit" class="contact_way">
									<option class="Manager" value="manager">Звонок менеджера</option>
									<option class="WhatsApp" value="WhatsApp">WhatsApp</option>
									<option class="Viber" value="Viber">Viber</option>
									<option class="Telegram" value="Telegram">Telegram</option>
								</select>
							</div>
							<div class="Flying_Placeholder">
								<select name="bitrix_audit" id="bitrix_audit" class="S3_type_1 bitrix_edition">
									<option value="Старт">Старт</option>
									<option value="Стандарт">Стандарт</option>
									<option value="Малый бизнес">Малый бизнес</option>
									<option value="Бизнес">Бизнес</option>
									<option value="Энтерпрайз">Энтерпрайз</option>
								</select>
							</div>
							<div class="Flying_Placeholder">
								<label>Адрес сайта *</label>
								<input class="popup-form-box__input" name="user-linksite_modal-audit" id="user-linksite_modal-audit"></input>
							</div>

						</div>
						<div class="popup-form__button d-flex justify-content-center">
							<button class="button popup-form__btn_audit">
								Отправить заявку
							</button>
						</div>
						<div class="popup-form-desc">
							Нажимая на кнопку я соглашаюсь на передачу личных данных ФЗ РФ № 152 «О защите персональных данных»
						</div>
					</form>
				</div>
			</div>
		</div>
		<!-- КОНЕЦ ВСПЛЫВАЮЩЕЙ ФОРМЫ АУДИТ-->

		<!-- НАЧАЛО ФОРМЫ СОТРУДНИЧЕСТВО -->
		<div class="send-request modal fade" id="ModalCollaboration" tabindex="-1" role="dialog" aria-labelledby="ModalCollaborationTitle" aria-hidden="true">
			<div class="popup modal-dialog m-0" role="document">
				<button type="button" class="popup-close close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>

				<div class="popup-form">
					<div class="popup-form-header" id="ModalCollaborationTitle">
						<div class="popup-form-header__title">Заявка на сотрудничество</div>
						<div class="popup-form-header__descr">Заполните анкету и мы отправим вам предложение на почту</div>
					</div>

					<form action="" id="collaboration_form" class="popup-form__form" method="POST">
						<div class="row">
							<!-- левая колонка формы -->
							<div class="col-12 col-sm-12 col-md-6 col-lg-6">
								<div class="Flying_Placeholder">
									<label>Ваше имя *</label>
									<input class="popup-form-box__input" type="text" name="user-name_collabForm" id="user-name_collabForm">
								</div>
								<div class="Flying_Placeholder">
									<label>Ваша должность *</label>
									<input class="popup-form-box__input" type="text" name="user-post_collabForm" id="user-name_collabForm">
								</div>
								<div class="Flying_Placeholder">
									<label>E-mail *</label>
									<input class="popup-form-box__input" type="mail" name="user-mail_collabForm" id="user-mail_collabForm">
								</div>
								<div class="Flying_Placeholder">
									<label>Телефон</label>
									<input class="popup-form-box__input" type="tel" name="user-phone_collabForm" id="user-phone_collabForm">

									<select id="contact-way_collabForm" name="contact-way_collabForm" class="contact_way">
										<option class="Manager" value="manager">Звонок менеджера</option>
										<option class="WhatsApp" value="WhatsApp">WhatsApp</option>
										<option class="Viber" value="Viber">Viber</option>
										<option class="Telegram" value="Telegram">Telegram</option>
									</select>
								</div>
								<div class="Flying_Placeholder">
									<label>Название компании *</label>
									<input class="popup-form-box__input" name="company-name_collabForm" id="company-name_collabForm"></input>
								</div>
								<div class="Flying_Placeholder">
									<label>Сайт *</label>
									<input class="popup-form-box__input" name="user-linksite_collabForm" id="user-linksite_collabForm"></input>
								</div>
								<div class="Flying_Placeholder">
									<label>Лет на рынке *</label>
									<input id="years_on_market" name="years_on_market" type="number" value="" min="0">
								</div>

							</div>
							<!-- конец левая колонка формы -->

							<!-- правая колонка формы -->
							<div class="col-12 col-sm-12 col-md-6 col-lg-6">
								<div class="Flying_Placeholder">
									<label>Штат *</label>
									<input id="staff" name="staff" type="number" value="" min="0">
								</div>
								<div class="Flying_Placeholder">
									<select name="activity" id="activity" class="S3_type_1">
										<option value="Веб-разработка">Веб-разработка</option>
										<option value="Реклама">Реклама</option>
										<option value="Продвижение">Продвижение</option>
										<option value="Интеграция">Интеграция</option>
										<option value="Консалтинг">Консалтинг</option>
									</select>
								</div>

								<div class="Flying_Placeholder">
									<select name="proj_types" id="proj_types" class="S3_type_1">
										<option value="Промо">Промо</option>
										<option value="Лэндинги/визитки">Лэндинги/визитки</option>
										<option value="Корп сайты">Корп сайты</option>
										<option value="Интернет-магазины">Интернет-магазины</option>
										<option value="Агрегаторы/инфопорталы">Агрегаторы/инфопорталы</option>
										<option value="Хайлоады">Хайлоады</option>
									</select>
								</div>
								<div class="modal_range_descr">
									Укажите общее количество выполненных проектов
								</div>
								<div class="Flying_Placeholder">
									<input type="text" class="js-range-slider" name="proj_num" id="proj_num" value="" />
								</div>
								<div class="calculation-form__checkbox d-inline-flex align-items-center">
									<div>
										<input type="checkbox" name="bitrix-only" class="options" id="bitrix-only">
									</div>
									<label for="bitrix-only">Работаем только с CMS 1С-Битрикс</label>
								</div>
								<div class="calculation-form__checkbox d-inline-flex align-items-center">
									<div>
										<input type="checkbox" name="bitrix-partner" class="options" id="bitrix-partner">
									</div>
									<label for="bitrix-partner">Партнеры 1С-Битрикс</label>
								</div>

								<div class="popup-form__button d-flex justify-content-center">
									<button class="button popup-form__btn">
										Отправить заявку
									</button>
								</div>
								<div class="popup-form-desc">
									Нажимая на кнопку я соглашаюсь на передачу личных данных ФЗ РФ № 152 «О защите персональных данных»
								</div>
								<!-- /.popup-form__btn -->
								<!-- конец правая колонка формы -->
							</div>
						</div>
					</form>
				</div>
				<!-- /.popup-form -->
			</div>
			<!-- /.popup -->
		</div>
		<!-- КОНЕЦ ФОРМЫ СОТРУДНИЧЕСТВО -->

		<!-- НАЧАЛО ВСПЛЫВАЮЩЕЙ ФОРМЫ ПЕРВЫЙ МЕСЯЦ ОБСЛУЖИВАНИЯ-->
		<div class="send-request modal fade" id="firstMonthModal" tabindex="-1" role="dialog" aria-labelledby="ModalLongTitle" aria-hidden="true">
			<div class="popup modal-dialog m-0" role="document">
				<button type="button" class="popup-close close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
				<div class="popup-form">
					<div class="popup-form-header" id="ModalLongTitle">
						<div class="popup-form-header__title">Закажи техподдержку на год и получи первый месяц бесплатно*</div>
						<div class="freeMonth_title">
							Предоставляется бесплатный тестовый период на 1 месяц, в течение которого у вас есть возможность потребовать возврат оплаты без объяснения причины.
						</div>
						<div class="popup-form-header__descr">*при оплате тех. поддержки на 12 месяцев, 1-ый месяц бесплатно.</div>

					</div>
					<form action="" id="popup_form-freeMonth" class="popup-form__form" method="POST">
						<div class="popup-form-box">
							<div class="Flying_Placeholder">
								<label>Имя *</label>
								<input class="popup-form-box__input" type="text" name="user-name_modal-freeMonth" id="user-name_modal-freeMonth">
							</div>
							<div class="Flying_Placeholder">
								<label>Телефон</label>
								<input class="popup-form-box__input" type="tel" name="user-phone_modal-freeMonth" id="user-phone_modal-freeMonth">
								<select id="popup-form-contact_way-freeMonth" name="popup-form-contact_way-freeMonth" class="contact_way">
									<option class="Manager" value="manager">Звонок менеджера</option>
									<option class="WhatsApp" value="WhatsApp">WhatsApp</option>
									<option class="Viber" value="Viber">Viber</option>
									<option class="Telegram" value="Telegram">Telegram</option>
								</select>
							</div>
							<div class="Flying_Placeholder">
								<select name="bitrix_freeMonth" id="bitrix_freeMonth" class="S3_type_1 bitrix_edition">
									<option value="Старт">Старт</option>
									<option value="Стандарт">Стандарт</option>
									<option value="Малый бизнес">Малый бизнес</option>
									<option value="Бизнес">Бизнес</option>
									<option value="Энтерпрайз">Энтерпрайз</option>
								</select>
							</div>
							<div class="Flying_Placeholder">
								<label>Адрес сайта *</label>
								<input class="popup-form-box__input" name="user-linksite_modal-freeMonth" id="user-linksite_modal-freeMonth"></input>
							</div>

						</div>
						<div class="popup-form__button d-flex justify-content-center">
							<button class="button popup-form__btn_freeMonth">
								Отправить заявку
							</button>
						</div>
						<div class="popup-form-desc">
							Нажимая на кнопку я соглашаюсь на передачу личных данных ФЗ РФ № 152 «О защите персональных данных»
						</div>
					</form>
				</div>
			</div>
		</div>
		<!-- КОНЕЦ ВСПЛЫВАЮЩЕЙ ФОРМЫ ПЕРВЫЙ МЕСЯЦ ОБСЛУЖИВАНИЯ-->

		<!-- НАЧАЛО ВСПЛЫВАЮЩЕЙ ФОРМЫ  ГАРАНТИЯ ВОЗВРАТА ОПЛАТЫ-->
		<div class="send-request modal fade" id="guaranteeModal" tabindex="-1" role="dialog" aria-labelledby="ModalLongTitle" aria-hidden="true">
			<div class="popup modal-dialog m-0" role="document">
				<button type="button" class="popup-close close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
				<div class="popup-form">
					<div class="popup-form-header" id="ModalLongTitle">
						<div class="popup-form-header__title">Гарантия возврата оплаты*</div>
						<div class="guarantee_title">Предоставляется бесплатный тестовый период на 1 месяц, в течение которого у вас есть возможность потребовать возврат оплаты без объяснения причины.</div>
						<div class="popup-form-header__descr">*гарантия возврата при оплате техподдержки на 12 месяцев.</div>
					</div>
					<form action="" id="popup_form-guarantee" class="popup-form__form" method="POST">
						<div class="popup-form-box">
							<div class="Flying_Placeholder">
								<label>Имя *</label>
								<input class="popup-form-box__input" type="text" name="user-name_modal-guarantee" id="user-name_modal-guarantee">
							</div>
							<div class="Flying_Placeholder">
								<label>Телефон</label>
								<input class="popup-form-box__input" type="tel" name="user-phone_modal-guarantee" id="user-phone_modal-guarantee">
								<select id="popup-form-contact_way-guarantee" name="popup-form-contact_way-guarantee" class="contact_way">
									<option class="Manager" value="manager">Звонок менеджера</option>
									<option class="WhatsApp" value="WhatsApp">WhatsApp</option>
									<option class="Viber" value="Viber">Viber</option>
									<option class="Telegram" value="Telegram">Telegram</option>
								</select>
							</div>
							<div class="Flying_Placeholder">
								<select name="bitrix_guarantee" id="bitrix_guarantee" class="S3_type_1 bitrix_edition">
									<option value="Старт">Старт</option>
									<option value="Стандарт">Стандарт</option>
									<option value="Малый бизнес">Малый бизнес</option>
									<option value="Бизнес">Бизнес</option>
									<option value="Энтерпрайз">Энтерпрайз</option>
								</select>
							</div>
							<div class="Flying_Placeholder">
								<label>Адрес сайта *</label>
								<input class="popup-form-box__input" name="user-linksite_modal-guarantee" id="user-linksite_modal-guarantee"></input>
							</div>

						</div>
						<div class="popup-form__button d-flex justify-content-center">
							<button class="button popup-form__btn_guarantee">
								Отправить заявку
							</button>
						</div>
						<div class="popup-form-desc">
							Нажимая на кнопку я соглашаюсь на передачу личных данных ФЗ РФ № 152 «О защите персональных данных»
						</div>
					</form>
				</div>
			</div>
		</div>
		<!-- КОНЕЦ ВСПЛЫВАЮЩЕЙ ФОРМЫ  ГАРАНТИЯ ВОЗВРАТА ОПЛАТЫ-->

		<!-- НАЧАЛО ФОРМЫ НЕ НАШЛИ УСЛУГУ -->
		<div class="send-request modal fade" id="ModalRequest" tabindex="-1" role="dialog" aria-labelledby="ModalRequestTitle" aria-hidden="true">
			<div class="popup modal-dialog m-0" role="document">
				<button type="button" class="popup-close close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
				<!-- <div class="popup-close close" data-dismiss="modal" aria-label="Close">&times;</div>-->
				<!-- /.popup-close -->

				<div class="popup-form">
					<div class="popup-form-header" id="ModalRequestTitle">
						<div class="popup-form-header__title">Связаться со мной</div>
						<div class="popup-form-header__descr">Заполните анкету и наши специалисты свяжутся с вами</div>
					</div>
					<form action="" id="request_form-form" class="request-form request_form-form" method="POST">
						<div class="request-form-box">
							<div class="Flying_Placeholder">
								<label>Имя *</label>
								<input class="popup-form-box__input" type="text" name="user-name_request-form" id="user-name_request-form">
							</div>
							<div class="Flying_Placeholder">
								<label>Телефон</label>
								<input class="popup-form-box__input" type="tel" name="user-phone_request-form" id="user-phone_request-form">
								<select id="request-form-contact_way" name="request-form-contact_way" class="contact_way">
									<option class="Manager" value="manager">Звонок менеджера</option>
									<option class="WhatsApp" value="WhatsApp">WhatsApp</option>
									<option class="Viber" value="Viber">Viber</option>
									<option class="Telegram" value="Telegram">Telegram</option>
								</select>
							</div>
							<div class="Flying_Placeholder">
								<label>E-mail *</label>
								<input class="popup-form-box__input" type="mail" name="user-mail_request-form" id="user-mail_request-form">
							</div>
							<?php /*
							<div class="Flying_Placeholder">
								<select name="bitrix_request-form" id="bitrix_request-form" class="S3_type_1 bitrix_edition">
									<option value="Старт">Старт</option>
									<option value="Стандарт">Стандарт</option>
									<option value="Малый бизнес">Малый бизнес</option>
									<option value="Бизнес">Бизнес</option>
									<option value="Энтерпрайз">Энтерпрайз</option>
									<option value="Я не знаю">Я не знаю</option>
								</select>
							</div>
							<div class="Flying_Placeholder">
								<label>Адрес сайта *</label>
								<input class="popup-form-box__input" name="user-linksite_request-form" id="user-linksite_request-form"></input>
							</div>
							*/ ?>
						</div>
						<div class="request-form__button d-flex justify-content-center">
							<button class="button request-form__btn">
								Отправить
							</button>
						</div>
						<div class="request-form-desc">
							Нажимая на кнопку вы соглашаетесь на передачу личных данных ФЗ РФ № 152 «О защите персональных данных»
						</div>
					</form>
				</div>
				<!-- /.popup-form -->
			</div>
			<!-- /.popup -->
		</div>
		<!-- КОНЕЦ НЕ НАШЛИ УСЛУГУ -->

		<!-- НАЧАЛО ВСПЛЫВАЮЩЕЕ ОКНО КАЛЬКУЛЯТОРА -->
		<div class="send-request modal fade" id="ModalCalculator" tabindex="-1" role="dialog" aria-labelledby="ModalCalculatorTitle" aria-hidden="true">
			<div class="popup modal-dialog m-0" role="document">
				<button type="button" class="popup-close close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
				<!-- <div class="popup-close close" data-dismiss="modal" aria-label="Close">&times;</div>-->
				<!-- /.popup-close -->
				<!-- Контент модального окна -->
				<div class="modalContent">

					<div class="calculator" id="calculator">
						<div class="CalcTitle">Оцените, сколько вам нужно часов*</div>
						<div class="subtitle"></div>
						<div class="CalcTable">
							<div class="CalcHeader">
								<div class="CalcRow">
									<div class="colService">Выбрать услугу</div>
									<div class="colAmount">Количество</div>
									<div class="colClose"></div>
								</div>
							</div>
							<div class="CalcBody">
								<template id="calculator_row">
									<div class="CalcRow">
										<div class="colService">
											<div class="action"></div>
											<div class="service">
												<select class="serviceList" tabindex="0"></select>
											</div>
										</div>
										<div class="colAmount"><input type="text" name="" id="" min="1" class="amount"></div>
										<div class="colClose">
											<div class="close"></div>
										</div>
									</div>
								</template>
							</div>
							<div class="CalcFooter">
								<div class="CalcRow">
									<div class="colService">
										<div class="action"></div>
										<div class="service">Добавить услугу</div>
									</div>
								</div>
							</div>
						</div>
						<div class="CalcFooter">
							<div class="result"></div>
							<div class="request">
								<div class="requestBtn">Оставить заявку</div>
								<div class="footnote">* оценка является приблизительной</div>
							</div>
						</div>

					</div>
					<!-- Конец контента модального окна -->
				</div>
				<!-- /.popup -->
			</div>
			<!-- КОНЕЦ ВСПЛЫВАЮЩЕЕ ОКНО КАЛЬКУЛЯТОРА -->
		</div>
		<!-- /.wrap -->


		<script src="js/jquery.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<script src="js/jquery.custominputmask.min.js"></script>
		<!--script src="https://cdn.jsdelivr.net/gh/S-a-n-d-r-0/select3@master/select3.min.js"></script-->
		<script src="js/select3.js"></script>

		<!-- костыль для корректного подключения jquery.mobile - его конфигурация перед подключением -->
		<!--script>$(document).on("mobileinit", function() {
		$.mobile.autoInitializePage = false;
		});</script>

		<script src="js/jquery.mobile-1.5.0-rc1.min.js"></script-->
		<script src="js/animateNumber.min.js"></script>
		<script src="js/detect.min.js"></script>
		<script src="js/flipper-responsive.js"></script>
		<script src="js/main.js"></script>
		<!--script src="js/select2.min.js"></script-->
		<script src="js/ion.rangeSlider.min.js"></script>
		<script src="js/zebra_datepicker.min.js"></script>
		<script src="js/jquery.nice-number.js"></script>
		<script src="js/calculator.js"></script>

</body>

</html>