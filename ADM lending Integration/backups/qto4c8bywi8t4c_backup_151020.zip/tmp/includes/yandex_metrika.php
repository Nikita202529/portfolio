<?php

if (!isset($data)) {
    echo 'error: $data variable is not defined';
    die();
}

if (empty($data->YM_ID)) {
    echo 'error: $data->YM_ID is empty';
    die();
}

?>
<!-- Yandex.Metrika counter -->
<script type="text/javascript">
    if (!data || !data.YM_ID) {
        throw new Error('data.YM_ID is empty');
    }

    (function(m, e, t, r, i, k, a) {
        m[i] = m[i] || function() {
            (m[i].a = m[i].a || []).push(arguments)
        };
        m[i].l = 1 * new Date();
        k = e.createElement(t), a = e.getElementsByTagName(t)[0], k.async = 1, k.src = r, a.parentNode.insertBefore(k, a)
    })
    (window, document, "script", "https://mc.yandex.ru/metrika/tag.js", "ym");

    ym(data.YM_ID, "init", {
        clickmap: true,
        trackLinks: true,
        accurateTrackBounce: true,
        webvisor: true
    });
</script>
<noscript>
    <div><img src="https://mc.yandex.ru/watch/<?= $data->YM_ID ?>" style="position:absolute; left:-9999px;" alt="" /></div>
</noscript>
<!-- /Yandex.Metrika counter -->