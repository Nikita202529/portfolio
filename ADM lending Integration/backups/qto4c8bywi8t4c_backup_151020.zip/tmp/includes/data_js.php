<script>
	const data = JSON.parse("<?= addslashes(json_encode($data)) ?>");
</script>