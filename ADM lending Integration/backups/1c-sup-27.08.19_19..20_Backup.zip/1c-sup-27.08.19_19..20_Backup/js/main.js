//-----------------------------------------------------------------------
//             Точное сравнение объектов js
//-----------------------------------------------------------------------

//Используется при загрузке файлов, чтобы пользователь не смог загрузить один файл дважды. 
//При попытке загрузки загруженный файл сравнивается с предыдущими. Если он уже есть, в 
//его загрузке отказывается

function deepCompare () {
  var i, l, leftChain, rightChain;

  function compare2Objects (x, y) {
    var p;

    // remember that NaN === NaN returns false
    // and isNaN(undefined) returns true
    if (isNaN(x) && isNaN(y) && typeof x === 'number' && typeof y === 'number') {
         return true;
    }

    // Compare primitives and functions.     
    // Check if both arguments link to the same object.
    // Especially useful on the step where we compare prototypes
    if (x === y) {
        return true;
    }

    // Works in case when functions are created in constructor.
    // Comparing dates is a common scenario. Another built-ins?
    // We can even handle functions passed across iframes
    if ((typeof x === 'function' && typeof y === 'function') ||
       (x instanceof Date && y instanceof Date) ||
       (x instanceof RegExp && y instanceof RegExp) ||
       (x instanceof String && y instanceof String) ||
       (x instanceof Number && y instanceof Number)) {
        return x.toString() === y.toString();
    }

    // At last checking prototypes as good as we can
    if (!(x instanceof Object && y instanceof Object)) {
        return false;
    }

    if (x.isPrototypeOf(y) || y.isPrototypeOf(x)) {
        return false;
    }

    if (x.constructor !== y.constructor) {
        return false;
    }

    if (x.prototype !== y.prototype) {
        return false;
    }

    // Check for infinitive linking loops
    if (leftChain.indexOf(x) > -1 || rightChain.indexOf(y) > -1) {
         return false;
    }

    // Quick checking of one object being a subset of another.
    // todo: cache the structure of arguments[0] for performance
    for (p in y) {
        if (y.hasOwnProperty(p) !== x.hasOwnProperty(p)) {
            return false;
        }
        else if (typeof y[p] !== typeof x[p]) {
            return false;
        }
    }

    for (p in x) {
        if (y.hasOwnProperty(p) !== x.hasOwnProperty(p)) {
            return false;
        }
        else if (typeof y[p] !== typeof x[p]) {
            return false;
        }

        switch (typeof (x[p])) {
            case 'object':
            case 'function':

                leftChain.push(x);
                rightChain.push(y);

                if (!compare2Objects (x[p], y[p])) {
                    return false;
                }

                leftChain.pop();
                rightChain.pop();
                break;

            default:
                if (x[p] !== y[p]) {
                    return false;
                }
                break;
        }
    }

    return true;
  }

  if (arguments.length < 1) {
    return true; //Die silently? Don't know how to handle such case, please help...
    // throw "Need two or more arguments to compare";
  }

  for (i = 1, l = arguments.length; i < l; i++) {

      leftChain = []; //Todo: this can be cached
      rightChain = [];

      if (!compare2Objects(arguments[0], arguments[i])) {
          return false;
      }
  }

  return true;
}

Array.prototype.unique = function() {
    var a = this.concat();
    for(var i=0; i<a.length; ++i) {
        for(var j=i+1; j<a.length; ++j) {
            if(deepCompare(a[i],a[j])) //было if(a[i] === a[j])
                a.splice(j--, 1);
        }
    }

    return a;
};

//-----------------------------------------------------------------------
//             Вывод всплывающих сообщений
//-----------------------------------------------------------------------

//Замена alert'у
//функция ShowMyMessage
var MyQueue = [];
//alert_message - сообщение, можно html
//bs_type - тип alert'а в bootstrap'е, влияет только на цвет, bstype = primary, secondary, success, danger, warning, info, light, dark
function ShowMyMessage(alert_message, bs_type)
{
	if (!bs_type) bs_type = 'light';
	function ShowMessageRightNow(message, bstype)
	{
		//генерация случайного id
		let id =  String.fromCharCode.apply(null, Date.now().toString().split('').map(function(i){ return parseInt(i) + 65;}));
		let MyDiv1 = $('<div/>', { 'id': id, 'class': 'modal fade MyAlertsClass', 'role': 'dialog', 'aria-hidden':'true' });
		let MyDiv2 = $('<div/>', { 'class': 'modal-dialog' });
		let MyDiv3 = $('<div/>', { 'class': 'alert alert-' + bstype });
		MyDiv3.append(message);
		MyDiv2.append(MyDiv3);
		MyDiv1.append(MyDiv2);

		$('body').append(MyDiv1);
		$('#' + id).modal('show');
		$('#' + id).on('hidden.bs.modal', function (e) {
			$('#' + id).remove();
			NextMassage();
		});
	}
	
	MyQueue.push([alert_message, bs_type]);
	if (MyQueue.length == 1)
		NextMassage();
		
	function NextMassage()
	{
		if ($('.MyAlertsClass').length == 0)
			setTimeout( function() {
			if (MyQueue.length != 0)
				{
					ShowMessageRightNow(MyQueue[0][0], MyQueue[0][1]);
					MyQueue.shift()
				}
			}, 500);
	}
}

//-----------------------------------------------------------------------
//             Маски на телефонные номера
//-----------------------------------------------------------------------

//Маски на телефонные номера
jQuery(function($){
  $("#user-phone").mask("+7 (999) 999-99-99", {autoclear: false});
  $("#user-phone_modal").mask("+7 (999) 999-99-99", {autoclear: false});
});

//-----------------------------------------------------------------------
//             Плавная прокрутка
//-----------------------------------------------------------------------

// Плавная прокрутка
// Элемент, после нажатия на который прокручивается должен иметь класс "btn-scroll", а в href должна быть ссылка на якорь
// Пример:
// 		<a class="button btn-scroll" href="#calculation">Оставить заявку</a>
$(document).ready(function (){

function scrollPage(selector)
{
	$(selector).click(function()
	{
		var page = $("html, body");
		page.on("scroll mousedown wheel DOMMouseScroll mousewheel keyup touchmove", function(){
		   page.stop();
		});

		page.animate(
		{   scrollTop: $($(this).attr("href")).offset().top - 30 },
		   1500,
		   function(){
		   page.off("scroll mousedown wheel DOMMouseScroll mousewheel keyup touchmove");
		});

		return false; 
	});

}

  scrollPage('.btn-scroll');
  
});


//-----------------------------------------------------------------------
//             Меню
//-----------------------------------------------------------------------


$(document).ready( function () {
  'use strict';
  
  // start main menu
    var hamburger = document.querySelector('.hamburger'),
        menu = document.querySelector('.menu'),
        scrollcontent = document.querySelector('.scrollcontent'),
        menuArrowBack = document.querySelector('.menu-top_arrow'),
        menuItem = document.querySelectorAll('.menu-item'),
        menuLink = document.querySelectorAll('.menu-link'),
        body = document.querySelector('body'),
        headerLogo = document.querySelector('.header-logo');

    // show main menu
    function showMenu() {

		menu.classList.add('menu-active');
		scrollcontent.classList.add('scrollcontent_active');

		$( '.hamburger' ).css('opacity', '0' );

		/*
		if (menu.clientWidth == document.body.clientWidth)
		{
			document.body.classList.add( 'frozen' );
			document.getElementsByTagName( 'html' )[0].classList.add('frozen');
		}
		*/
    }

    // hide main menu
    function hideMenu() {
		menu.classList.remove('menu-active');
		scrollcontent.classList.remove('scrollcontent_active');

		$( '.hamburger' ).css('opacity', '1' );
		/*
		if (document.body.classList.contains( 'frozen' ))
			document.body.classList.remove( 'frozen' );
		if (document.getElementsByTagName( 'html' )[0].classList.contains( 'frozen' ))
			document.getElementsByTagName( 'html' )[0].classList.remove( 'frozen' );
		*/
    }

    //Event when you click on a hamburger and then the menu appears
    hamburger.addEventListener('click', function(e) {
        e.stopPropagation();
		
		let menu_is_active = $(menu).hasClass( 'menu-active' );
		if (menu_is_active)
			hideMenu();
		else
			showMenu();
    });

    // Event when you click outside menu - menu hide
    document.addEventListener('click', function( e ) {
      let target = e.target;
      let its_menu = target == menu || menu.contains(target);
	  
	  //e.stopPropagation();
      let its_hamburger = target == hamburger;
      let menu_is_active = menu.classList.contains('menu-active');

      
      if (!its_menu && !its_hamburger && menu_is_active) {
        hideMenu(); 
      }  
    });


    // Event when you click on the arrow main menu and then the menu is hidden
    menuArrowBack.addEventListener('click', function( e ) {
		e.stopPropagation();
		hideMenu();
    });
	
	
	//свайп по окну
	/*
	$( window ).on( "swipeleft", function( e ) { 
		e.stopPropagation();
		hideMenu();
	} );
	
	$( window ).on( "swiperight", function( e ) { 
		e.stopPropagation();
		showMenu();
	} );
	*/
	
  // end main menu
});

//-----------------------------------------------------------------------
//             Показать все сервисы/Скрыть все сервисы
//-----------------------------------------------------------------------

$(document).ready( function () {
//show some blocks when you click on a link
  let serviceItem = document.querySelectorAll('.service-item'),
      serviceLinks = document.querySelector('.service-links'),
      serviceLink = document.querySelectorAll('.service-link');

  function showserviceItem() {
    for (let i = 0; i < serviceItem.length; i++) {
      serviceItem[i].style.display = '';
    }
  }

  function hideserviceItem() {
    for (let i = 0; i < serviceItem.length; i++) {
      if (i > 5) {
        serviceItem[i].style.display = 'none';
      } else {
        serviceItem[i].style.display = '';
      }
    }
  }
  //Все сервисы показываются только на широком экране:
  function serviceBlock() {
    //if ($(window).width() < 992) {
    if (window.innerWidth < 992) {
      hideserviceItem();
      //serviceLink[0].style.display = 'inline-block';
    } else {
      showserviceItem();
      // serviceLink[1].style.display = 'none';
    }
  }

  //Показать все сервисы/Скрыть все сервисы
  serviceLinks.addEventListener('click', function(e) {
    let target = e.target;
    if (target && target.classList.contains('service-link__show')) {
      showserviceItem();
      serviceLink[0].style.display = 'none';
      serviceLink[1].style.display = 'inline-block';
    } 
  });  
  serviceLinks.addEventListener('click', function(e) {
    let target = e.target;
    if (target && target.classList.contains('service-link__hide')) {
      hideserviceItem();
      serviceLink[0].style.display = 'inline-block';
      serviceLink[1].style.display = 'none';
    }
  });

  serviceBlock();

});


//-----------------------------------------------------------------------
//             AJAX-отправка форм
//-----------------------------------------------------------------------

$(document).ready(function ()
{
	
//-------------AJAX-отправка форм
	//-----------------------------------------------------------------------
	//             Загрузка файлов
	//-----------------------------------------------------------------------

	//Загруженные файлы
	var files = [];
	
	$('input[type="file"]').change( function()
	{
		//files = this.files;//старая версия
		
		//новая версия - важно
		for (let i = 0; i < this.files.length; i++)
			files.push( this.files[i]);
		
		files = files.unique();//не стандартная функция. Прописана в начале файла. Удаляет все совпадения в массиве
		
		$('#my_file_upload').val("123");//важно
		
		refresh_all_preloads_html();
	});

//-------------AJAX-отправка форм
	//-----------------------------------------------------------------------
	//             Обновление превьюшек загрузок
	//-----------------------------------------------------------------------


	/* //Чистый пример:
	$('input[type="file"]').change(function(e){
				var fileName = e.target.files[0].name;
				alert('The file "' + fileName +  '" has been selected.');
			});
	*/
	//https://stackoverflow.com/questions/4459379/preview-an-image-before-it-is-uploaded
	//http://qaru.site/questions/24784/javascript-image-resize

	function refresh_all_preloads_html()
	{
		//если файлов нет, убираем отступы по y 
		if (files.length == 0)
			$('.preloads').addClass('my0_py0');
		else
			$('.preloads').removeClass('my0_py0');
		
		$('.preloads').empty();
		for (let i = 0; i < files.length; i++)
			{
				let p_text = $('<div/>', { /* id: 'some-id', */ "class": 'p_text' });
				let p_close = $('<div/>', { /* id: 'some-id', */ "class": 'p_close', "ind": i }); //ind передается для удаления - p_close.click
				let p_preview = $('<div/>', { /* id: 'some-id', */ "class": 'p_preview' });
				let p_item = $('<div/>', { /* id: 'some-id', */ "class": 'p_item' });
				
				p_text.append(files[i].name);

				let reader = new FileReader();
				reader.onload = function(e) {
				  $(p_preview).css('background-image', "url(" + e.target.result + ")");
				}
				reader.readAsDataURL(files[i]);
				
				p_close.append('×');
				p_close.click( function(e){
					files.splice(e.target.getAttribute("ind"), 1);
					refresh_all_preloads_html();
				});
				
				p_item.append(p_text);
				p_item.append(p_preview);
				p_item.append(p_close);
				$('.preloads').append(p_item);
			}
	}
	
	refresh_all_preloads_html();
	
//-------------AJAX-отправка форм
	//-----------------------------------------------------------------------
	//             Валидация форм
	//-----------------------------------------------------------------------
	
	//Добавит/снимет визуальное оформление ошибки с текстом о том, что поле обязательное. return true/false - прошло ли валидацию. ChangeVisual - true/false =false не меняет внешний вид поля
	function ValidateRequiredField(fieldQuerySelector, ChangeVisual)
	{
		let result = true;
		
		let field = $(fieldQuerySelector)[0];
		
		if (ChangeVisual == true)
		{
			$(field).removeClass('error');						//очищаем старое оформление ошибок
			$(field).parent().find( '.myTooltip' ).remove();	//очищаем старые сообщения ошибок
		}
		
		if (!$(field).val() || $(field).val().length == 0)
		{
			result = false;
			
			if (ChangeVisual == true)
			{
				$(field).addClass( 'error' );
				
				let errText = '* Это обязательное поле';
				let tooltip = $( '<div/>', { "class": 'myTooltip' });
				tooltip.append(errText);
				$(field).parent().append(tooltip); //добавляем элемент к обертке. Сработает только если есть обертка
			}
		}
		
		return result;
	}
	
	//Добавит/снимет визуальное оформление ошибки с текстом о том, что email заполнен неверно. return true/false - прошло ли валидацию. ChangeVisual - true/false. =false не меняет внешний вид поля
	function ValidateEmail(fieldQuerySelector, ChangeVisual)
	{
		let result = true;
		
		let field = $(fieldQuerySelector)[0];
		
		if (ChangeVisual == true)
		{
			$(field).removeClass('error');						//очищаем старое оформление ошибок
			$(field).parent().find( '.myTooltip' ).remove();	//очищаем старые сообщения ошибок
		}
		
		var mailRegExp = new RegExp("[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?");
		if (!mailRegExp.test($(field).val()))
		{
			result = false;
			
			if (ChangeVisual == true)
			{
				$(field).addClass( 'error' );
				
				let errText = 'Некорректный e-mail';
				let tooltip = $( '<div/>', { "class": 'myTooltip' });
				tooltip.append(errText);
				$(field).parent().append(tooltip); //добавляем элемент к обертке. Сработает только если есть обертка
			}
		}
		
		return result;
	}
	
	//ChangeVisual - true/false. =false не меняет внешний вид поля
	function ValidatePhone(fieldQuerySelector, ChangeVisual)
	{
		let result = true;
		
		let field = $(fieldQuerySelector)[0];
		
		if (ChangeVisual == true)
		{
			$(field).removeClass('error');						//очищаем старое оформление ошибок
			$(field).parent().find( '.myTooltip' ).remove();	//очищаем старые сообщения ошибок
		}
		
		var phoneRegExp = new RegExp(/^((\+7|7|8)+(([0-9,\s,\-,\(,\)]){10,16}))$/igm);//писал сам
		if (!phoneRegExp.test($(field).val()))
		{
			result = false;
			
			if (ChangeVisual == true)
			{
				$(field).addClass( 'error' );
				
				let errText = 'Телефон заполнен неверно';
				let tooltip = $( '<div/>', { "class": 'myTooltip' });
				tooltip.append(errText);
				$(field).parent().append(tooltip); //добавляем элемент к обертке. Сработает только если есть обертка
			}
		}
		
		return result;
	}
	
	function Validate(formId)
	{
		if (formId == 'calculation_form')
		{
			let result = true;
			
			//если нет - result = false;
			
			result = ValidateRequiredField("#" + formId + " " + "[name='site-problem']", true) && result;		
			result = ValidateRequiredField("#" + formId + " " + "[name='user-name']", true) && result;			
			result = ValidateRequiredField("#" + formId + " " + "[name='site-name']", true) && result;			
			result = ValidateRequiredField("#" + formId + " " + "[name='bitrix']", true) && result;	
			result = (ValidateRequiredField("#" + formId + " " + "[name='user-mail']", true)) ? 
						ValidateEmail("#" + formId + " " + "[name='user-mail']", true) && result : 
						false;
			result = (ValidateRequiredField("#" + formId + " " + "[name='user-phone']", false)) ?
						ValidatePhone("#" + formId + " " + "[name='user-phone']", true) && result :
						result;

			return result;
		}
		else if (formId == 'popup_form')
		{
			let result = true;
			
			//если нет - result = false;
			
			result = ValidateRequiredField("#" + formId + " " + "[name='user-name_modal']", true) && result;
			result = ValidateRequiredField("#" + formId + " " + "[name='user-linksite_modal']", true) && result;
			result = (ValidateRequiredField("#" + formId + " " + "[name='user-mail_modal']", true)) ? 
						ValidateEmail("#" + formId + " " + "[name='user-mail_modal']", true) && result : 
						false;
			result = (ValidateRequiredField("#" + formId + " " + "[name='user-phone']", false)) ?
						ValidatePhone("#" + formId + " " + "[name='user-phone']", true) && result :
						result;
			
			return result;
		}
		
		return false;
	}

//-------------AJAX-отправка форм
	//-----------------------------------------------------------------------
	//             Форма снизу, событие SUBMIT
	//-----------------------------------------------------------------------	

	$('.calculation-form__form').submit(function(event) {
		event.stopPropagation(); // Прекращаем дальнейшую передачу текущего события.
		event.preventDefault(); // Запрещаем стандартное поведение для кнопки submit
		
		//Валидация
		if (!Validate('calculation_form'))
			return;
		
		var button = $(this).find('.calculation-form__btn');
		let formTargetId = $(this).attr("id");

		var formserialize = new FormData(this);
		
		var data = new FormData();
		
		$.each(files, function(key, value){
			data.append('files'+key, value);
		});
		
		data.append('formId', formTargetId);
		
		data.append('my_file_upload', formserialize.get("my_file_upload"));

		data.append('name', formserialize.get("user-name"));
		data.append('phone', formserialize.get("user-phone"));
		data.append('site', formserialize.get("site-name"));
		data.append('bitrix', $("#bitrix").val());
		data.append('problem', formserialize.get("site-problem"));
		data.append('links', formserialize.get("site-problem-links"));
		data.append('device', formserialize.get("user-device"));
		data.append('mail', formserialize.get("user-mail"));
		if (formserialize.get("user-device"))
		{
			var user = detect.parse(navigator.userAgent);
			var main_info = 'Браузер пользователя: ' + user.browser.family + ' ' + user.browser.version + '; ОС пользователя: ' + user.os.name + ' .';
			
			var _navigator = {};
			_navigator['main_info'] = main_info;
			for (var i in navigator) _navigator[i] = navigator[i];
			
			// --- для IE
			delete _navigator.plugins;
			delete _navigator.mimeTypes;
			// --- конец --- для IE
			
			data.append('device_details', JSON.stringify(_navigator));
		}
		
		if (formserialize.get("user-phone"))
			data.append('way_to_contact', formserialize.get("contact_way"));

		$(button).html('Форма отправлена');
		$(button).prop('disabled',true);
		
		$.ajax({
			type: "POST",
			url: "/ajax/rest.php",
			data: data,
			cache: false,
			processData: false, // NEEDED, DON'T OMIT THIS
			contentType: false, // NEEDED, DON'T OMIT THIS (requires jQuery 1.6+)
			dataType: 'json',
			success: function(respond){
				//Два случая: успех и ошибка валидации на сервере				
				//Успех
				if (respond.success == 'true') //В respond.success ключ success называется так, потому что так его отправил php-обработчик. С respond.error_type и respond.error_message аналогично
				{
					console.log(JSON.stringify(respond));
					ShowMyMessage("Спасибо за заявку! В ближайшее время наш менеджер свяжется с Вами для уточнения деталей.", '');
				}
				//Ошибка
				else if (respond.success == 'false')
				{
					console.log(JSON.stringify(respond));
					if (respond.error_type == 'external_error')
						ShowMyMessage(respond.error_message, 'danger');
				}
				else
					console.log('Не удалось распознать ответ сервера: \n' + JSON.stringify(respond));
			}
			
			,error: function(xhr, status, error)
			{
				$(button).html('Отправить заявку');
				$(button).prop('disabled',false);
				ShowMyMessage('Не удалось отправить заявку. Попробуйте еще раз через некоторое время или свяжитесь с нами по контактному номеру', 'danger');
				
				console.log('ajaxError xhr:', xhr); // выводим значения переменных
				console.log('ajaxError status:', status);
				console.log('ajaxError error:', error);

				// соберем самое интересное в переменную
				var errorInfo = 'Ошибка выполнения запроса: '
						+ '\n[' + xhr.status + ' ' + status   + ']'
						+  ' ' + error + ' \n '
						+ xhr.responseText
						+ '<br>'
						+ xhr.responseJSON;

				console.log('ajaxError:', errorInfo); // в консоль
				//alert(errorInfo); // если требуется, то и на экран
			}
		});
	});

//-------------AJAX-отправка форм
	//-----------------------------------------------------------------------
	//             js-всплывающая форма, событие SUBMIT
	//-----------------------------------------------------------------------

	$('.popup-form__form').submit(function(event) {
		event.stopPropagation();
		event.preventDefault();
		
		//Валидация
		if (!Validate('popup_form'))
			return;
		
		$('#ModalLong').modal('hide');
		
		var button = $(this).find('.popup-form__btn');
		let formTargetId = $(this).attr("id");
	
		var formserialize = new FormData(this);
		
		var data = new FormData();
		
		data.append('formId', formTargetId);
		
		data.append('name', formserialize.get("user-name_modal"));
		data.append('site', formserialize.get("user-linksite_modal"));
		data.append('phone', formserialize.get("user-phone_modal"));
		data.append('mail', formserialize.get("user-mail_modal"));
		
		$(button).html('Форма отправлена');
		$(button).prop('disabled',true);
		
		$.ajax({
			type: "POST",
			url: "/ajax/rest.php",
			data: data,
			cache: false,
			processData: false, // NEEDED, DON'T OMIT THIS
			contentType: false, // NEEDED, DON'T OMIT THIS (requires jQuery 1.6+)
			dataType: 'json',
			success: function(respond){
				//Два случая: успех и ошибка валидации на сервере				
				//Успех
				if (respond.success == 'true') //В respond.success ключ success называется так, потому что так его отправил php-обработчик. С respond.error_type и respond.error_message аналогично
				{
					console.log(JSON.stringify(respond));
					ShowMyMessage("Спасибо за заявку! В ближайшее время наш менеджер свяжется с Вами для уточнения деталей.", '');
				}
				//Ошибка
				else if (respond.success == 'false')
				{
					console.log(JSON.stringify(respond));
					if (respond.error_type == 'external_error')
						ShowMyMessage(respond.error_message, 'danger');
				}
				else
					console.log('Не удалось распознать ответ сервера: \n' + JSON.stringify(respond));
			}
			
			,error: function(xhr, status, error)
			{
				$(button).html('Отправить заявку');
				$(button).prop('disabled',false);
				ShowMyMessage('Не удалось отправить заявку. Попробуйте еще раз через некоторое время или свяжитесь с нами по контактному номеру', 'danger');
				
				console.log('ajaxError xhr:', xhr); // выводим значения переменных
				console.log('ajaxError status:', status);
				console.log('ajaxError error:', error);

				// соберем самое интересное в переменную
				var errorInfo = 'Ошибка выполнения запроса: '
						+ '\n[' + xhr.status + ' ' + status   + ']'
						+  ' ' + error + ' \n '
						+ xhr.responseText
						+ '<br>'
						+ xhr.responseJSON;

				console.log('ajaxError:', errorInfo); // в консоль
				//alert(errorInfo); // если требуется и то на экран
			}
		});
	});
});	

//-----------------------------------------------------------------------
//             Кастомный список
//-----------------------------------------------------------------------
//https://select2.org/
$( document ).ready(function (){
	$('select').select2(); //подключение
	
	//насройки
	$('select').select2({
		//...
		"language": {
		   "noResults": function(){
			   return "Нет подходящих результатов";
		   }
		},
		escapeMarkup: function (markup) {
			return markup;
		},
	});
	
	/*
	//тесты
	$('select').change(function() {
	alert($("select").val()); 
	if ($("select").val()[1])
		alert($("select").val()[1]); 
	});
	*/
	
});

//-----------------------------------------------------------------------
//             Летающие подсказки-placeholder'ы
//-----------------------------------------------------------------------

//летающая подсказка-placeholder
//Flying_Placeholder - класс обертки для label, в котором текст placeholder'а и input'а или textarea

$( document ).ready(function (){
	let wraps = $('.Flying_Placeholder');
	for (let i = 0; i < wraps.length; i++)
	{
		let flying_label = $(wraps[i]).find("label");
		let inp = $(wraps[i]).find("input, textarea, select");
		$(flying_label).click(function() {
			for (let k = 0; k < inp.length; k++)
			{
				inp[k].focus();
				if ($(inp[k]).hasClass("select2-hidden-accessible")) //s2
					$(inp[k]).select2('open'); //s2
			}
		});
		
		let s2 = $(wraps[i]).find(".select2"); //s2
		$(s2).click(function() { //s2
			for (let k = 0; k < inp.length; k++) //s2
			{ //s2
				inp[k].focus(); //s2
				if ($(inp[k]).hasClass("select2-hidden-accessible")) //s2
					$(inp[k]).select2('open'); //s2
			} //s2
		}); //s2
		
		for (let k = 0; k < inp.length; k++)
		{
			$(inp[k]).on ( "focus" , function() {
				//input/textarea событие focus - фокус элемента
				flying_label.addClass("focus");
			});
			$(inp[k]).on( "blur" , function() {
				//input/textarea событие blur - фокус снят
				if (!$(inp[k]).val() || $(inp[k]).val().length == 0) {
					if (!$(inp[k]).hasClass("select2-search__field"))  //s2
						flying_label.removeClass("focus");
				}	
			});
			
			$(inp[k]).on( "change, select2:close" , function() {  //s2
				if (!$(inp[k]).val() || $(inp[k]).val().length == 0)  //s2
					flying_label.removeClass("focus");  //s2
			});  //s2
			
			//при загрузке
			if ($(inp[k]).val() && $(inp[k]).val().length != 0) //если поле заполнено
				flying_label.addClass("focus");
		}
	}
});

$( document ).ready(function (){
	//calculation-form
	let user_phone = $('.calculation-form #user-phone')[0];
	let wtc_wrap = $('.calculation-form .way_to_contact')[0];
	$(user_phone).on( "focus" , function() {
			$(wtc_wrap).addClass("focus");
	});
	$(user_phone).on( "blur" , function() {
		if (!$(user_phone).val() || $(user_phone).val().length == 0)
			$(wtc_wrap).removeClass("focus");
	});
	if ($(user_phone).val() && $(user_phone).val().length != 0)
		$(wtc_wrap).addClass("focus");
});

//-----------------------------------------------------------------------
//             Виджет bitrix24
//-----------------------------------------------------------------------


$( document ).ready(function (){
	function toggleWidjet(){
		if(!$('.bx-livechat-wrapper').hasClass('bx-livechat-show') && !$('.b24-widget-button-social').hasClass('b24_hover')){
			$('.b24-widget-button-social').toggleClass('b24_adm');
		}	
	}
	function toggleChat(){
		if($('.bx-livechat-wrapper').hasClass('bx-livechat-show')){
			$('.b24-widget-button-social-item.b24-widget-button-openline_livechat').addClass('b24-adm-unbind');
		}
		$('.bx-livechat-control-box').click(function() {
			$('.b24-widget-button-social-item.b24-widget-button-openline_livechat').removeClass('b24-adm-unbind');
		});
	}
	/*setInterval(function() {
		 toggleWidjet()
	}, 30000);*/
	setTimeout( function (){
		toggleWidjet(); //первый запуск спустя 3 секунды
	}, 3000);
	$(".b24-widget-button-social").mouseover(function() {
	  $(this).addClass('b24_hover');
	});
	$(".b24-widget-button-social").mouseout(function() {
	  $(this).removeClass('b24_hover');
	});
	$(document).mouseup(function (e){
		var div = $(".bx-livechat-wrapper");
		if (!div.is(e.target) && div.has(e.target).length === 0 && $('.bx-livechat-wrapper').hasClass('bx-livechat-show')) {
			$('.b24-widget-button-inner-mask').trigger('click');
			$('.b24-widget-button-social-item.b24-widget-button-openline_livechat').removeClass('b24-adm-unbind');
		}
	})
	$('.b24-widget-button-social-item.b24-widget-button-openline_livechat').click(function() {
		toggleChat();
	});
	/*let qs = '.b24-widget-button-inner-item';
	$( qs ).hover(function (){
		$( '.b24-widget-button-pulse-animate' ).removeClass( 'b24-widget-button-pulse-animate_1anim' );
		$( '.b24-widget-button-pulse-animate' ).addClass( 'b24-widget-button-pulse-animate_noAnim' );
		setTimeout( function (){$( '.b24-widget-button-pulse-animate' ).addClass( 'b24-widget-button-pulse-animate_1anim' );}, 200);
		setTimeout( function (){$( '.b24-widget-button-pulse-animate' ).removeClass( 'b24-widget-button-pulse-animate_noAnim' );}, 200);
	});*/
});