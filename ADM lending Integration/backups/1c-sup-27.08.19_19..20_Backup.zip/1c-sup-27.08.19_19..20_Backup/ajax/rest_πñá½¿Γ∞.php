<?

// CRM server conection data
define('CRM_HOST', 'admcenter.bitrix24.ru'); // your CRM domain name
define('CRM_PORT', '443'); // CRM server port
define('CRM_PATH', '/crm/configs/import/lead.php'); // CRM server REST service path

// CRM server authorization data
define('CRM_LOGIN', 'lid@adm-center.ru'); // login of a CRM user able to manage leads
define('CRM_PASSWORD', 'Lidadmcenter.001'); // password of a CRM user
// OR you can send special authorization hash which is sent by server after first successful connection with login and password
define('CRM_AUTH', 'bf3dec9d8996af9fa4225e6f90019476111'); // authorization hash

/********************************************************************************************/

## Транслитирация кирилических символов
function cyrillic_translit( $title ){
    $iso9_table = array(
        'А' => 'A', 'Б' => 'B', 'В' => 'V', 'Г' => 'G', 'Ѓ' => 'G',
        'Ґ' => 'G', 'Д' => 'D', 'Е' => 'E', 'Ё' => 'YO', 'Є' => 'YE',
        'Ж' => 'ZH', 'З' => 'Z', 'Ѕ' => 'Z', 'И' => 'I', 'Й' => 'J',
        'Ј' => 'J', 'І' => 'I', 'Ї' => 'YI', 'К' => 'K', 'Ќ' => 'K',
        'Л' => 'L', 'Љ' => 'L', 'М' => 'M', 'Н' => 'N', 'Њ' => 'N',
        'О' => 'O', 'П' => 'P', 'Р' => 'R', 'С' => 'S', 'Т' => 'T',
        'У' => 'U', 'Ў' => 'U', 'Ф' => 'F', 'Х' => 'H', 'Ц' => 'TS',
        'Ч' => 'CH', 'Џ' => 'DH', 'Ш' => 'SH', 'Щ' => 'SHH', 'Ъ' => '',
        'Ы' => 'Y', 'Ь' => '', 'Э' => 'E', 'Ю' => 'YU', 'Я' => 'YA',
        'а' => 'a', 'б' => 'b', 'в' => 'v', 'г' => 'g', 'ѓ' => 'g',
        'ґ' => 'g', 'д' => 'd', 'е' => 'e', 'ё' => 'yo', 'є' => 'ye',
        'ж' => 'zh', 'з' => 'z', 'ѕ' => 'z', 'и' => 'i', 'й' => 'j',
        'ј' => 'j', 'і' => 'i', 'ї' => 'yi', 'к' => 'k', 'ќ' => 'k',
        'л' => 'l', 'љ' => 'l', 'м' => 'm', 'н' => 'n', 'њ' => 'n',
        'о' => 'o', 'п' => 'p', 'р' => 'r', 'с' => 's', 'т' => 't',
        'у' => 'u', 'ў' => 'u', 'ф' => 'f', 'х' => 'h', 'ц' => 'ts',
        'ч' => 'ch', 'џ' => 'dh', 'ш' => 'sh', 'щ' => 'shh', 'ъ' => '',
        'ы' => 'y', 'ь' => '', 'э' => 'e', 'ю' => 'yu', 'я' => 'ya'
    );

    $name = strtr( $title, $iso9_table );
    $name = preg_replace('~[^A-Za-z0-9\'_\-\.]~', '-', $name );
    $name = preg_replace('~\-+~', '-', $name ); // --- на -
    $name = preg_replace('~^-+|-+$~', '', $name ); // кил - на концах

    return $name;
}

if($_POST['my_file_upload']=="123" && $_FILES){  
    // ВАЖНО! тут должны быть все проверки безопасности передавемых файлов и вывести ошибки если нужно
	$allowed_filetypes = array('.jpg','.png'); // Допустимые типы файлов 
	$max_filesize = 5242880; // Максимальный размер файла в байтах (в данном случае он равен 5 Мб 5242880 байт).

    $uploaddir = './uploads'; // . - текущая папка где находится submit.php
    
    // cоздадим папку если её нет
    if(!is_dir($uploaddir))mkdir($uploaddir, 0777);

    $files = $_FILES; // полученные файлы
    $done_files = array();

    // переместим файлы из временной директории в указанную
    foreach($files as $file){
		$filename = $file['name']; // В переменную $filename заносим имя файла (включая расширение).
		$ext = substr($filename, strpos($filename,'.'), strlen($filename)-1); // В переменную $ext заносим расширение загруженного файла.
		
		if(in_array($ext,$allowed_filetypes))
		{
			if(filesize($file['tmp_name']) < $max_filesize) // Проверим размер загруженного файла.
			{
				$file_name = cyrillic_translit($file['name']);
				if(move_uploaded_file($file['tmp_name'], "$uploaddir/$file_name")){
					$done_files[] = realpath( "$uploaddir/$file_name" );
				}
			}
			else
			{
				$done_files['error_text'][] = $file['name'].' - File is too big.';
			}
		}
		else
		{
			$done_files['error_text'][] = $file['name'].' - This file type is not supported.';
		}
    }
	
	if($done_files['error_text'])
	{
		$datafile = array('error' => 'File Upload Error.', 'error_text' => $done_files['error_text']);
		die(json_encode($datafile));
	}
	else
	{
		$datafile = array('files' => $done_files);
	}
}

// POST processing
if ($_SERVER['REQUEST_METHOD'] == 'POST')
{
	$leadData = $_POST;

	// get lead data from the form
	//https://dev.1c-bitrix.ru/community/blogs/chaos/crm-sozdanie-lidov-iz-drugikh-servisov.php
	$postData = array(
		'SOURCE_DESCRIPTION' => "1c-bitrixsupport.ru",
		'ASSIGNED_BY_ID' => 126,
	);
	
	if($leadData['formId'])
	{
		if ($leadData['formId'] == "calculation_form")
		{
			$postData['TITLE'] = "1c-bitrixsupport.ru. Заявка с формы. Расчет стоимости задачи.";
		}
		else if ($leadData['formId'] == "popup_form")
		{
			$postData['TITLE'] = "1c-bitrixsupport.ru. Заявка с формы. Заявка на постоянное обслуживание.";
		}
		else //ошибка
		{
			die("Ошибка, неизвестный formId <br><br>".json_encode($leadData));
		}
	}
	else //ошибка
	{
		die("Ошибка, не указан formId <br><br>".json_encode($leadData));
	}
	
	if($leadData['name']) {
		$postData['NAME'] = $leadData['name'];
	}
	if($leadData['phone']) {
		$postData['PHONE_MOBILE'] = $leadData['phone'];
	}
	if($leadData['site']) {
		$postData['WEB_WORK'] = $leadData['site'];
	}
	if($leadData['mail']) {
		$postData['EMAIL_HOME'] = $leadData['mail'];
	}
	
	$postData['COMMENTS'] = '<div style="font-size: 18px; line-height: 22px;"><b>Комментарии, ответы пользователя</b></div><br>';
	$postData['COMMENTS'] .= "<div style=\"font-weight: normal; \">";//открывающий div
	
	//Дублирование в комменты
	
	$postData['COMMENTS'] .= "<b>Источник:</b><br> 1c-bitrixsupport.ru. <br> ";
	if($leadData['formId'])
	{
		if ($leadData['formId'] == "calculation_form")
			$postData['COMMENTS'] .= "Форма расчета стоимости задачи. <br><br>";
		else if ($leadData['formId'] == "popup_form")
			$postData['COMMENTS'] .= "Форма заявки на постоянное обслуживание. <br><br>";
	}
	if($leadData['name']){
		$postData['COMMENTS'] .= "<b>Имя пользователя:</b><br>".$leadData['name']."<br>";
	}
	if($leadData['phone']){
		$postData['COMMENTS'] .= "<b>Телефон:</b><br>".$leadData['phone']."<br>";
	}
	if($leadData['site']){
		$postData['COMMENTS'] .= "<b>Сайт:</b><br>".$leadData['site']."<br>";
	}
	if($leadData['mail']){
		$postData['COMMENTS'] .= "<b>E-mail:</b><br>".$leadData['mail']."<br>";
	}
	//- конец Дублирование
	
	if($leadData['bitrix']){
		$postData['COMMENTS'] .= "<b>Редакция 1С-Битрикс:</b><br>".$leadData['bitrix']."<br><br>";
	}
	
	if($leadData['problem']){
		$postData['COMMENTS'] .= "<b>Описание проблемы:</b><br>".$leadData['problem']."<br><br>";
	}
	
	if($leadData['links']){
		$postData['COMMENTS'] .= "<b>Ссылки на страницы, где обнаружена проблема:</b><br>".$leadData['links']."<br><br>";
	}
	
	if($leadData['device']){
		if($leadData['device']=="on"){
			$leadData['device'] = "Да";
		}else{
			$leadData['device'] = "Нет";
		}
		$postData['COMMENTS'] .= "<b>Я пишу с устройства, на котором обнаружилась проблема:</b><br>".$leadData['device']."<br><br>";
	}
	/*
	if($datafile['files']){
		$postData['COMMENTS'] .= "<b>Загруженные файлы на фтп:</b><br>";
		foreach($datafile['files'] as $file){
			$postData['COMMENTS'] .= $file."<br>";
		}
	}
	*/
	if($datafile['files']){
		$postData['COMMENTS'] .= "<b>Загруженные файлы на фтп:</b><br>";
		foreach($datafile['files'] as $file){
			//ПРИ ПЕРЕНОСЕ ИЗМЕНИТЬ:
			$_url = str_replace('/home/users/a/admservice/domains/', 'http://', $file); //ПРИ ПЕРЕНОСЕ ИЗМЕНИТЬ
			//---------------------
			$postData['COMMENTS'] .= "<a href=\"".$_url."\">".$_url."</a>";
			$postData['COMMENTS'] .= "<br>";
		}
	}
	
	$postData['COMMENTS'] .= "</div>"; //закрывающий div

	// append authorization data
	if (defined('CRM_AUTH'))
	{
		$postData['AUTH'] = CRM_AUTH;
	}
	else
	{
		$postData['LOGIN'] = CRM_LOGIN;
		$postData['PASSWORD'] = CRM_PASSWORD;
	}

	// open socket to CRM
	$fp = fsockopen("ssl://".CRM_HOST, CRM_PORT, $errno, $errstr, 30);
	if ($fp)
	{
		// prepare POST data
		$strPostData = '';
		foreach ($postData as $key => $value)
			$strPostData .= ($strPostData == '' ? '' : '&').$key.'='.urlencode($value);

		// prepare POST headers
		$str = "POST ".CRM_PATH." HTTP/1.0\r\n";
		$str .= "Host: ".CRM_HOST."\r\n";
		$str .= "Content-Type: application/x-www-form-urlencoded\r\n";
		$str .= "Content-Length: ".strlen($strPostData)."\r\n";
		$str .= "Connection: close\r\n\r\n";

		$str .= $strPostData;

		// send POST to CRM
		fwrite($fp, $str);

		// get CRM headers
		$result = '';
		while (!feof($fp))
		{
			$result .= fgets($fp, 128);
		}
		fclose($fp); 
		
		// cut response headers
		$response = explode("\r\n\r\n", $result);
		
		$output = '<pre>'.print_r($response[1], 1).'</pre>';
		echo json_encode(array('success'=>'true'));
	}
	else
	{
		echo 'Connection Failed! '.$errstr.' ('.$errno.')';
	}
}
else
{
	$output = '';
}

// HTML form
?>
<?/*=$output;*/?>