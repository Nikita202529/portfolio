<!DOCTYPE html>
<html lang="ru">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

		<title>Техподдержка сайтов на 1С-Битрикс</title>	
		<!-- Bootstrap -->
		<link href="css/bootstrap.min.css" rel="stylesheet">

		<!-- Custom -->
		<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800&amp;subset=cyrillic" rel="stylesheet">
		<link rel="stylesheet" href="css/style.css">
	</head>

	<body>      
		<div class="wrap">

		  <div class="menu">
				<div class="menu-arrow">
				  <a href="http://adm-center.ru/" class="menu-logo">
						<img src="img/header/logo-white.svg" alt="ADM">
				  </a>
				  <div class="menu-arrow__link"></div>
				</div>
				<!-- ./menu-arrow -->
				<ul>
				  <li class="menu-item">
					<div class="menu-link">
					  <span class="icon-about"></span>
					  О компании
					</div>
					<div class="menu sub-menu">
					  <div class="menu-arrow">
						<a href="http://adm-center.ru/" class="menu-logo">
						  <img src="img/header/logo-white.svg" alt="ADM">
						</a>
						<div class="menu-arrow__link"></div>
					  </div>
					  <ul>
						<li><a href="http://adm-center.ru/ver/mi-v-tsifrah.html">Мы в цифрах</a></li>
						<li><a href="http://adm-center.ru/ver/vacancies.html">Вакансии</a></li>
					  </ul>
					</div>
					<!-- /.sub-menu -->
				  </li>
				  <!-- li -->
				  <li class="menu-item">
					<div class="menu-link">
					  <span class="icon-feature"></span>
					  Услуги
					</div>
					<div class="menu sub-menu">
					  <div class="menu-arrow">
						<a href="http://adm-center.ru/" class="menu-logo">
						  <img src="img/header/logo-white.svg" alt="ADM">
						</a>
						<div class="menu-arrow__link"></div>
					  </div>
					  <ul>
						<li><a href="http://1c-bitrixsupport.ru/">Техподдержка</a></li>
						<li><a href="https://bitrix-kassa.ru/">Настройка и подлючение Онлайн-касс</a></li>
					  </ul>
					</div>
					<!-- /.sub-menu -->
				  </li>
				  <li class="menu-item">
					<a href="http://adm-center.ru/ver/contacts.html" class="menu-link">
					  <span class="icon-contact"></span>
					  Контакты
					</a>
					<div class="menu sub-menu">
					  <div class="menu-arrow">
						<a href="http://adm-center.ru/" class="menu-logo">
						  <img src="img/header/logo-white.svg" alt="ADM">
						</a>
						<div class="menu-arrow__link"></div>
					  </div>
					  <ul>
						<li><a href="#"></a></li>
						<li><a href="#"></a></li>
						<li><a href="#"></a></li>
						<li><a href="#"></a></li>
					  </ul>
					</div>
					<!-- /.sub-menu -->
				  </li>
				  <!-- li -->          
				</ul>
				<!-- ul -->
		  </div>
		  <!-- ./menu -->
		  
		  <div class="scrollcontent">
			<header class="header">
			  <div class="container">
				<div class="row align-items-center">
				  <div class="col-6 col-sm-4 col-md-6 col-lg-4">
					<div class="row align-items-end">
					  <div class="col-5 col-sm-6 col-md-4 col-lg-6">
						<div class="header-menu-link" id="touch-menu"></div>              
					  </div>

					  <div class="col-7 col-sm-6 col-md-8 col-lg-6"> 
						<div href="http://adm-center.ru/" class="header-logo">
						  <img src="img/header/logo.svg" alt="ADM">
						</div>
					  </div>
					</div>
				  </div>

				  <div class="col-6 col-sm-8 col-md-6 col-lg-8 d-flex justify-content-end align-items-center">
					<a class="header-phone header-phone__mhidden" href="tel:+7(863)226-90-95">+7 (863) 226-90-95</a>
					<a class="header-btn button btn-scroll" href="#calculation">Оставить заявку</a>
					<!-- <button type="button" class="header-btn button" title>
					  Оставить заявку
					</button> -->
				  </div>
				</div>
				<!-- /.row -->
			  </div>
			  <!-- /.container -->
			</header>
			<!-- /.header -->

			<div class="highlights">
			  <div class="container">
				<div class="row">
				  <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
					<div class="row justify-content-center">
					  <div class="col-12 col-sm-11 col-md-12 col-lg-10 col-xl-12">
						<h1 class="title-main">Техническая поддержка сайтов на 1С-Битрикс</h1>
					  </div>
					  <!-- /.col-12 -->
					</div>
					<!-- /.row -->
					
				  </div>
				  <!-- /.col-12 -->
				</div>
				<!-- /.row -->
				<div class="row align-items-center">
				  <div class="col-12 col-sm-12 col-md-5 col-lg-5 col-xl-4 order-2 order-md-0">
					<div class="highlights-items d-flex justify-content-center justify-content-md-start">
					  <ul>
						<li class="d-flex align-items-center justify-content-start">
						  <div class="highlights_blue">10</div>
						  <div class="highlights-items__descr">10 лет опыта разработки сайтов</div>
						</li>
						<li class="d-flex align-items-center justify-content-start">
						  <div class="highlights_blue">50</div>
						  <div class="highlights-items__descr">Более 50 проектов на техподдержке</div>
						</li>
						<li class="d-flex align-items-center justify-content-start">
						  <div class="highlights_blue">15</div>
						  <div class="highlights-items__descr">15 мин реакции на заявку</div>
						</li>
					  </ul>
					</div>
				  </div>
				  <!-- /.col-6 -->
				  <div class="col-12 col-sm-12 col-md-7 col-lg-7 col-xl-8 pl-lg-0 pb-4 pb-sm-5 pb-md-0">                  
					<div class="row align-items-center">
					  <div class="col-9 col-sm-8 col-md-9 col-lg-10 col-xl-10 pr-xl-5 pl-lg-0 d-flex justify-content-start justify-content-lg-center justify-content-xl-end align-items-center">
						<div class="highlights-img">
						  <img src="img/support/support-adm.png" alt="Техподдержка ADM">
						</div>
						<!-- /.highlights-img -->
					  </div>
					  <!-- /.col-12 -->
					  <div class="col-3 col-sm-4 col-md-3 col-lg-2 col-xl-2 pl-0 d-flex justify-content-end">
						<div class="h-our_awards">
						  <ul class="d-flex flex-column justify-content-center">
							<li>
							  <img src="img/support/gold-partner.jpg" alt="1C-Bitrix Gold Partner" title="Золотой партнер 1С-Битрикс">
							</li>
							<li>
							  <img src="img/support/monitoring.jpg" alt="Monitoring Participant" title="Участник программы качества внедрений 1С-Битрикс">
							</li>
							<li><img src="img/support/kompozit.jpg" alt="Kompozit" title="Композитный сайт"></li>
							<li><img src="img/support/1c.jpg" alt="1c-integration" title="Интеграция с 1С"></li>
						  </ul>
						</div>
						<!-- /.header-middle-sale -->
					  </div>
					  <!-- /.col-5 -->
					</div>
					<!-- /.row -->
				  </div>
				  <!-- /.col-6 -->
				</div>
				<!-- /.row -->
			  </div>
			  <!-- /.container -->
			</div>
			<!-- /.highlights -->
			
			<section id="aboutServices" class="about-services">
			  <div class="container">
				<div class="row">
				  <div class="col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
					<div class="row justify-content-center">
					  <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
						<div class="about-services-desc">
						  <h2 class="about-services-title">Постоянная техподдержка</h2>

						  <!-- <div class="about-services-subtitle">Подходит для:</div> -->
						  <div class="about-services-price">
							<span>от</span> 1800 <span>руб/мес</span>
						  </div>
						  <div class="title-desc d-flex align-items-center">
							<div class="d-flex align-items-center"><img src="img/done.png" alt="#"></div>
							Для небольших проектов
						  </div>
						  <div class="title-desc d-flex align-items-center">
							<div class="d-flex align-items-center"><img src="img/done.png" alt="#"></div>
							Если нет своего системного администратора
						  </div>
						  <!-- <h3 class="title-desc-time">Время реакции на заявку 15 мин</h3> -->
						  <div class="support-bonus">
							Перенос сайта БЕСПЛАТНО!
						  </div>
						  <div class="about-services__btn d-flex justify-content-end">
							<a class="button support-detail__btn" href="#subscription">Подробнее</a>
						  </div>
						  <!-- /.about-services__btn -->
						</div>
						<!-- /.about-services-desc -->
					  </div>
					  <!-- /.col-12 -->
					</div>
					<!-- /.row -->
				  </div>
				  <!-- /.col-6 -->

				  <div class="col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
					<div class="row justify-content-center">
					  <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
						<div class="about-services-desc">
						  <h2 class="about-services-title">Почасовая разработка</h2>

						  <!--  <div class="about-services-subtitle">Подходит для:</div> -->
						  <div class="about-services-price">
							<span>от</span> 1400 <span>руб/ч</span>
						  </div>
						  <div class="title-desc d-flex align-items-center">
							<div class="d-flex align-items-center"><img src="img/done.png" alt="#"></div>
							Для крупных проектов
						  </div>
						  <div class="title-desc d-flex align-items-center">
							<div class="d-flex align-items-center"><img src="img/done.png" alt="#"></div>
							Ести не хватает собственных IT-специалистов
						  </div>
						  <!-- <h3 class="title-desc-time">Время реакции на заявку до 24 часов</h3> -->
						  <div class="support-bonus">
							СКИДКИ до 20%
						  </div>

						  <div class="about-services__btn d-flex justify-content-end">
							<a class="button support-detail__btn" href="#support">Подробнее</a>
						  </div>
						  <!-- /.about-services__btn -->
						</div>
						<!-- /.about-services-desc -->
					  </div>
					  <!-- /.col-9 -->
					</div>
					<!-- /.row -->
				  </div>
				  <!-- /.col-6 -->
				</div>
				<!-- /.row -->
			  </div>
			  <!-- /.container -->
			</section>
			<!-- /.about-service -->

			<section id="subscription" class="subscription">
			  <div class="container">  
				<div class="row">
				  <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
					<div class="row align-items-center">
					  <div class="col-12 col-md-6 col-lg-6 col-xl-6 d-none d-lg-flex justify-content-center">
						<div class="subscription-img">
						  <img src="img/support/subscription-fee.png" alt="Постоянная поддержка">
						</div>
						<!-- /.subscription-img -->
					  </div>
					  <!-- /.col-6 -->
					  <div class="col-12 col-sm-12 col-md-12 col-lg-6 col-xl-6">
						<div class="subscription-desc">
						  <div class="subscription-bg title-bg">subscription fees</div>
						  <div class="title-before">Постоянная поддержка</div>
						  <h2 class="title">Абонентская плата</h2>

						  <div class="title-desc d-flex align-items-center">
							<div class="d-flex align-items-center"><img src="img/done.png" alt="#"></div>
							Размещение на нашем сервере
						  </div>
						  <div class="title-desc d-flex align-items-center">
							<div class="d-flex align-items-center"><img src="img/done.png" alt="#"></div>
							Контроль работы сервера, сайта, почты, домена
						  </div>
						  <div class="title-desc d-flex align-items-center">
							<div class="d-flex align-items-center"><img src="img/done.png" alt="#"></div>
							Время реакции на заявку - 15 мин
						  </div>
						  <div class="support-price">
							<span>от</span> 1800 <span>руб/мес</span> 
						  </div>
						  <div class="support-bonus">
							Перенос сайта БЕСПЛАТНО!
						  </div>
						  <button class="button" data-toggle="modal" data-target="#ModalLong">Отправить заявку</button>
						</div>
						<!-- /.subscription-desc -->
					  </div>
					  <!-- /.col-6 -->
					</div>
					<!-- /.row -->
				  </div>
				  <!-- /.col-12 -->

				  <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
					<div class="subscription-block">
					  <div class="row align-items-start">
						<div class="col-12 col-lg-7 col-xl-6">
						  <div class="subscription-table__scroll">
							<div class="subscription-table">
							  <div class="s-table_name">
								<div class="table_name-blue">Тарифы</div>
								<div class="table_name-blue">Стандарт</div>
								<div class="table_name-blue">Эксперт</div>
								<div class="table_name-blue">Бизнес</div>
								<div class="table_name-blue">Бизнес Pro</div>
							  </div>
							  <div class="s-table_row">
								<div class="table_row-grey t-dark_grey">Консультирование</div>
								<div class="table_row-grey t-middle_grey">1 ч</div>
								<div class="table_row-grey t-middle_grey">2 ч</div>
								<div class="table_row-grey t-middle_grey">4 ч</div>
								<div class="table_row-grey t-middle_grey">8 ч</div>
							  </div>
							  <div class="s-table_row">
								<div class="table_row-grey t-dark_grey">Программирование</div>
								<div class="table_row-grey t-middle_grey">0 ч</div>
								<div class="table_row-grey t-middle_grey">2 ч</div>
								<div class="table_row-grey t-middle_grey">6 ч</div>
								<div class="table_row-grey t-middle_grey">16 ч</div>
							  </div>
							  <div class="s-table_row">
								<div class="table_row-grey t-dark_grey">Верстка / Контент / Дизайн</div>
								<div class="table_row-grey t-middle_grey">1 ч</div>
								<div class="table_row-grey t-middle_grey">4 ч</div>
								<div class="table_row-grey t-middle_grey">10 ч</div>
								<div class="table_row-grey t-middle_grey">20 ч</div>
							  </div>
							  <div class="s-table_row">
								<div class="table_row-grey t-middle_grey">HTML-лендинг</div>
								<div class="table_row-grey">800 р</div>
								<div class="table_row-grey"> </div>
								<div class="table_row-grey"> </div>
								<div class="table_row-grey"> </div>
							  </div>
							  <div class="s-table_row">
								<div class="table_row-grey t-middle_grey">Лендинг на CMS</div>
								<div class="table_row-grey">1200 р</div>
								<div class="table_row-grey"> </div>
								<div class="table_row-grey"> </div>
								<div class="table_row-grey"> </div>
							  </div>
							  <div class="s-table_row">
								<div class="table_row-grey t-middle_grey">Сайт-визитка</div>
								<div class="table_row-grey">1800 р</div>
								<div class="table_row-grey"> </div>
								<div class="table_row-grey"> </div>
								<div class="table_row-grey"> </div>
							  </div>
							  <div class="s-table_row">
								<div class="table_row-grey t-middle_grey">Корпоративный сайт/<br>Сайт-каталог</div>
								<div class="table_row-grey">2200 р</div>
								<div class="table_row-grey"> </div>
								<div class="table_row-grey"> </div>
								<div class="table_row-grey"> </div>
							  </div>
							  <div class="s-table_row">
								<div class="table_row-grey t-middle_grey">Интернет-магазин</div>
								<div class="table_row-grey">2800 р</div>
								<div class="table_row-grey">8800 р</div>
								<div class="table_row-grey">22400 р</div>
								<div class="table_row-grey">50400 р</div>
							  </div>
							</div>
						  </div>
						</div>

						<div class="col-12 col-lg-5 col-xl-6">
						  <div class="subscription-advant">
							<div class="subscription-advant__title">
							  Преимущества размещения на нашем сервере
							</div>

							<p>Такой вид поддержки оказывается <b>на абонентской плате</b>, в которую включен определенный набор услуг для корпоративного сайта минимальный тариф - <b>1800/мес</b>, для интернет магазина - <b>2800/мес</b> (в зависимости от нагрузок на проект).</p>
							<p>При таком виде техподдержки у вас полностью отсутствует головная боль по обслуживанию серверов и контроля работоспособности сайтов.</p>
							<p>Детально состав работ включенных в данный вид техподдержки вышлем дополнительно.</p>
							<p>ПЕРЕЕЗД САЙТОВ НА НАШИ СЕРВЕРА ОСУЩЕСТВЛЯЕТСЯ БЕСПЛАТНО.</p>
							<p>*Тарифы применяются для проектов с минимальной нагрузкой на сервер. Для определения нагрузки проект ставится на бесплатный тестовый режим в течение 2х недель.</p>
						
							<p>**При росте нагрузки сайта на сервер потребуется расширение ресурсов. Стоимость расширения согласовывается дополнительно.</p>  
								  
							<p>***Неизрасходованные часы за прошлый месяц накапливаются при оплате за следующий месяц, в противном случае - сгорают.</p>
									
							<p>****Возможны индивидуальные тарифы ТП. За расчетами обращаться к менеджерам по тел: (863) 226-90-96, (928) 163-11-00.</p>
						  </div>
						</div>
					  </div>
					  <!-- /.row -->
					</div>
					<!-- /.subscription-block -->
				  </div>
				  <!-- /.col-12 -->
				  
				  <div class="col-12 col-sm-12 col-md-12 col-lg-6 col-xl-6">
					<button class="button" data-toggle="modal" data-target="#ModalLong">Отправить заявку</button>
				  </div>
				</div>
				<!-- /.row -->
			  </div>
			  <!-- /.container -->
			</section>
			<!-- /.subscription -->

			<section id="support" class="support">
			  <div class="container">
				<div class="row">
				  <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
					<div class="row align-items-center align-items-xl-center">
					  <div class="col-12 col-lg-6 col-xl-6">
						<div class="support-desc">
						  <div class="support-bg title-bg">Hourly Payl</div>
						  <div class="title-before support-title-before">Всегда на связи</div>
						  <h2 class="title">Почасовая оплата</h2>
						  <div class="title-desc d-flex align-items-center">
							<div class="d-flex align-items-center"><img src="img/done.png" alt="#"></div>
							Решение конкретных задач
						  </div>
						  <div class="title-desc d-flex align-items-center">
							<div class="d-flex align-items-center"><img src="img/done.png" alt="#"></div>
							Время реакции зависит от загрузки специалиста
						  </div>
						  <div class="support-price">
							<span>от</span> 1400 <span>руб/ч</span>
						  </div>
						  <div class="support-bonus">
						   СКИДКА до 20%
						  </div>
						  <a class="button btn-scroll" href="#calculation">Рассчитать стоимость</a>
						</div>
						<!-- /.support-desc -->
					  </div>
					  <!-- /.col-6 -->

					  <div class="col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6 d-none d-lg-flex justify-content-center">
						<div class="support-img d-flex align-items-center">
						  <img src="img/support/hourly-fee.png" alt="Техническая поддержка">
						</div>
						<!-- /.support-img -->
					  </div>
					  <!-- /.col-6 -->
					</div>
					<!-- /.row -->
				  </div>
				  <!-- /.col-12 -->    

				  <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
					<div class="subscription-block">
					  <div class="row align-items-start">
						<div class="col-12 col-lg-7 col-xl-6">
						  <div class="subscription-table__scroll">
							<div class="subscription-table">
							  <div class="s-table_name">
								<div class="table_name-blue">Тарифы</div>
								<div class="table_name-blue">Стандарт</div>
								<div class="table_name-blue">Базовый</div>
								<div class="table_name-blue">Бизнес</div>
								<div class="table_name-blue">Цена за 1 час</div>
							  </div>
							  <div class="s-table_row">
								<div class="table_row-grey t-dark_grey">Количество часов</div>
								<div class="table_row-grey t-middle_grey">20</div>
								<div class="table_row-grey t-middle_grey">40</div>
								<div class="table_row-grey t-middle_grey">60</div>
								<div class="table_row-grey t-middle_grey"> </div>
							  </div>
							  <div class="s-table_row">
								<div class="table_row-grey t-dark_grey">Срок действия, месяц</div>
								<div class="table_row-grey t-middle_grey">3</div>
								<div class="table_row-grey t-middle_grey">6</div>
								<div class="table_row-grey t-middle_grey">9</div>
								<div class="table_row-grey t-middle_grey"> </div>
							  </div>
							  <div class="s-table_row">
								<div class="table_row-grey t-dark_grey">Скидка, %</div>
								<div class="table_row-grey t-middle_grey">5</div>
								<div class="table_row-grey t-middle_grey">10</div>
								<div class="table_row-grey t-middle_grey">15</div>
								<div class="table_row-grey t-middle_grey">20 ч</div>
							  </div>
							  <div class="s-table_row">
								<div class="table_row-grey t-middle_grey">Программирование</div>
								<div class="table_row-grey">26600 р</div>
								<div class="table_row-grey">50400 р</div>
								<div class="table_row-grey">95200 р</div>
								<div class="table_row-grey">1400 р</div>
							  </div>
							  <div class="s-table_row">
								<div class="table_row-grey t-middle_grey">Верстка/Контент</div>
								<div class="table_row-grey">22800 р</div>
								<div class="table_row-grey">43200 р</div>
								<div class="table_row-grey">22800 р</div>
								<div class="table_row-grey">1200 р</div>
							  </div>
							  <div class="s-table_row">
								<div class="table_row-grey t-middle_grey">Дизайн</div>
								<div class="table_row-grey">19000 р</div>
								<div class="table_row-grey">36000 р</div>
								<div class="table_row-grey">68000 р</div>
								<div class="table_row-grey">1000 р</div>
							  </div>
							</div>
						  </div>  
						</div>
						<div class="col-12 col-lg-5 col-xl-6">
						  <div class="subscription-advant">
							<p>При размещении на ваших серверах <b>техподдержка осуществляется "от задач" - </b> задача ставится, согласовывается, осмечивается, ставится в план, выполняется.</p>

							<p>В таком случае контроль работоспособности серверов и сайта осуществляется вашими силами и средствами.</p>

							<p>Для такого вида техподдержки трудозатраты оцениваются в трудочасах. Стоимость часа бэкенд разработчика на текущий момент - <b>1400 рублей</b>. Так, например, если задачу оценили в 4 часа, то стоимость ее выполнения 5600 рублей. Срок выполнения зависит от очереди и нагрузки на разработчиков.</p>

							<p>В таком варианте техподдержки есть возможность закупать пакеты часов по 20/40/80 с скидкой 5/10/15 процентов соответственно, что выгодно для объемных работ.</p>

							<div class="subscription-advant__title">Регламент сотрудничества</div>
							<p>При невыработке часов из пакета в течение срока действия пакета, стоимость невыработанных часов не возвращается.</p>       
							<p>Время обращения с вопросом/задачей/правкой: с 09:00 до 18:00 по мск (Пн - Пт).</p>
								  
							<p>Выполненная задача считается принятой, если после уведомления о готовности от заказчика не поступило ответа/замечаний в течение 3 дней.</p>
								  
							<p>Время обработки вашего запроса менеджером: от 15 мин до 24ч.</p>  
						  </div>
						</div>
					  </div>
					  <!-- /.row -->
					</div>
					<!-- /.subscription-block -->
				  </div>
				  <!-- /.col-12 -->

				  <div class="col-12 col-sm-12 col-md-12 col-lg-6 col-xl-6">
					<a class="button btn-scroll" href="#calculation">Рассчитать стоимость</a> 
				  </div>
				</div>
				<!-- /.row --> 
			  </div>
			  <!-- /.container -->
			</section>
			<!-- /.support -->

			<section class="support-services">
			  <div class="container">
				<div class="row align-items-center">
				  <div class="col-12">
					<div class="support-services-bg title-bg">Type of work</div> 
					<h2 class="title support-services__title">Виды услуг техподдержки</h2>
				  </div>
				</div>
				<!-- /.row -->
				<div class="row align-items-start">
				  <div class="col-10 col-sm-6 col-md-6 col-lg-4 col-xl-3 d-flex justify-content-center justify-content-lg-start">
					<div class="service-item">
					  <img src="img/support/host.svg" class="service-item_img" alt="Размещение на сервере">
					  <h3 class="service-item_name">Размещение на сервере</h3>
					  <div class="service-item_desc">
						Размещение сайта на хостинге. Переезд с одного хостинга на другой, контроль работоспособности.
					  </div>
					</div>
				  </div>  
				  <div class="col-10 col-sm-6 col-md-6 col-lg-4 col-xl-3 d-flex justify-content-center justify-content-lg-start">
					<div class="service-item">
					  <img src="img/support/1c.svg" class="service-item_img" alt="Интеграция систем">
					  <h3 class="service-item_name">Интеграция систем</h3>
					  <div class="service-item_desc">
						1С. Мой склад. Онлайн-касса.  В том числе с нестандартными, нетиповыми конфигурациями. Обмен каталогами с внешними системами.
					  </div>
					</div>
				  </div> 
				  <div class="col-10 col-sm-6 col-md-6 col-lg-4 col-xl-3 d-flex justify-content-center justify-content-lg-start">
					<div class="service-item">
					  <img src="img/support/responsive.svg" class="service-item_img" alt="Разрабатываем адаптив">
					  <h3 class="service-item_name">Адаптив</h3>
					  <div class="service-item_desc">
						Разрабатываем адаптивные сайты и адаптируем уже существующие под любые устройства.
					  </div>
					</div>
				  </div> 
				  <div class="col-10 col-sm-6 col-md-6 col-lg-4 col-xl-3 d-flex justify-content-center justify-content-lg-start">
					<div class="service-item">
					  <img src="img/support/bitrix24.svg" class="service-item_img" alt="Интеграция с Битрикс24">
					  <h3 class="service-item_name">Интеграция с Битрикс24</h3>
					  <div class="service-item_desc">
						Настройка автоматизированных бизнес-процессов в едином  пространстве.
					  </div>
					</div>
				  </div> 
				  <div class="col-10 col-sm-6 col-md-6 col-lg-4 col-xl-3 d-flex justify-content-center justify-content-lg-start">
					<div class="service-item">
					  <img src="img/support/audit.svg" class="service-item_img" alt="Технический аудит">
					  <h3 class="service-item_name">Технический аудит</h3>
					  <div class="service-item_desc">
						Выявление ошибок, препятствующих успешному продвижению. Варианты исправления ошибок .
					  </div>
					</div>
				  </div> 
				  <div class="col-10 col-sm-6 col-md-6 col-lg-4 col-xl-3 d-flex justify-content-center justify-content-lg-start">
					<div class="service-item">
					  <img src="img/support/diagnosis.svg" class="service-item_img" alt="Диагностика">
					  <h3 class="service-item_name">Диагностика</h3>
					  <div class="service-item_desc">
						Проверка корректности внутреннего кода, вёрстки, скорости загрузки, безопасности, ошибок на сайте  и др.
					  </div>
					</div>
				  </div> 
				  <div class="col-10 col-sm-6 col-md-6 col-lg-4 col-xl-3 d-flex justify-content-center justify-content-lg-start">
					<div class="service-item">
					  <img src="img/support/vidjets.svg" class="service-item_img" alt="Виджеты">
					  <h3 class="service-item_name">Виджеты</h3>
					  <div class="service-item_desc">
					   Подключение внешних виджетов и систем, в том числе систем аналитики Яндекс Метрика, Google Analytics и др.
					  </div>
					</div>
				  </div> 
				  <div class="col-10 col-sm-6 col-md-6 col-lg-4 col-xl-3 d-flex justify-content-center justify-content-lg-start">
					<div class="service-item">
					  <img src="img/support/content.svg" class="service-item_img" alt="Контент">
					  <h3 class="service-item_name">Контент</h3>
					  <div class="service-item_desc">
						Копирайтинг и размещение контента. Обработка графических материалов, видео и презентаций. Размещение статей, новостей, обзоров. 
					  </div>
					</div>
				  </div> 
				  <div class="col-10 col-sm-6 col-md-6 col-lg-4 col-xl-3 d-flex justify-content-center justify-content-lg-start">
					<div class="service-item">
					  <img src="img/support/copy.svg" class="service-item_img" alt="Резервное копирование">
					  <h3 class="service-item_name">Резервное копирование</h3>
					  <div class="service-item_desc">
						Настройка регулярного резервного копирования. Восстановление сайта из копии.  
					  </div>
					</div>
				  </div> 
				  <div class="col-10 col-sm-6 col-md-6 col-lg-4 col-xl-3 d-flex justify-content-center justify-content-lg-start">
					<div class="service-item">
					  <img src="img/support/design.svg" class="service-item_img" alt="Дизайн/Редизайн">
					  <h3 class="service-item_name">Дизайн/Редизайн</h3>
					  <div class="service-item_desc">
						Изменение в дизайне и переработка функционала. Отрисовка отдельных элементов. Доработка дизайна интерфейса. 
					  </div>
					</div>
				  </div> 
				  <div class="col-10 col-sm-6 col-md-6 col-lg-4 col-xl-3 d-flex justify-content-center justify-content-lg-start">
					<div class="service-item">
					  <img src="img/support/instruction.svg" class="service-item_img" alt="Инструкции">
					  <h3 class="service-item_name">Инструкции</h3>
					  <div class="service-item_desc">
						Написание инструкций для пользователей и администраторов.  
					  </div>
					</div>
				  </div> 
				  <div class="col-10 col-sm-6 col-md-6 col-lg-4 col-xl-3 d-flex justify-content-center justify-content-lg-start">
					<div class="service-item">
					  <img src="img/support/learning.svg" class="service-item_img" alt="Обучение">
					  <h3 class="service-item_name">Обучение</h3>
					  <div class="service-item_desc">
						Обучение работе с сайтом: заполнение, редактирование и т.д.
					  </div>
					</div>
				  </div>
				  <div class="col-12 col-sm-12 col-md-12 col-lg-12 d-block d-lg-none">
					<div class="service-links">
					  <div class="service-link service-link__show">Показать все &#187;</div>
					  <div class="service-link service-link__hide">Скрыть &#187;</div>
					</div>
				  </div>
				</div>
				<!-- /.row -->
			  </div>
			  <!-- /.container -->
			</section>
			<!-- /.support-services -->
		
			<section class="recommend">
			  <div class="container">
				<div class="row">
				  <div class="col-12">
					<div class="recommend-bg title-bg">Recommend</div>
					<h2 class="title recommend-title">Как мы обрабатываем заявки</h2>
				  </div>
				  <!-- /.col-12 -->

				  <div class="col-12 col-sm-12 offset-sm-2 col-md-6 offset-md-6">
					<div class="work-process">
					  <div class="wp-text-bg__top text-bg">Заявка</div>
					  <div class="wp-tree">
						
						<div class="wp-cell">
						  <div class="wp-cell-bg text-bg">15 мин</div>
						  <div class="wprocess-number">1</div>
						  <div class="wp-line"></div>
						  <div class="wp-img"><img src="img/recommend/1.svg" alt="#"></div>
						  <div class="wprocess-step">Реагирование</div>
						  <div class="wprocess-desc">Время реагирования на заявку клиента на техподдержке - 15 мин. 1-2 часа для всех клиентов.</div>
						</div>
						
						<div class="wp-cell">
						  <div class="wp-cell-bg text-bg">1 день</div>
						  <div class="wprocess-number">2</div>
						  <div class="wp-line"></div>
						  <div class="wp-img"><img src="img/recommend/2.svg" alt="#"></div>
						  <div class="wprocess-step">Обсуждение</div>
						  <div class="wprocess-desc">К обсуждению привлекаются все заинтересованные специалисты. Время на обсуждение и выборку заявок - 1-2 дня.</div>
						</div>
						
						<div class="wp-cell">
						  <div class="wprocess-number">3</div>
						  <div class="wp-line"></div>
						  <div class="wp-img"><img src="img/recommend/3.svg" alt="#"></div>
						  <div class="wprocess-step">Составление условий</div>
						  <div class="wprocess-desc">Обсуждаются условия, сроки, стоимость, исполнитель. Заявке присваивается статус "задача".</div>
						</div>
						
						<div class="wp-cell">
						  <div class="wprocess-number">4</div>
						  <div class="wp-line"></div>
						  <div class="wp-img"><img src="img/recommend/4.svg" alt="#"></div>
						  <div class="wprocess-step">Согласование</div>
						  <div class="wprocess-desc">Согласование с клиентом стоимости и сроков исполнения задачи.</div>
						</div>
						
						<div class="wp-cell">
						  <div class="wp-cell-bg text-bg">очередь</div>
						  <div class="wprocess-number">5</div>
						  <div class="wp-line"></div>
						  <div class="wp-img"><img src="img/recommend/5.svg" alt="#"></div>
						  <div class="wprocess-step">Постановка задачи в план</div>
						  <div class="wprocess-desc">Учитывая загруженность специалиста, задача ставится в план.</div>
						</div>
						
						<div class="wp-cell">
						  <div class="wp-cell-bg text-bg">проверка</div>
						  <div class="wprocess-number">6</div>
						  <div class="wp-line"></div>
						  <div class="wp-img"><img src="img/recommend/6.svg" alt="#"></div>
						  <div class="wprocess-step">Контроль процесса</div>
						  <div class="wprocess-desc">Клиенту сообщается о готовности задачи. Проводится сдача задачи.
						  </div>
						</div>
						
						<div class="wp-cell">
						  <div class="wprocess-number">7</div>
						  <div class="wp-line"></div>
						  <div class="wp-img"><img src="img/recommend/7.svg" alt="#"></div>
						  <div class="wprocess-step">Сохранение</div>
						  <div class="wprocess-desc">Обязательное сохранение результата после выполнения задачи.</div>
						</div>
					  </div>
					  <div class="wp-text-bg__bottom text-bg">game over</div>
					</div>
				  </div>
				  <!-- /.col-12 -->
				</div>
				<!-- /.row -->
			  </div>
			  <!-- /.container -->
			</section>
			<!-- /.recommend -->

			<section id="calculation" class="calculation">
			  <div class="container">
				<div class="row">
				  <div class="col-12">
					<div class="calculation-item-title"> 
					  <div class="calculation-bg title-bg">Cost calculation</div>
					  <h2 class="title calculation-title">Нужно рассчитать стоимость задачи?</h2>  
					</div>
					<!-- /.calculation-item-title -->
				  </div>
				  <!-- /.col-12 -->
				</div>
				<!-- /.row -->
				
				<div class="row justify-content-between">
				  <div class="col-12 d-flex">
					<p>Если не знаете, сколько часов займет ваша заявка, предлагаем рассчитать.  Заполните форму и наши специалисты помогут вам.</p>
				  </div>
				</div>
				<div class="calculation-form">
					<form action="" id="calculation_form" class="calculation-form__form" method="post" enctype="multipart/form-data">
						<input type="hidden" name="my_file_upload" id="my_file_upload">
						<div class="row">
							<div class="col-12 col-sm-12 col-md-6 col-lg-6">
								<input class="calculation-form__input" type="text" name="user-name" id="user-name" placeholder="Имя" required="required">
								<input class="calculation-form__input" type="tel" name="user-phone" id="user-phone" placeholder="Телефон" title="+7 (___) ___-__-__" required="required">
								<input class="calculation-form__input" type="text" name="site-name" id="site-name" placeholder="Адрес сайта" <?/*?>required="required"<?*/?>>
								<input class="calculation-form__input" type="text" name="bitrix" id="bitrix" placeholder="Редакция 1С-Битрикс" <?/*?>required="required"<?*/?>>            
							</div>
							<div class="col-12 col-sm-12 col-md-6 col-lg-6">
								<textarea class="calculation-form__input calculation-form__ta" name="site-problem" placeholder="Описание проблемы" required></textarea>
								<textarea class="calculation-form__input calculation-form__ta" name="site-problem-links" placeholder="Ссылки на страницы, где обнаружена проблема" <?/*?>required<?*/?>></textarea>
								<label class="calculation-label d-inline-flex align-items-center" for="file-upload">
									<img src="img/calculation/icon.svg" alt="#">
									<span>Загрузить скриншот подтверждающий проблему</span>
									<input class="calculation-form__input d-none" type="file" name="file-upload" id="file-upload" <?/*?>required="required"<?*/?> multiple accept="image/jpeg,image/png">
								</label>
								<small class="calculation-small">формат файла: png/jpg, размер до 5Мб</small>
							</div>  
							<div class="col-12">
								<div class="calculation-form__checkbox d-inline-flex align-items-center">
									<div>
										<input type="checkbox" name="user-device" class="options" id="user-device" <?/*?>required="required"<?*/?>>
									</div>
									<label for="user-device">Я пишу с устройства, на котором обнаружилась проблема</label>
								</div>
								<div class="calculation-form__consent d-flex align-items-center justify-content-start">
									Нажимая на кнопку, я даю согласие на передачу личных данных ФЗ РФ №152 «О защите персональных данных»
								</div>
								<div class="d-flex align-items-center justify-content-start">
									<button type="submit" class="button calculation-form__btn">
										Отправить заявку
									</button>
								</div>  
							</div>
						</div>
					</form>
				</div>
				<!-- /.calculation-form --> 
			  </div>
			  <!-- /.container -->
			</section>
			<!-- /.calculation -->

			<footer class="footer">
			  <div class="footer-top">
				<div class="container">
				  <div class="row">
					<div class="col-12 col-md-4 col-lg-4 d-flex justify-content-start justify-content-md-center">
					  <ul class="footer-top__list list-1">
						<li><a href="tel:+7(863)226-90-95" class="footer-top-link">+7 (863) 226-90-95</a></li>
					  </ul>
					</div>
					<!-- /.col-4 -->
					<div class="col-12 col-md-4 col-lg-4 d-flex justify-content-start justify-content-md-center">
					  <ul class="footer-top__list list-2">
						<li><a href="tel:+7(863)226-90-95" class="footer-top-link">+7 (863) 226-90-95</a></li>
					  </ul>
					</div>
					<!-- /.col-4 -->
					<div class="col-12 col-md-4 col-lg-4 d-flex justify-content-start justify-content-md-center">
					  <ul class="footer-top__list list-3">
						<li><a href="mailto:mail@adm-center.ru" class="footer-top-link">mail@adm-center.ru</a></li>
					  </ul>
					</div>
					<!-- /.col-4 -->
				  </div>
				  <!-- /.row -->
				</div>
				<!-- /.container -->  
			  </div>
			  <!-- /.footer-top -->
			  <div class="footer-bottom">
				<div class="container">
				  <div class="row align-items-center">
					<div class="col-9 col-sm-6 offset-1 offset-md-0 col-md-4 col-lg-5">
					  <div class="footer-bottom-social d-flex flex-wrap flex-lg-nowrap justify-content-between align-items-center">
						<a href="#"><span class="icon-facebook"></span></a>
						<a href="#"><span class="icon-vkontakte"></span></a>
						<a href="#"><span class="icon-odnoklassniki"></span></a>
						<a href="#"><span class="icon-twitter"></span></a>
						<a href="#"><span class="icon-telegram"></span></a>
						<a href="#"><span class="icon-instagram"></span></a>
						<a href="#"><span class="icon-whatsapp"></span></a>
						<a href="#"><span class="icon-viber-brands"></span></a>
						<a href="#"><span class="icon-pinterest"></span></a>
					  </div>
					  <!-- /.footer-bottom-social -->
					</div>
					<!-- /.col-6 -->
					<div class="col-12 col-md-7 col-lg-7">
					  <div class="row align-items-center">
						<div class="col-12 col-md-7 col-lg-8 d-flex justify-content-start justify-content-lg-end">
						  <a href="#" class="footer-bottom-privacy">
							Политика конфиденциальности
						  </a>
						  <!-- /.footer-bottom-privacy -->
						</div>
						<!-- /.col-12 collg-6 -->
						<div class="col-12 col-md-5 col-lg-4 d-flex justify-content-start justify-content-md-end">
						  <div class="footer-bottom-copy">
							&#169; 2008-2018 ЦИТ «ADM»
						  </div>
						  <!-- /.footer-bottom-copy -->
						</div>
						<!-- /.col-12 collg-6 -->
					  </div>
					  <!-- /.row -->
					  
					</div>
					<!-- /.col-6 -->
				  </div>
				  <!-- /.row -->
				</div>
				<!-- /.container -->  
			  </div>
			  <!-- /.footer-bottom -->
			</footer>
			<!-- /.footer -->
				</div>
		  <!-- /.scrollcontent -->

				<div class="send-request modal fade" id="ModalLong" tabindex="-1" role="dialog" aria-labelledby="ModalLongTitle" aria-hidden="true">
			  <div class="popup modal-dialog" role="document">
			  <button type="button" class="popup-close close" data-dismiss="modal" aria-label="Close">
				<span aria-hidden="true">&times;</span>
			  </button>
				<!-- <div class="popup-close close" data-dismiss="modal" aria-label="Close">&times;</div>-->
				<!-- /.popup-close -->

				<div class="popup-form">
					<div class="popup-form-header" id="ModalLongTitle">
						<div class="popup-form-header__title">Оставьте заявку на постоянное обслуживание</div>
						<div class="popup-form-header__descr">Заполните анкету и наши специалисты свяжутся с вами для обсуждения возможностей сотрудничества</div>
					</div>
				  <form action="" id="popup_form" class="popup-form__form" method="POST">
					<div class="popup-form-box">
					  <input class="popup-form-box__input" type="text" name="user-name_modal" id="user-name_modal" placeholder="Имя" required="required">
					  <input class="popup-form-box__input" type="tel" name="user-phone_modal" id="user-phone_modal" placeholder="Телефон" title="+7 (___) ___-__-__" required="required">
					  <textarea class="popup-form-box__input popup-form-box__ta" name="user-linksite" placeholder="Адрес сайта" required></textarea>
					  <div class="popup-form-desc">
						Нажимая на кнопку я соглашаюсь на передачу личных данных ФЗ РФ № 152 «О защите персональных данных»
					  </div>
					</div>
					<!-- /.popup-form-box -->

					<div class="popup-form__button d-flex justify-content-center">
					  <button class="button popup-form__btn">
						Отправить заявку
					  </button>                
					</div>       
					<!-- /.popup-form__btn -->
				  </form>
				</div>
				<!-- /.popup-form -->
			  </div>
			  <!-- /.popup -->
			</div>
			<!-- /.send-request -->
		</div>
		<!-- /.wrap -->

		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script> 
		
		<script>window.jQuery || document.write('<script src="js/jquery.min.js"><\/script>')</script>
		<script src="js/bootstrap.min.js"></script>
		<script src="js/jquery.maskedinput.min.js"></script>
		<script src="js/main.js"></script>
 
	</body>
</html>