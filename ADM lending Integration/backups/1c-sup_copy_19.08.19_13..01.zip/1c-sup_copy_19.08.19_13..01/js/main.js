function deepCompare () {
  var i, l, leftChain, rightChain;

  function compare2Objects (x, y) {
    var p;

    // remember that NaN === NaN returns false
    // and isNaN(undefined) returns true
    if (isNaN(x) && isNaN(y) && typeof x === 'number' && typeof y === 'number') {
         return true;
    }

    // Compare primitives and functions.     
    // Check if both arguments link to the same object.
    // Especially useful on the step where we compare prototypes
    if (x === y) {
        return true;
    }

    // Works in case when functions are created in constructor.
    // Comparing dates is a common scenario. Another built-ins?
    // We can even handle functions passed across iframes
    if ((typeof x === 'function' && typeof y === 'function') ||
       (x instanceof Date && y instanceof Date) ||
       (x instanceof RegExp && y instanceof RegExp) ||
       (x instanceof String && y instanceof String) ||
       (x instanceof Number && y instanceof Number)) {
        return x.toString() === y.toString();
    }

    // At last checking prototypes as good as we can
    if (!(x instanceof Object && y instanceof Object)) {
        return false;
    }

    if (x.isPrototypeOf(y) || y.isPrototypeOf(x)) {
        return false;
    }

    if (x.constructor !== y.constructor) {
        return false;
    }

    if (x.prototype !== y.prototype) {
        return false;
    }

    // Check for infinitive linking loops
    if (leftChain.indexOf(x) > -1 || rightChain.indexOf(y) > -1) {
         return false;
    }

    // Quick checking of one object being a subset of another.
    // todo: cache the structure of arguments[0] for performance
    for (p in y) {
        if (y.hasOwnProperty(p) !== x.hasOwnProperty(p)) {
            return false;
        }
        else if (typeof y[p] !== typeof x[p]) {
            return false;
        }
    }

    for (p in x) {
        if (y.hasOwnProperty(p) !== x.hasOwnProperty(p)) {
            return false;
        }
        else if (typeof y[p] !== typeof x[p]) {
            return false;
        }

        switch (typeof (x[p])) {
            case 'object':
            case 'function':

                leftChain.push(x);
                rightChain.push(y);

                if (!compare2Objects (x[p], y[p])) {
                    return false;
                }

                leftChain.pop();
                rightChain.pop();
                break;

            default:
                if (x[p] !== y[p]) {
                    return false;
                }
                break;
        }
    }

    return true;
  }

  if (arguments.length < 1) {
    return true; //Die silently? Don't know how to handle such case, please help...
    // throw "Need two or more arguments to compare";
  }

  for (i = 1, l = arguments.length; i < l; i++) {

      leftChain = []; //Todo: this can be cached
      rightChain = [];

      if (!compare2Objects(arguments[0], arguments[i])) {
          return false;
      }
  }

  return true;
}

Array.prototype.unique = function() {
    var a = this.concat();
    for(var i=0; i<a.length; ++i) {
        for(var j=i+1; j<a.length; ++j) {
            if(deepCompare(a[i],a[j])) //было if(a[i] === a[j])
                a.splice(j--, 1);
        }
    }

    return a;
};



//-----------------------------------------------------------------------
//             Костыль для IE
//-----------------------------------------------------------------------

//Убирает баг дрожания фиксированного заголовка при прокрутке колесом мыши, когда меню открыто
$(document).ready(function (){
 if(navigator.userAgent.match(/Trident\/7\./)) {
    $('body').on("mousewheel", function () {
        event.preventDefault();

        var wheelDelta = event.wheelDelta;

        var currentScrollPosition = window.pageYOffset;
        window.scrollTo(0, currentScrollPosition - wheelDelta);
    });
 }
});


//-----------------------------------------------------------------------
//             Маски на телефонные номера
//-----------------------------------------------------------------------

//Маски на телефонные номера
jQuery(function($){
  $("#user-phone").mask("+7 (999) 999-99-99", {autoclear: false});
  $("#user-phone_modal").mask("+7 (999) 999-99-99", {autoclear: false});
});

//-----------------------------------------------------------------------
//             Плавная прокрутка
//-----------------------------------------------------------------------

// Плавная прокрутка
// Элемент, после нажатия на который прокручивается должен иметь класс "btn-scroll", а в href должна быть ссылка на якорь
// Пример:
// 		<a class="button btn-scroll" href="#calculation">Оставить заявку</a>
$(document).ready(function (){

function scrollPage(selector)
{
	$(selector).click(function()
	{
		var page = $("html, body");
		page.on("scroll mousedown wheel DOMMouseScroll mousewheel keyup touchmove", function(){
		   page.stop();
		});

		page.animate(
		{   scrollTop: $($(this).attr("href")).offset().top - 30 },
		   1500,
		   function(){
		   page.off("scroll mousedown wheel DOMMouseScroll mousewheel keyup touchmove");
		});

		return false; 
	});

}

  scrollPage('.btn-scroll');
  
});


//-----------------------------------------------------------------------
//             Меню
//-----------------------------------------------------------------------


$(document).ready( function () {
  'use strict';
  
  // start main menu
    var hamburger = document.querySelector('.header-menu-link'),
        menu = document.querySelector('.menu'),
        scrollcontent = document.querySelector('.scrollcontent'),
        menuArrowBack = document.querySelector('.menu-top_arrow'),
        menuItem = document.querySelectorAll('.menu-item'),
        menuLink = document.querySelectorAll('.menu-link'),
        body = document.querySelector('body'),
        headerLogo = document.querySelector('.header-logo');

    // show main menu
    function showMenu() {

		menu.classList.add('menu-active');
		scrollcontent.classList.add('scrollcontent_active');

		$( '.header-menu-link' ).css('display', 'none' );
		$( '.header-menu-close' ).css('display', 'block' );
		
		/*
		if (menu.clientWidth == document.body.clientWidth)
		{
			document.body.classList.add( 'frozen' );
			document.getElementsByTagName( 'html' )[0].classList.add('frozen');
		}
		*/
    }

    // hide main menu
    function hideMenu() {
		menu.classList.remove('menu-active');
		scrollcontent.classList.remove('scrollcontent_active');

		$( '.header-menu-link' ).css('display', 'block' );
		$( '.header-menu-close' ).css('display', 'none' );
		
		/*
		if (document.body.classList.contains( 'frozen' ))
			document.body.classList.remove( 'frozen' );
		if (document.getElementsByTagName( 'html' )[0].classList.contains( 'frozen' ))
			document.getElementsByTagName( 'html' )[0].classList.remove( 'frozen' );
		*/
    }

    //Event when you click on a hamburger and then the menu appears
    hamburger.addEventListener('click', function(e) {
        e.stopPropagation();
		
		let menu_is_active = $(menu).hasClass( 'menu-active' );
		if (menu_is_active)
			hideMenu();
		else
			showMenu();
    });

    // Event when you click outside menu - menu hide
    document.addEventListener('click', function( e ) {
      let target = e.target;
      let its_menu = target == menu || menu.contains(target);
	  
	  //e.stopPropagation();
      let its_hamburger = target == hamburger;
      let menu_is_active = menu.classList.contains('menu-active');

      
      if (!its_menu && !its_hamburger && menu_is_active) {
        hideMenu(); 
      }  
    });


    // Event when you click on the arrow main menu and then the menu is hidden
    menuArrowBack.addEventListener('click', function( e ) {
		e.stopPropagation();
		hideMenu();
    });
	
	
	//свайп по окну
	/*
	$( window ).on( "swipeleft", function( e ) { 
		e.stopPropagation();
		hideMenu();
	} );
	
	$( window ).on( "swiperight", function( e ) { 
		e.stopPropagation();
		showMenu();
	} );
	*/
	
  // end main menu
});

//-----------------------------------------------------------------------
//             Показать все сервисы/Скрыть все сервисы
//-----------------------------------------------------------------------

$(document).ready( function () {
//show some blocks when you click on a link
  let serviceItem = document.querySelectorAll('.service-item'),
      serviceLinks = document.querySelector('.service-links'),
      serviceLink = document.querySelectorAll('.service-link');

  function showserviceItem() {
    for (let i = 0; i < serviceItem.length; i++) {
      serviceItem[i].style.display = '';
    }
  }

  function hideserviceItem() {
    for (let i = 0; i < serviceItem.length; i++) {
      if (i > 5) {
        serviceItem[i].style.display = 'none';
      } else {
        serviceItem[i].style.display = '';
      }
    }
  }
  //Все сервисы показываются только на широком экране:
  function serviceBlock() {
    //if ($(window).width() < 992) {
    if (window.innerWidth < 992) {
      hideserviceItem();
      //serviceLink[0].style.display = 'inline-block';
    } else {
      showserviceItem();
      // serviceLink[1].style.display = 'none';
    }
  }

  //Показать все сервисы/Скрыть все сервисы
  serviceLinks.addEventListener('click', function(e) {
    let target = e.target;
    if (target && target.classList.contains('service-link__show')) {
      showserviceItem();
      serviceLink[0].style.display = 'none';
      serviceLink[1].style.display = 'inline-block';
    } 
  });  
  serviceLinks.addEventListener('click', function(e) {
    let target = e.target;
    if (target && target.classList.contains('service-link__hide')) {
      hideserviceItem();
      serviceLink[0].style.display = 'inline-block';
      serviceLink[1].style.display = 'none';
    }
  });

  serviceBlock();

});

//-----------------------------------------------------------------------
//             AJAX-отправка форм
//-----------------------------------------------------------------------

$(document).ready(function ()
{
	
	//Загруженные файлы
	var files = [];
	
	$('input[type="file"]').change( function()
	{
		//files = this.files;//старая версия
		
		//новая версия - важно
		for (let i = 0; i < this.files.length; i++)
			files.push( this.files[i]);
		
		files = files.unique();//не стандартная функция. Прописана в начале файла. Удаляет все совпадения в массиве
		
		$('#my_file_upload').val("123");//важно
		
		refresh_all_preloads_html();
	});

	//-----------------------------------------------------------------------
	//             Обновление превьюшек загрузок
	//-----------------------------------------------------------------------


	/* //Чистый пример:
	$('input[type="file"]').change(function(e){
				var fileName = e.target.files[0].name;
				alert('The file "' + fileName +  '" has been selected.');
			});
	*/
	//https://stackoverflow.com/questions/4459379/preview-an-image-before-it-is-uploaded
	//http://qaru.site/questions/24784/javascript-image-resize

	function refresh_all_preloads_html()
	{
		//если файлов нет, убираем отступы по y 
		if (files.length == 0)
			$('.preloads').addClass('my0_py0');
		else
			$('.preloads').removeClass('my0_py0');
		
		$('.preloads').empty();
		for (let i = 0; i < files.length; i++)
			{
				let p_text = $('<div/>', { /* id: 'some-id', */ "class": 'p_text' });
				let p_close = $('<div/>', { /* id: 'some-id', */ "class": 'p_close', "ind": i }); //ind передается для удаления - p_close.click
				let p_preview = $('<div/>', { /* id: 'some-id', */ "class": 'p_preview' });
				let p_item = $('<div/>', { /* id: 'some-id', */ "class": 'p_item' });
				
				p_text.append(files[i].name);

				let reader = new FileReader();
				reader.onload = function(e) {
				  $(p_preview).css('background-image', "url(" + e.target.result + ")");
				}
				reader.readAsDataURL(files[i]);
				
				p_close.append('×');
				p_close.click( function(e){
					files.splice(e.target.getAttribute("ind"), 1);
					refresh_all_preloads_html();
				});
				
				p_item.append(p_text);
				p_item.append(p_preview);
				p_item.append(p_close);
				$('.preloads').append(p_item);
			}
	}
	
	refresh_all_preloads_html();

	//-----------------------------------------------------------------------
	//             Валидация форм
	//-----------------------------------------------------------------------
	
	function Validate(formId)
	{
		if (formId == 'calculation_form')
		{
			let result = true;
			
			//если нет - result = false;
			
			let myForm = $('#' + formId)[0];
			
			let erText_1 = '';
			let inp_1 = $(myForm).find("[name='site-problem']")[0];
			$(inp_1).removeClass('error');
			$(inp_1).parent().find( '.myTooltip' ).remove();
			if (!$(inp_1).val() || $(inp_1).val().length == 0)
			{
				erText_1 += '* Это обязательное поле\n'
			}
			if (erText_1 != '')
			{
				result = false;
				$(inp_1).addClass( 'error' );
				let tooltip = $( '<div/>', { /* id: 'some-id', */ "class": 'myTooltip' });
				tooltip.append(erText_1);
				$(inp_1).parent().append(tooltip);
			}
			
			//точная копия:
			let erText_2 = '';
			let inp_2 = $(myForm).find("[name='user-name']")[0];
			$(inp_2).removeClass('error');
			$(inp_2).parent().find( '.myTooltip' ).remove();
			if (!$(inp_2).val() || $(inp_2).val().length == 0)
			{
				erText_2 += '* Это обязательное поле\n'
			}
			if (erText_2 != '')
			{
				result = false;
				$(inp_2).addClass( 'error' );
				let tooltip = $( '<div/>', { /* id: 'some-id', */ "class": 'myTooltip' });
				tooltip.append(erText_2);
				$(inp_2).parent().append(tooltip);
			}
			
			//точная копия:
			let erText_3 = '';
			let inp_3 = $(myForm).find("[name='site-name']")[0];
			$(inp_3).removeClass('error');
			$(inp_3).parent().find( '.myTooltip' ).remove();
			if (!$(inp_3).val() || $(inp_3).val().length == 0)
			{
				erText_3 += '* Это обязательное поле\n'
			}
			if (erText_3 != '')
			{
				result = false;
				$(inp_3).addClass( 'error' );
				let tooltip = $( '<div/>', { /* id: 'some-id', */ "class": 'myTooltip' });
				tooltip.append(erText_3);
				$(inp_3).parent().append(tooltip);
			}
			
			//точная копия:, отлич-ся только "[name='bitrix']"
			let erText_4 = '';
			let inp_4 = $(myForm).find("[name='bitrix']")[0];
			$(inp_4).removeClass('error');
			$(inp_4).parent().find( '.myTooltip' ).remove();
			if (!$(inp_4).val() || $(inp_4).val().length == 0)
			{
				erText_4 += '* Это обязательное поле\n'
			}
			if (erText_4 != '')
			{
				result = false;
				$(inp_4).addClass( 'error' );
				let tooltip = $( '<div/>', { /* id: 'some-id', */ "class": 'myTooltip' });
				tooltip.append(erText_4);
				$(inp_4).parent().append(tooltip);
			}
			
			//e-mail
			let erText_5 = '';
			let inp_5 = $(myForm).find("[name='user-mail']")[0];
			$(inp_5).removeClass('error');
			$(inp_5).parent().find( '.myTooltip' ).remove();
			if (!$(inp_5).val() || $(inp_5).val().length == 0)
			{
				erText_5 += '* Это обязательное поле\n'
			}
			else
			{
				//https://stackoverflow.com/questions/46155/how-to-validate-an-email-address-in-javascript
				// RFC 2822
				//var mailRegExp = new RegExp("(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*|"(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21\x23-\x5b\x5d-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])*")@(?:(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?|\[(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?|[a-z0-9-]*[a-z0-9]:(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21-\x5a\x53-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])+)\])");
				var mailRegExp = new RegExp("[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?");
				if (!mailRegExp.test($(inp_5).val()))
					erText_5 += 'Некорректный e-mail \n'
			}
			if (erText_5 != '')
			{
				result = false;
				$(inp_5).addClass( 'error' );
				let tooltip = $( '<div/>', { /* id: 'some-id', */ "class": 'myTooltip' });
				tooltip.append(erText_5);
				$(inp_5).parent().append(tooltip);
			}
			
			return result;
		}
		else if (formId == 'popup_form')
		{
			let result = true;
			
			//если нет - result = false;
			
			let myForm = $('#' + formId)[0];
			
			let erText_1 = '';
			let inp_1 = $(myForm).find("[name='user-name_modal']")[0];
			$(inp_1).removeClass('error');
			$(inp_1).parent().find( '.myTooltip' ).remove();
			if (!$(inp_1).val() || $(inp_1).val().length == 0)
			{
				erText_1 += '* Это обязательное поле\n'
			}
			if (erText_1 != '')
			{
				result = false;
				$(inp_1).addClass( 'error' );
				let tooltip = $( '<div/>', { /* id: 'some-id', */ "class": 'myTooltip' });
				tooltip.append(erText_1);
				$(inp_1).parent().append(tooltip);
			}
			
			//e-mail
			let erText_2 = '';
			let inp_2 = $(myForm).find("[name='user-mail_modal']")[0];
			$(inp_2).removeClass('error');
			$(inp_2).parent().find( '.myTooltip' ).remove();
			if (!$(inp_2).val() || $(inp_2).val().length == 0)
			{
				erText_2 += '* Это обязательное поле\n'
			}
			else
			{
				//https://stackoverflow.com/questions/46155/how-to-validate-an-email-address-in-javascript
				var mailRegExp = new RegExp("[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?");
				if (!mailRegExp.test($(inp_2).val()))
					erText_2 += 'Некорректный e-mail \n'
			}
			if (erText_2 != '')
			{
				result = false;
				$(inp_2).addClass( 'error' );
				let tooltip = $( '<div/>', { /* id: 'some-id', */ "class": 'myTooltip' });
				tooltip.append(erText_2);
				$(inp_2).parent().append(tooltip);
			}
			
			//точная копия:, отлич-ся только user-linksite_modal
			let erText_3 = '';
			let inp_3 = $(myForm).find("[name='user-linksite_modal']")[0];
			$(inp_3).removeClass('error');
			$(inp_3).parent().find( '.myTooltip' ).remove();
			if (!$(inp_3).val() || $(inp_3).val().length == 0)
			{
				erText_3 += '* Это обязательное поле\n'
			}
			if (erText_3 != '')
			{
				result = false;
				$(inp_3).addClass( 'error' );
				let tooltip = $( '<div/>', { /* id: 'some-id', */ "class": 'myTooltip' });
				tooltip.append(erText_3);
				$(inp_3).parent().append(tooltip);
			}
			
			return result;
		}
		
		return false;
	}

	//-----------------------------------------------------------------------
	//             Форма снизу, событие SUBMIT
	//-----------------------------------------------------------------------	

	$('.calculation-form__form').submit(function(event) {
		event.stopPropagation(); // Прекращаем дальнейшую передачу текущего события.
		event.preventDefault(); // Запрещаем стандартное поведение для кнопки submit
		
		//Валидация
		if (!Validate('calculation_form'))
			return;
		
		var button = $(this).find('.calculation-form__btn');
		let formTargetId = $(this).attr("id");

		var formserialize = new FormData(this);
		
		var data = new FormData();
		
		$.each(files, function(key, value){
			data.append('files'+key, value);
		});
		
		data.append('formId', formTargetId);
		
		data.append('my_file_upload', formserialize.get("my_file_upload"));

		data.append('name', formserialize.get("user-name"));
		data.append('phone', formserialize.get("user-phone"));
		data.append('site', formserialize.get("site-name"));
		data.append('bitrix', $("#bitrix").val());
		data.append('problem', formserialize.get("site-problem"));
		data.append('links', formserialize.get("site-problem-links"));
		data.append('device', formserialize.get("user-device"));
		data.append('mail', formserialize.get("user-mail"));
		if (formserialize.get("user-device"))
		{
			var user = detect.parse(navigator.userAgent);
			var main_info = 'Браузер пользователя: ' + user.browser.family + ' ' + user.browser.version + '; ОС пользователя: ' + user.os.name + ' .';
			
			var _navigator = {};
			_navigator['main_info'] = main_info;
			for (var i in navigator) _navigator[i] = navigator[i];
			
			// --- для IE
			delete _navigator.plugins;
			delete _navigator.mimeTypes;
			// --- конец --- для IE
			
			data.append('device_details', JSON.stringify(_navigator));
		}
		
		if (formserialize.get("user-phone"))
			data.append('way_to_contact', formserialize.get("contact_way"));

		$(button).html('Форма отправлена');
		$(button).prop('disabled',true);
		
		$.ajax({
			type: "POST",
			url: "/ajax/rest.php",
			data: data,
			cache: false,
			processData: false, // NEEDED, DON'T OMIT THIS
			contentType: false, // NEEDED, DON'T OMIT THIS (requires jQuery 1.6+)
			dataType: 'json',
			success: function(respond, status, jqXHR){
				//Два случая: успех и ошибка валидации на сервере				
				//Успех
				if (respond.success == 'true')
				{
					console.log(JSON.stringify(respond));
					alert("Спасибо за заявку! В ближайшее время наш менеджер свяжется с Вами для уточнения деталей.");
				}
				//Ошибка
				else if (respond.success == 'false')
				{
					console.log(JSON.stringify(respond));
					if (respond.error_type == 'external_error')
						alert(respond.error_message);
				}
				else
					console.log('Не удалось распознать ответ сервера: \n' + JSON.stringify(respond));
			}
			
			,error: function(xhr, status, error)
			{
				console.log('ajaxError xhr:', xhr); // выводим значения переменных
				console.log('ajaxError status:', status);
				console.log('ajaxError error:', error);

				// соберем самое интересное в переменную
				var errorInfo = 'Ошибка выполнения запроса: '
						+ '\n[' + xhr.status + ' ' + status   + ']'
						+  ' ' + error + ' \n '
						+ xhr.responseText
						+ '<br>'
						+ xhr.responseJSON;

				console.log('ajaxError:', errorInfo); // в консоль
				//alert(errorInfo); // если требуется, то и на экран
			}
		});
	});

	//-----------------------------------------------------------------------
	//             js-всплывающая форма, событие SUBMIT
	//-----------------------------------------------------------------------

	$('.popup-form__form').submit(function(event) {
		event.stopPropagation();
		event.preventDefault();
		
		//Валидация
		if (!Validate('popup_form'))
			return;
		
		var button = $(this).find('.popup-form__btn');
		let formTargetId = $(this).attr("id");
	
		var formserialize = new FormData(this);
		
		var data = new FormData();
		
		data.append('formId', formTargetId);
		
		data.append('name', formserialize.get("user-name_modal"));
		data.append('site', formserialize.get("user-linksite_modal"));
		data.append('phone', formserialize.get("user-phone_modal"));
		data.append('mail', formserialize.get("user-mail_modal"));
		
		$.ajax({
			type: "POST",
			url: "/ajax/rest.php",
			data: data,
			cache: false,
			processData: false, // NEEDED, DON'T OMIT THIS
			contentType: false, // NEEDED, DON'T OMIT THIS (requires jQuery 1.6+)
			dataType: 'json',
			success: function(respond, status, jqXHR){
				$(button).html('Форма отправлена');
				$(button).prop('disabled',true);
				alert("Спасибо за заявку! В ближайшее время наш менеджер свяжется с Вами для уточнения деталей.");
			}
			
			,error: function(xhr, status, error)
			{
				console.log('ajaxError xhr:', xhr); // выводим значения переменных
				console.log('ajaxError status:', status);
				console.log('ajaxError error:', error);

				// соберем самое интересное в переменную
				var errorInfo = 'Ошибка выполнения запроса: '
						+ '\n[' + xhr.status + ' ' + status   + ']'
						+  ' ' + error + ' \n '
						+ xhr.responseText
						+ '<br>'
						+ xhr.responseJSON;

				console.log('ajaxError:', errorInfo); // в консоль
				//alert(errorInfo); // если требуется и то на экран
			}
		});
	});
});	

//-----------------------------------------------------------------------
//             Кастомный список
//-----------------------------------------------------------------------
//https://select2.org/
$( document ).ready(function (){
	$('select').select2(); //подключение
	
	//насройки
	$('select').select2({
		//...
		"language": {
		   "noResults": function(){
			   return "Нет подходящих результатов";
		   }
		},
		escapeMarkup: function (markup) {
			return markup;
		},
	});
	
	/*
	//тесты
	$('select').change(function() {
	alert($("select").val()); 
	if ($("select").val()[1])
		alert($("select").val()[1]); 
	});
	*/
	
});

//-----------------------------------------------------------------------
//             Летающие подсказки-placeholder'ы
//-----------------------------------------------------------------------

//летающая подсказка-placeholder
//Flying_Placeholder - класс обертки для label, в котором текст placeholder'а и input'а или textarea

$( document ).ready(function (){
	let wraps = $('.Flying_Placeholder');
	for (let i = 0; i < wraps.length; i++)
	{
		let flying_label = $(wraps[i]).find("label");
		let inp = $(wraps[i]).find("input, textarea, select");
		$(flying_label).click(function() {
			for (let k = 0; k < inp.length; k++)
			{
				inp[k].focus();
				if ($(inp[k]).hasClass("select2-hidden-accessible")) //s2
					$(inp[k]).select2('open'); //s2
			}
		});
		
		let s2 = $(wraps[i]).find(".select2"); //s2
		$(s2).click(function() { //s2
			for (let k = 0; k < inp.length; k++) //s2
			{ //s2
				inp[k].focus(); //s2
				if ($(inp[k]).hasClass("select2-hidden-accessible")) //s2
					$(inp[k]).select2('open'); //s2
			} //s2
		}); //s2
		
		for (let k = 0; k < inp.length; k++)
		{
			$(inp[k]).on ( "focus" , function() {
				//input/textarea событие focus - фокус элемента
				flying_label.addClass("focus");
			});
			$(inp[k]).on( "blur" , function() {
				//input/textarea событие blur - фокус снят
				if (!$(inp[k]).val() || $(inp[k]).val().length == 0) {
					if (!$(inp[k]).hasClass("select2-search__field"))  //s2
						flying_label.removeClass("focus");
				}	
			});
			
			$(inp[k]).on( "change, select2:close" , function() {  //s2
				if (!$(inp[k]).val() || $(inp[k]).val().length == 0)  //s2
					flying_label.removeClass("focus");  //s2
			});  //s2
			
			//при загрузке
			if ($(inp[k]).val() && $(inp[k]).val().length != 0) //если поле заполнено
				flying_label.addClass("focus");
		}
	}
});

$( document ).ready(function (){
	//calculation-form
	let user_phone = $('.calculation-form #user-phone')[0];
	let wtc_wrap = $('.calculation-form .way_to_contact')[0];
	$(user_phone).on( "focus" , function() {
			$(wtc_wrap).addClass("focus");
	});
	$(user_phone).on( "blur" , function() {
		if (!$(user_phone).val() || $(user_phone).val().length == 0)
			$(wtc_wrap).removeClass("focus");
	});
	if ($(user_phone).val() && $(user_phone).val().length != 0)
		$(wtc_wrap).addClass("focus");
});

//-----------------------------------------------------------------------
//             Переключалка нижней границы header'а
//-----------------------------------------------------------------------

$( document ).ready(function (){
	function refresh_header_scroll (){
		if ($( document ).scrollTop() < 10)
		{
			$( 'header.header' ).removeClass("headerBottomBorder");
		}
		else
		{
			$( 'header.header' ).addClass("headerBottomBorder");
		}
	}
	
	refresh_header_scroll(); //на случай перезагрузки страницы с сохранением текущего scrollTop
	$( document ).scroll(refresh_header_scroll);
});