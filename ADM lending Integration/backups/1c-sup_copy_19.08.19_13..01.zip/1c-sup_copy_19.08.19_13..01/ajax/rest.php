<?

// CRM (система управления взаимоотношениями с клиентами) - это битрикс24
// CRM is Bitrix24

// CRM server conection data
// Данные соединения с сервером CRM
define('CRM_HOST', 'admcenter.bitrix24.ru');		// your CRM domain name			//Ваше доменное имя CRM
define('CRM_PORT', '443');							// CRM server port				//Порт сервера CRM
define('CRM_PATH', '/crm/configs/import/lead.php'); // CRM server REST service path	// Путь службы REST сервера CRM

// CRM server authorization data
// Данные авторизации CRM-сервера
define('CRM_LOGIN', 'lid@adm-center.ru');			// login of a CRM user able to manage leads	// логин пользователя CRM, которому доступно управление лидами
define('CRM_PASSWORD', 'Lidadmcenter.001');			// password of a CRM user					// пароль этого пользователя
// OR you can send special authorization hash which is sent by server after first successful connection with login and password
// ИЛИ вы можете отправить специальный хеш авторизации, который отправляется сервером после первого успешного подключения с логином и паролем
define('CRM_AUTH', 'bf3dec9d8996af9fa4225e6f90019476111');	// authorization hash				// хеш авторизации

/********************************************************************************************/
//									ВОЗВРАЩАЕМЫЕ ДАННЫЕ
//С помощью Die() отсылается массив в формате json. Ключи массива
//'success'		=>	
//					'true'	- все прошло успешно
//					'false'	- есть ошибки
//'error_type' =>
//					''					
//					'internal_error'	- внутренняя ошибка - неправильно написан php-файл. Выводится в консоль js
//					'external_error'	- внешняя ошибка - пользователь ввел неправильные данные. Выводится не только в консоль js, но и в alert()
//'error_message' - текст ошибки
/********************************************************************************************/


//--------------------------------------------------------------------------------------------
//									ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ
//--------------------------------------------------------------------------------------------

// Transliteration of Cyrillic characters
// Транслитерация кирилических символов
// Used for the names of downloaded files
// Используется для названий загруженных файлов
function cyrillic_translit( $title ){
    $iso9_table = array(
        'А' => 'A', 'Б' => 'B', 'В' => 'V', 'Г' => 'G', 'Ѓ' => 'G',
        'Ґ' => 'G', 'Д' => 'D', 'Е' => 'E', 'Ё' => 'YO', 'Є' => 'YE',
        'Ж' => 'ZH', 'З' => 'Z', 'Ѕ' => 'Z', 'И' => 'I', 'Й' => 'J',
        'Ј' => 'J', 'І' => 'I', 'Ї' => 'YI', 'К' => 'K', 'Ќ' => 'K',
        'Л' => 'L', 'Љ' => 'L', 'М' => 'M', 'Н' => 'N', 'Њ' => 'N',
        'О' => 'O', 'П' => 'P', 'Р' => 'R', 'С' => 'S', 'Т' => 'T',
        'У' => 'U', 'Ў' => 'U', 'Ф' => 'F', 'Х' => 'H', 'Ц' => 'TS',
        'Ч' => 'CH', 'Џ' => 'DH', 'Ш' => 'SH', 'Щ' => 'SHH', 'Ъ' => '',
        'Ы' => 'Y', 'Ь' => '', 'Э' => 'E', 'Ю' => 'YU', 'Я' => 'YA',
        'а' => 'a', 'б' => 'b', 'в' => 'v', 'г' => 'g', 'ѓ' => 'g',
        'ґ' => 'g', 'д' => 'd', 'е' => 'e', 'ё' => 'yo', 'є' => 'ye',
        'ж' => 'zh', 'з' => 'z', 'ѕ' => 'z', 'и' => 'i', 'й' => 'j',
        'ј' => 'j', 'і' => 'i', 'ї' => 'yi', 'к' => 'k', 'ќ' => 'k',
        'л' => 'l', 'љ' => 'l', 'м' => 'm', 'н' => 'n', 'њ' => 'n',
        'о' => 'o', 'п' => 'p', 'р' => 'r', 'с' => 's', 'т' => 't',
        'у' => 'u', 'ў' => 'u', 'ф' => 'f', 'х' => 'h', 'ц' => 'ts',
        'ч' => 'ch', 'џ' => 'dh', 'ш' => 'sh', 'щ' => 'shh', 'ъ' => '',
        'ы' => 'y', 'ь' => '', 'э' => 'e', 'ю' => 'yu', 'я' => 'ya'
    );

    $name = strtr( $title, $iso9_table );
    $name = preg_replace('~[^A-Za-z0-9\'_\-\.]~', '-', $name );	//Находим любые символы, кроме A-Z, a-z, 0-9, ', _, - или . и заменяем на сивмол -
    $name = preg_replace('~\-+~', '-', $name );		// --- на -
    $name = preg_replace('~^-+|-+$~', '', $name );	// кил - на концах

    return $name;
}

//Turns the number of bytes into a string
//Преобразует количество байтов в строку
//Example: formatBytes (2500) will output "2.44 Kb"
//Пример: formatBytes(2500) выведет "2.44 Kb"
function formatBytes($bytes, $precision = 2) { 
    $units = array('b', 'Kb', 'Mb', 'Gb', 'Tb'); 

    $bytes = max($bytes, 0); 
    $pow = floor(($bytes ? log($bytes) : 0) / log(1024)); 
    $pow = min($pow, count($units) - 1); 
    $bytes /= pow(1024, $pow);

    return round($bytes, $precision) . ' ' . $units[$pow]; 
} 


//--------------------------------------------------------------------------------------------
//									ОБРАБОТКА ФАЙЛОВ
//--------------------------------------------------------------------------------------------

if($_POST['my_file_upload']=="123" && $_FILES){  
    // ВАЖНО! тут должны быть все проверки безопасности передавемых файлов и вывести ошибки, если нужно
	$allowed_filetypes = array('jpg','jpeg','jfif','pjpeg','pjp','png','bm','bmp', 'dib'); // Допустимые типы файлов
	$max_filesize = 5242880; // Максимальный размер файла в байтах (в данном случае он равен 5 Мб = 5242880 байт).

    $uploaddir = './uploads'; // . - текущая папка где находится submit.php
    
    // cоздадим папку если её нет
    if(!is_dir($uploaddir))mkdir($uploaddir, 0777);

    $files = $_FILES; // полученные файлы
    $done_files = array();

    // переместим файлы из временной директории в указанную
    foreach($files as $file){
		$filename = $file['name']; // В переменную $filename заносим имя файла (включая расширение).
		$ext = strtoupper(pathinfo($filename, PATHINFO_EXTENSION)); // В переменную $ext заносим расширение загруженного файла.
		
		if(in_array($ext, array_map('strtoupper', $allowed_filetypes))) // array_map(strtoupper, $array) - переведет весь массив $array в верхний регистр
		{
			if(filesize($file['tmp_name']) < $max_filesize) // Проверим размер загруженного файла.
			{
				$file_name = cyrillic_translit($file['name']);
				if(move_uploaded_file($file['tmp_name'], "$uploaddir/$file_name")){
					$done_files[] = realpath( "$uploaddir/$file_name" );
				}
			}
			else
			{
				//ОШИБКА:
				$error_message = "Ошибка загрузки файлов: \n";
				$error_message .= $file['name'] . " - Файл слишком большой. Максимальный размер файла - " . formatBytes($max_filesize) . "\n";
				DIE(json_encode(array('success'=>'false','error_type'=>'external_error','error_message'=>$error_message)));
			}
		}
		else
		{
			//ОШИБКА:
			$error_message = "Ошибка загрузки файлов: \n";
			$error_message .= "\"" . $ext . "\"" . " - Этот тип файлов не разрешен. \n";
			DIE(json_encode(array('success'=>'false','error_type'=>'external_error','error_message'=>$error_message)));
		}
    }

	$datafile = array('files' => $done_files);
	
}

//--------------------------------------------------------------------------------------------
//										ВАЛИДАЦИЯ
//--------------------------------------------------------------------------------------------

//Возвращает массив в 3мя ключами:
//							error			=> true/false,
//							error_message	=> 'сообщение об ошибке'/'',
//							value			=> отформатированное значение
function validate($key_id, $value_in, $description, $form_id = null)
{
	$error = false;
	$error_message = '';
	$value_out = $value_in;
	
	switch ($key_id)
	{
		case 'email':
			if (!filter_var('bob@example.com', FILTER_VALIDATE_EMAIL))
			{
				$error = true;
				$error_message = "Ошибка: \n";
				$error_message .= "Поле \"" . $description . "\" не прошло валидацию на сервере. Заполните поле правильно.";
			}
			break;
			
		case 'problem_device_yn':
			$value_out = ($value_in == "on") ? "Да" : "Нет";
			break;
			
		case 'way_to_contact':
			$value_out = ($value_in == "manager") ? "Звонок менеджера" : $value_in;
			break;
			
		default:
			$error = false;
			$error_message = '';
			$value_out = $value_in;
	}
	
	return array('error' => $error, 'error_message' => $error_message, 'value' => $value_out);
}

//--------------------------------------------------------------------------------------------
//										КЛЮЧИ
//--------------------------------------------------------------------------------------------

//description - используется для заполнения поля комментариев COMMENTS в bitrix24.
//		Поскольку все поля дублируются в комментариях, должно быть заполнено. Также
//		используется для вывода сообщений об ошибках для пользователей
//b24_key - ключ массива для API bitrix24. Взять можно здесь:
//		https://dev.1c-bitrix.ru/community/blogs/chaos/crm-sozdanie-lidov-iz-drugikh-servisov.php
//form_id - id формы, см. в её html
//input_name - имя параметра в массиве $_POST. Равно аттрибуту name в html формы, но
//		могло быть изменено в js. См. html и js.
//internal_vals - значения полей, которые не приходят с формы. Кроме параметров
//		соединения с сервером и авторизации в CRM. Они задавались выше
//post_vals - описание параметров, которые передаются через $_POST.

$_MyKEYS = array(
	
	//форма, которая снизу. Расчет стоимости задачи.
    array(
        'form_id' => "calculation_form", 
        'internal_vals' => array(
			array(
                'b24_key'			=> 'TITLE',
                'value'				=> '1c-bitrixsupport.ru. Расчет стоимости задачи.'
            ),
			array(
                'b24_key'			=> 'SOURCE_DESCRIPTION',
                'value'				=> '1c-bitrixsupport.ru'
            ),
            array(
                'b24_key'			=> 'ASSIGNED_BY_ID',
                'value'				=> 126	//id ответственного за Лид
            ),
        ),
        'post_vals' => array(
            array(
                'id'					=> 'name',
                'input_name'			=> 'name',
                'b24_key'				=> 'NAME',
                'description'			=> 'Имя'
            ),
            array(
                'id'					=> 'phone',
                'input_name'			=> 'phone',
                'b24_key'				=> 'PHONE_MOBILE',
                'description'			=> 'Телефон'
            ),
			array(
                'id'					=> 'site',
                'input_name'			=> 'site',
                'b24_key'				=> 'WEB_WORK',
                'description'			=> 'Сайт'
            ),
			array(
                'id'					=> 'email',
                'input_name'			=> 'mail',
                'b24_key'				=> 'EMAIL_WORK',
                'description'			=> 'E-mail'
            ),
			array(
                'id'					=> 'bitrix_edition',
                'input_name'			=> 'bitrix',
                'b24_key'				=> 'COMMENTS',
                'description'			=> 'Редакция 1С-Битрикс'
            ),
			array(
                'id'					=> 'problem_description',
                'input_name'			=> 'problem',
                'b24_key'				=> 'COMMENTS',
                'description'			=> 'Описание проблемы'
            ),
			array(
                'id'					=> 'problem_links',
                'input_name'			=> 'links',
                'b24_key'				=> 'COMMENTS',
                'description'			=> 'Ссылки на страницы, где обнаружена проблема'
            ),
			array(
                'id'					=> 'problem_device_yn',
                'input_name'			=> 'device',
                'b24_key'				=> 'COMMENTS',
                'description'			=> 'Я пишу с устройства, на котором обнаружилась проблема'
            ),
			array(
                'id'					=> 'problem_device_details',
                'input_name'			=> 'device_details',
                'b24_key'				=> 'COMMENTS',
                'description'			=> 'Устройство'
            ),
			array(
                'id'					=> 'way_to_contact',
                'input_name'			=> 'way_to_contact',
                'b24_key'				=> 'COMMENTS',
                'description'			=> 'Способ связаться'
            ),
        )
    ),
	
	//всплывающая форма. Заявка на постоянное обслуживание.
    array(
        'form_id' => "popup_form", 
        'internal_vals' => array(
			array(
                'b24_key'			=> 'TITLE',
                'value'				=> '1c-bitrixsupport.ru. Заявка на постоянное обслуживание.' //Заголовок
            ),
			array(
                'b24_key'			=> 'SOURCE_DESCRIPTION',
                'value'				=> '1c-bitrixsupport.ru'  //Дополнительно об источнике
            ),
            array(
                'b24_key'			=> 'ASSIGNED_BY_ID',
                'value'				=> 126 //id ответственного за Лид
            ),
        ),
        'post_vals' => array(
            array(
                'id'					=> 'name',
                'input_name'			=> 'name',
                'b24_key'				=> 'NAME',
                'description'			=> 'Имя'
            ),
            array(
                'id'					=> 'phone',
                'input_name'			=> 'phone',
                'b24_key'				=> 'PHONE_MOBILE',
                'description'			=> 'Телефон'
            ),
			array(
                'id'					=> 'site',
                'input_name'			=> 'site',
                'b24_key'				=> 'WEB_WORK',
                'description'			=> 'Сайт'
            ),
			array(
                'id'					=> 'email',
                'input_name'			=> 'mail',
                'b24_key'				=> 'EMAIL_WORK',
                'description'			=> 'E-mail'
            ),
        )
    ),
);


//--------------------------------------------------------------------------------------------
//								ОБРАБОТКА $_POST КРОМЕ ФАЙЛОВ
//--------------------------------------------------------------------------------------------

// POST processing
if ($_SERVER['REQUEST_METHOD'] == 'POST')
{
	// get lead data from the form
	$leadData = $_POST;

	$postData = array();
	
	//Проверяем существование нужного $leadData['formId'] в $_MyKEYS
	$form_exists = false;	
	foreach ($_MyKEYS as $form)
		if ($form['form_id'] == $leadData['formId'])
		{
			$form_exists = true;
			break;
		}
	if (!$form_exists)
	{
		//ВНУТРЕННЯЯ ОШИБКА: 1
		$error_message = "Ошибка 1: \n";
		$error_message .= "Неизвестный id формы: " . "\"" . $leadData['formId'] . "\"" . "\n";
		DIE(json_encode(array('success'=>'false','error_type'=>'internal_error','error_message'=>$error_message)));
	}
	
	foreach ($_MyKEYS as $form)
		if ($form['form_id'] == $leadData['formId'])
		{
			//Заполняем поля, значения которых задавались здесь (кроме параметров соединения с сервером и авторизации в CRM)
			foreach ($form['internal_vals'] as $v)
				if ($v['b24_key'] && $v['value'])
					$postData[$v['b24_key']] = $v['value'];
				else
				{
					//ВНУТРЕННЯЯ ОШИБКА: 2
					$error_message = "Ошибка 2: \n";
					DIE(json_encode(array('success'=>'false','error_type'=>'internal_error','error_message'=>$error_message)));
				}
				
				
			//Готовим поле комментариев COMMENTS
			$comm = '<div style="font-size: 18px; line-height: 22px;"><b>Комментарии, ответы пользователя</b></div><br>';
			$comm .= "<div style=\"font-weight: normal; \">";//открывающий div
			
			//Добавим в комментарии заголовок
			foreach ($form['internal_vals'] as $v)
				if ($v['b24_key'] == 'TITLE')
					$comm .= '<b>' . $v['value'] . '</b><br><br>';
			
			foreach ($form['post_vals'] as $v)
				if ($leadData[$v['input_name']])
				{
					$validate_result = validate($v['id'], $leadData[$v['input_name']], $v['description']);
					if ($validate_result['error'] == false)
					{
						//заполняем поля, не являющиеся комментариями
						if ($v['b24_key'] != 'COMMENTS' && $v['b24_key'] != '')
							$postData[$v['b24_key']] = $validate_result['value'];
						
						//заполняем комментарии
						if ($v['description'])
							$comm .= '<b>' . $v['description'] . ': </b>';
						$comm .= $validate_result['value'];
						$comm .=  '<br><br>';
					}
					else
					{
						//ОШИБКА:
						DIE(json_encode(array('success'=>'false','error_type'=>'external_error','error_message'=>$validate_result['error_message'])));
					}
				}
				
			//Добавим в комментарии ссылки на загруженные файлы (подготовлены выше)
			if($datafile['files'])
			{
				$comm .= '<b>Загруженные файлы: </b><br>';
				foreach($datafile['files'] as $file)
				{
					//ПРИ ПЕРЕНОСЕ ИЗМЕНИТЬ:
					$_url = str_replace('/home/users/a/admservice/domains/', 'http://', $file); //-------!!!!!!!ПРИ ПЕРЕНОСЕ ИЗМЕНИТЬ
					$comm .= "<a href=\"".$_url."\">".$_url."</a>";
					$comm .= '<br>';
				}
				$comm .= '<br>';
			}
					
			$comm .= "</div>"; //закрывающий div комментариев
			$postData['COMMENTS'] = $comm;
			
			break;
		}
		
		
	

	// append authorization data
	if (defined('CRM_AUTH'))
	{
		$postData['AUTH'] = CRM_AUTH;
	}
	else
	{
		$postData['LOGIN'] = CRM_LOGIN;
		$postData['PASSWORD'] = CRM_PASSWORD;
	}

	// open socket to CRM
	$fp = fsockopen("ssl://".CRM_HOST, CRM_PORT, $errno, $errstr, 30);
	if ($fp)
	{
		// prepare POST data
		$strPostData = '';
		foreach ($postData as $key => $value)
			$strPostData .= ($strPostData == '' ? '' : '&').$key.'='.urlencode($value);

		// prepare POST headers
		$str = "POST ".CRM_PATH." HTTP/1.0\r\n";
		$str .= "Host: ".CRM_HOST."\r\n";
		$str .= "Content-Type: application/x-www-form-urlencoded\r\n";
		$str .= "Content-Length: ".strlen($strPostData)."\r\n";
		$str .= "Connection: close\r\n\r\n";

		$str .= $strPostData;

		// send POST to CRM
		fwrite($fp, $str);

		// get CRM headers
		$result = '';
		while (!feof($fp))
		{
			$result .= fgets($fp, 128);
		}
		fclose($fp); 
		
		// cut response headers
		$response = explode("\r\n\r\n", $result);
		
		$output = '<pre>'.print_r($response[1], 1).'</pre>';
		DIE(json_encode(array('success'=>'true')));
	}
	else
	{
		//ОШИБКА:
		$error_message = "Соединение было прервано! \n";
		$error_message .= "Connection Failed! \n";
		$error_message .= $errstr. " (" . $errno . ")";
		DIE(json_encode(array('success'=>'false','error_type'=>'external_error','error_message'=>$error_message)));
	}
}
else
{
	$output = '';
}

// HTML form
?>
<?/*=$output;*/?>